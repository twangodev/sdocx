#!/usr/bin/env python3
"""Capture old Pencil through native Drawing with role-aware queue diagnostics.

This is a fresh ignored V17 successor to the frozen V16 uniform observer. It imports the pinned runtime helper
from ../montblanc-drawing-capture-root-v2 and maps the hash-pinned Pencil DSO.
It never calls Pencil RedrawPen/AddPoint directly: Drawing chooses the plugin
and selected class. `--preflight` is source/hash-only; `--capture` executes the
bounded ARM64 Unicorn harness and prints the complete native Drawing result,
queue-handoff record, and exact uniform guest payloads before Mesa forwarding. The real native SPPenCanvas returns a bounded
host IGLMsgQueue adapter, which retains native WorkerTask objects without running
them inside the callback destructor.

Example after review, from repository root:
  PYTHONPATH=scratch/apk-analysis-runtime/python:tmp/vector-parity-plan/montblanc-drawing-capture-root-v2/conformance \
  python3 tmp/vector-parity-plan/pen-family-audit/old-pencil-material-controlled-v17-vbo-observer/capture.py --capture --initial-seed <explicit-u32> --output tmp/vector-parity-plan/pen-family-audit/old-pencil-material-controlled-v17-vbo-observer/root-material-v17.json

The 4-point ObjectStroke is synthetic. Default `rand`/`srand` use an explicitly
identified host glibc profile; optional forced outputs are caller controls, not
an Android/Samsung RNG model or device state.
"""
from __future__ import annotations

import argparse
import ast
import base64
import ctypes as C
import hashlib
import linecache
import json
import locale
import os
import re
import struct
import subprocess
import sys
import traceback
import zlib
from pathlib import Path
from queue_contract import validate_task_snapshot

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
HELPERS = ROOT / "tmp/vector-parity-plan/montblanc-drawing-capture-root-v2/conformance"
RUNTIME = HELPERS / "native_drawing_runtime.py"
PLT_HELPER = HELPERS / "elf_plt.py"
RENDERER_ADAPTER = HELPERS / "marker3_paint_scale_native.py"
QUEUE_CONTRACT = HERE / "queue_contract.py"
APK = ROOT / "scratch/apk-input/samsung-notes-4.4.45.37.apk"
PENCIL = ROOT / "scratch/apk-output/samsung-notes-4.4.45.37/lib/arm64-v8a/libSPenPencil.so"
PENCIL_ANALYSIS = ROOT / "scratch/apk-analysis-native/arm64-v8a/libSPenPencil.so"
DRAWING_DSO = ROOT / "scratch/apk-analysis-native/arm64-v8a/libSPenDrawing.so"
RUNTIME_INPUTS = ROOT / "tmp/vector-parity-plan/montblanc-drawing-capture-root-v2/runtime-inputs"
BRUSH_CANVAS_RUNNER = ROOT / "scratch/vector-parity-plan/brushpen-full-queue/full_queue_actual_canvas.py"
BRUSH_CANVAS_EVIDENCE = ROOT / "scratch/vector-parity-plan/brushpen-full-queue/actual-canvas-evidence.json"
PIN = {
    "apk": "daed1eff8c8ee9dfb8afe2771e39e893a8808f3230d6d522a8aa647db09b8667",
    "pencil": "39eb599262676ca5ec67b86e702b43474a04e9ca9677072f247b131222189df9",
    "drawing_dso": "788bf413ddeb0b9d352062c5f1b7b8ed11babca911df72691da58ff1a0a5a4bd",
    "runtime_helper": "8cfdb8ca4b39518856460246ae829957b65f94afbbd002c63ec447b409a4d9f5",
    "plt_helper": "816eceff5b532b35c8ef9ea904a8aa64767422b0799347a18fbd4602b70f373b",
    "renderer_adapter": "9b1eafd3dd07d1b491148d2635aad004c83ac401416f3c8a9c62b1e60099b7a8",
    "renderer_dso": "f38df5db5e64f80c0641b6cee980e14533bd78e8e6eb34f250bd703d28119aed",
    "graphics_dso": "aac858ce3a9d0353d760b4b0ef09f1e88b0d4a87f5e0906fe8d53936ee8a6621",
    "cxx_shared": "4397241b4bd20a8e579bfb41d21107857e12985f6a01ca0c2a5f83380d1270b4",
    "base_dso": "e10da0116946691cf68302437ef261282e1dfe0eec15bf2dfa66093286985deb",
    "pencommon_dso": "afd39c0d55ec5cf47153be48222c8a9ddc0057fc772dd870af9ced74a59ec33d",
    "fountain_dso": "1fed4e071caffcb88a4df4ca345b6df5e3374852c9ef18044793fc2e340ac6ec",
    "airbrush_dso": "92ebe10993ebfcb42fa3f5c55e86f6d469ccac6638421bbd71f92e0558587423",
    "marker3_dso": "d9e63380088cadd4128f05d904bba109a3adff343c048d005beba4d83f5f15c5",
    "airbrush_helper": "6b33ed37a316f76908821e9069a852b34e483ac0da18e6b04e3357a889e59ea3",
    "inkpen_helper": "a3e65b2b37b2913b4bb2787b72ab2dbad0a9660cb66435b142f5acfa4d5051ae",
    "fountain_helper": "40cb917c7f286302d8519e9b953c3c21b7fe6ea0b6b0a80ccc13e2e724cfad30",
    "brush_canvas_runner": "1c1c8d98c5dbd3d492d13dc38de47085206ad4db8d3351ccce9a303a153d6703",
    "brush_canvas_evidence": "38778d8184a32402bc8fb40c735fb27f29dde1fb9937c3cfa868ccb8be28b712",
    "queue_contract": "87044d1b476f24041c0b9f5c00a4367e490ba40c727dba677c708676e44153cf",
}
FROZEN_V16_CAPTURE_SHA256 = "ab0abf5f6681dbe9a895d8b015dc9ed41ffe74ff2c694cccb1012cdbfcc31bdb"
FROZEN_V16_RECEIPT_SHA256 = "5c7d2053351d2f6dc0ba202b175e382e41727bf8e830fb34b0e7c21f7d1645d0"
FROZEN_V15_CAPTURE_SHA256 = "fbea81b2bdb50286093832217e38205b9f08c68a03fac22397e495fc2ae0dac9"
FROZEN_V14_RECEIPT_SHA256 = "872aed5a5fe6d62f8b6b66f6851351a1c0d36527aa1c22e20161416b533190d6"
FROZEN_V1_SHA256 = "6c703798ce33033fb8d3ea1bdca825f48f25378b88ec15b6a78b8b2e97924476"
PEN_NAME = "com.samsung.android.sdk.pen.pen.preload.Pencil"
PENCIL_BASE = 0xB000000
PENCIL_HANDLE = 0xB0000001
STOP = 0x200F1000
BASE_BASE = 0x2000000
GRAPHICS_BASE = 0x4000000
RENDERER_BASE = 0xA000000
GET_TIMESTAMP_RVA = 0x9A1F0
GET_TIMESTAMP_CLOCK_RETURN_RVA = 0x9A21C
CLOCK_GETTIME_PLT_RVA = 0xE5BB0
HOST_LIBC_SHA256 = "9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92"
PENCIL_SETTEXTURES_RVA = 0x2E9B4
PENCIL_INIT_SETTEXTURES_RETURN_RVA = 0x2ED2C
PENCIL_ARRAY_NEW_CALL_RVA = 0x2E9EC
PENCIL_ARRAY_NEW_CALL_RETURN_RVA = 0x2E9F0
PENCIL_BITMAP_UPDATE_CALL_RETURN_RVA = 0x2EAB4
PENCIL_TEXTURE_WIDTH = 144
PENCIL_TEXTURE_HEIGHT = 144
PENCIL_TEXTURE_RGBA8_BYTES = 144 * 144 * 4
GRAPHICS_TEXTURE_BITMAP_UPDATE_RVA = 0x90A94
GRAPHICS_SUBBITMAP_RT_UPDATE_THUNK_RVA = 0x8E6EC
GRAPHICS_SUBBITMAP_UPDATE_RETURN_RVA = 0x90AE0
RENDERER_TEXTURE_UPDATE_RVA = 0x5EE8C
RENDERER_TEXTURE_CREATE_RVA = 0x5E53C
RENDERER_TEXTURE_GET_WIDTH_RETURN_RVA = 0x5EF34
RENDERER_TEXTURE_GET_HEIGHT_RETURN_RVA = 0x5EF48
RENDERER_GL_SUBIMAGE_PLT_RVA = 0x656E0
RENDERER_GL_SUBIMAGE_RETURN_RVA = 0x5EF88
RENDERER_GL_SCISSOR_PLT_RVA = 0x648B0
RENDERER_SET_SCISSOR_RECT_RVA = 0x55D48
RENDERER_SET_SCISSOR_RECT_BRANCH_RVA = 0x55D54
GRAPHICS_ENABLE_CLIP_SCISSOR_RETURN_RVA = 0x94064


class NativeCallDiagnostic(Exception):
    def __init__(self, report, output_path):
        super().__init__(report["native_call"].get("symbol", "native call failed"))
        self.report = report
        self.output_path = output_path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_clock_gettime_callsite(clock_id: int, timespec_address: int,
                                    caller_lr: int, stack_low: int,
                                    stack_high: int, import_pc: int,
                                    import_name: str | None) -> None:
    """Require Base::GetTimeStamp's observed CLOCK_REALTIME ABI boundary."""
    if clock_id != 0:
        raise ValueError(f"expected CLOCK_REALTIME id 0, got {clock_id}")
    if caller_lr != BASE_BASE + GET_TIMESTAMP_CLOCK_RETURN_RVA:
        raise ValueError(f"clock_gettime caller is not pinned Base::GetTimeStamp: {caller_lr:#x}")
    if (import_pc != BASE_BASE + CLOCK_GETTIME_PLT_RVA
            or import_name not in ("clock_gettime", "clock_gettime@LIBC")):
        raise ValueError(f"clock_gettime import is not the pinned Base PLT entry: {import_pc:#x} {import_name!r}")
    if (timespec_address < stack_low or timespec_address + 16 > stack_high
            or timespec_address & 7):
        raise ValueError(f"timespec pointer is outside aligned native stack: {timespec_address:#x}")


def encode_target_timespec(seconds: int, nanoseconds: int) -> bytes:
    """Encode target AArch64 struct timespec as two signed 64-bit fields."""
    if not 0 <= nanoseconds < 1_000_000_000:
        raise ValueError(f"invalid timespec tv_nsec {nanoseconds}")
    return struct.pack("<qq", seconds, nanoseconds)


def validate_pencil_array_new_call(call_pc: int, requested_bytes: int,
                                   enclosing_caller_lr: int) -> int:
    """Validate the pre-BL allocation site and derive its actual return PC."""
    expected_call = PENCIL_BASE + PENCIL_ARRAY_NEW_CALL_RVA
    expected_return = PENCIL_BASE + PENCIL_ARRAY_NEW_CALL_RETURN_RVA
    expected_caller = PENCIL_BASE + PENCIL_INIT_SETTEXTURES_RETURN_RVA
    if call_pc != expected_call:
        raise ValueError(f"Pencil new[] call PC is not pinned setTextures: {call_pc:#x}")
    if call_pc + 4 != expected_return:
        raise ValueError("Pencil operator-new[] return does not immediately follow the pinned BL")
    if requested_bytes != PENCIL_TEXTURE_RGBA8_BYTES:
        raise ValueError(f"Pencil setTextures requested {requested_bytes} bytes, expected {PENCIL_TEXTURE_RGBA8_BYTES}")
    if enclosing_caller_lr != expected_caller:
        raise ValueError(f"Pencil setTextures was not called from pinned Init return: {enclosing_caller_lr:#x}")
    return call_pc + 4


def validate_exact_raw_source_span(pointer: int, requested_bytes: int,
                                   owner: dict | None) -> dict:
    """Require operator new[]'s returned base to own the whole packed buffer."""
    if not pointer or not owner:
        raise ValueError("Pencil new[] return has no recorded allocation owner")
    if (int(owner.get("base", "0"), 16) != pointer
            or int(owner.get("size", 0)) != requested_bytes
            or int(owner.get("offset", "-1"), 16) != 0):
        raise ValueError(f"Pencil source pointer {pointer:#x} is not the base of its exact {requested_bytes}-byte allocation")
    return owner


def decode_renderer_texture_object_prefix(prefix: bytes) -> dict:
    """Decode fields proven by TextureObject getters/Update machine code."""
    if len(prefix) < 84:
        raise ValueError(f"Renderer TextureObject prefix is too short: {len(prefix)}")
    target, texture_id = struct.unpack_from("<II", prefix, 40)
    width, height = struct.unpack_from("<II", prefix, 64)
    gl_format_index, gl_type_index = struct.unpack_from("<II", prefix, 76)
    return {"target_enum_at_plus_40": target, "texture_id_at_plus_44": texture_id,
        "width_at_plus_64": width, "height_at_plus_68": height,
        "gl_format_index_at_plus_76": gl_format_index,
        "gl_type_index_at_plus_80": gl_type_index}


def tightly_packed_rgba8_unpack_layout(width: int, height: int, alignment: int,
                                       row_length: int, skip_rows: int,
                                       skip_pixels: int, unpack_buffer: int) -> dict:
    """Compute client RGBA8 row pitch/span from the observed GLES unpack state."""
    if width <= 0 or height <= 0:
        raise ValueError(f"invalid RGBA8 image dimensions {width}x{height}")
    if alignment not in (1, 2, 4, 8):
        raise ValueError(f"invalid GL_UNPACK_ALIGNMENT {alignment}")
    if row_length != 0 or skip_rows != 0 or skip_pixels != 0 or unpack_buffer != 0:
        raise ValueError("Pencil source requires default row length, zero skips, and client memory")
    row_bytes = width * 4
    row_stride = ((row_bytes + alignment - 1) // alignment) * alignment
    source_span = (height - 1) * row_stride + row_bytes
    return {"width": width, "height": height, "bytes_per_pixel": 4,
        "row_length_pixels": row_length, "alignment_bytes": alignment,
        "skip_rows": skip_rows, "skip_pixels": skip_pixels,
        "pixel_unpack_buffer": unpack_buffer, "row_bytes": row_bytes,
        "row_stride_bytes": row_stride, "source_span_bytes": source_span,
        "tightly_packed": row_stride == row_bytes}


def pencil_shader_evidence() -> dict:
    blob = PENCIL.read_bytes()
    markers = {
        "vertex": b"precision highp float; layout(location = 0) in vec4 aRectPoint",
        "fragment": b"precision highp float; uniform sampler2D sampler0",
    }
    found = {}
    for label, marker in markers.items():
        offset = blob.find(marker)
        if offset < 0:
            raise RuntimeError(f"pinned Pencil DSO is missing embedded {label} shader")
        end = blob.find(b"\0", offset)
        if end < 0:
            raise RuntimeError(f"embedded Pencil {label} shader is not NUL terminated")
        source = blob[offset:end].decode("ascii")
        found[label] = {"elf_file_offset": hex(offset), "byte_length": end - offset,
                        "sha256": hashlib.sha256(source.encode()).hexdigest(),
                        "source": source}
    return {"dso_sha256": digest(PENCIL), "shaders": found}


def preflight() -> None:
    for path, key in ((APK, "apk"), (PENCIL, "pencil"),
                      (PENCIL_ANALYSIS, "pencil"), (DRAWING_DSO, "drawing_dso"),
                      (RUNTIME, "runtime_helper"),
                      (PLT_HELPER, "plt_helper"), (RENDERER_ADAPTER, "renderer_adapter"),
                      (HELPERS / "airbrush_texture_native.py", "airbrush_helper"),
                      (HELPERS / "inkpen_paint_native.py", "inkpen_helper"),
                      (HELPERS / "fountain_native.py", "fountain_helper"),
                      (QUEUE_CONTRACT, "queue_contract"),
                      (BRUSH_CANVAS_RUNNER, "brush_canvas_runner"),
                      (BRUSH_CANVAS_EVIDENCE, "brush_canvas_evidence")):
        if not path.is_file() or digest(path) != PIN[key]:
            raise SystemExit(f"pin mismatch or missing input: {path}")
    if digest(PENCIL) != digest(PENCIL_ANALYSIS):
        raise SystemExit("decoded-APK Pencil DSO and analysis copy differ")
    for path, key in ((RUNTIME_INPUTS / "libSPenRenderer.so", "renderer_dso"),
                      (RUNTIME_INPUTS / "libSPenGraphics.so", "graphics_dso"),
                      (RUNTIME_INPUTS / "libSPenBase.so", "base_dso"),
                      (RUNTIME_INPUTS / "libSPenPenCommon.so", "pencommon_dso"),
                      (RUNTIME_INPUTS / "libSPenFountainPen.so", "fountain_dso"),
                      (RUNTIME_INPUTS / "libSPenAirBrushPen.so", "airbrush_dso"),
                      (RUNTIME_INPUTS / "libSPenMarker3.so", "marker3_dso"),
                      (RUNTIME_INPUTS / "libc++_shared.so", "cxx_shared")):
        if not path.is_file() or digest(path) != PIN[key]:
            raise SystemExit(f"runtime input pin mismatch or missing input: {path}")
    ast.parse(Path(__file__).read_text())
    print(json.dumps({"status": "source-and-hash-preflight-only",
                      "apk_sha256": PIN["apk"], "pencil_sha256": PIN["pencil"],
                      "runtime_helper_sha256": PIN["runtime_helper"],
                      "native_bitmap_reference_sha256": PIN["brush_canvas_evidence"],
                      "addpoint_signature": "SPen::PencilStrokeDrawableRTV1::AddPoint(SPen::Vector3<float>, float)",
                      "addpoint_abi": ["x0=this", "s0/s1/s2=Vector3<float>", "s3=float"]},
                     sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--preflight", action="store_true")
    mode.add_argument("--capture", action="store_true")
    parser.add_argument("--rand-values", default=None,
                        help="optional forced rand() results; omitting this uses recorded host libc rand")
    parser.add_argument("--initial-seed", type=lambda value: int(value, 0),
                        help="explicit seed for the declared host-libc profile before native calls")
    parser.add_argument("--dispatch-through", type=int, default=9,
                        help="run the source-verified retained native task prefix through this sequence (0..9)")
    parser.add_argument("--output", type=Path, default=None,
                        help="optional path for the complete capture/failure JSON; stdout is always emitted")
    args = parser.parse_args()
    preflight()
    if args.preflight:
        return
    if args.initial_seed is None or not 0 <= args.initial_seed <= 0xFFFFFFFF:
        raise SystemExit("--capture requires --initial-seed in the uint32 range")
    if not 0 <= args.dispatch_through <= 9:
        raise SystemExit("--dispatch-through must be in the source-audited range 0..9")
    random_values = None
    if args.rand_values is not None:
        random_values = [int(item, 0) for item in args.rand_values.split(",") if item.strip()]
        if not random_values or any(not 0 <= item <= 0x7FFFFFFF for item in random_values):
            raise SystemExit("--rand-values must contain one or more nonnegative int32 results")

    sys.path.insert(0, str(HELPERS))
    sys.path.insert(0, str(ROOT / "scratch/apk-analysis-runtime/python"))
    import native_drawing_runtime
    import elf_plt
    import airbrush_texture_native as at
    import inkpen_paint_native as ip
    import fountain_native as fn
    from unicorn import UC_HOOK_CODE, UC_HOOK_MEM_INVALID, UC_HOOK_MEM_WRITE
    from unicorn import arm64_const as R

    rt = native_drawing_runtime.create_runtime()
    p, env = rt.p, rt.env
    phase = ["runtime_setup"]
    # These observers are installed before Renderer initialization so an
    # initialization-time texture call cannot observe unbound capture state.
    pencil_settextures_entries = []
    pencil_array_new_calls = []
    pencil_native_array_allocator_calls = []
    pencil_array_allocations = []
    pencil_bitmap_update_events = []
    graphics_subbitmap_update_events = []
    pencil_texture_create_events = []
    renderer_texture_update_events = []
    pending_texture_create_returns = {}
    pencil_texture_allocation_events = []
    pencil_mesa_uploads = []
    pixel_store_events = []
    draw_pixel_evidence = []
    active_texture_rt = [0]
    pending_pencil_array_allocations = {}

    def allocation_owner_of(address):
        for base, size, *_rest in reversed(p._newlog):
            if base <= address < base + size:
                return {"base": hex(base), "size": int(size), "offset": hex(address - base)}
        return None

    # The existing Fountain NativeFountain host callback implements the exact
    # operator new[] service as p.alloc(size), but unlike the separate
    # operator new(unsigned long) callback it does not append to p._newlog.
    # Wrap that existing allocator after it returns so owner checks can refer
    # to the returned raw allocation span; do not replace its allocation logic.
    native_operator_new_array = p.callbacks.get("operator new[](unsigned long)")
    if not callable(native_operator_new_array):
        raise RuntimeError("pinned host runtime lacks the existing operator new[] callback")
    def trace_native_operator_new_array():
        requested = p.x(0)
        import_pc = p.u.reg_read(R.UC_ARM64_REG_PC)
        caller_lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        native_operator_new_array()
        pointer = p.x(0)
        # p.alloc zeroes exactly requested bytes and advances the bump heap by
        # ceil(size/16)*16. _newlog is observational bookkeeping only.
        p._newlog.append((pointer, requested))
        pencil_native_array_allocator_calls.append({
            "import_pc": hex(import_pc), "import_symbol": p.plt.get(import_pc),
            "caller_lr": hex(caller_lr), "requested_bytes": requested,
            "returned_pointer": hex(pointer),
            "recorded_raw_span": {"base": hex(pointer), "size": requested, "offset": "0x0"},
            "allocator": "pinned Fountain NativeFountain operator new[] callback -> p.alloc(requested); callback behavior retained",
            "phase": phase[0]})
        if caller_lr == PENCIL_BASE + PENCIL_ARRAY_NEW_CALL_RETURN_RVA:
            if requested != PENCIL_TEXTURE_RGBA8_BYTES or not pointer:
                raise RuntimeError("Pencil source operator new[] callback returned the wrong request or null pointer")
    p.callbacks["operator new[](unsigned long)"] = trace_native_operator_new_array

    native_events = []
    add_calls = []
    pencil_drawpoint_state = []
    pencil_data_owner_readbacks = []
    smpath_call_entries = []
    smpath_call_returns = []
    pending_smpath_returns = {}
    pending_drawpoint_returns = {}
    native_import_events = []
    native_call_attempts = []
    strncpy_calls = []
    invalid_memory_events = []
    symbols_by_address = {}
    return_watch_by_address = {}
    pending_native_returns = {}
    native_return_events = []

    def refresh_symbol_index():
        symbols_by_address.clear()
        for symbol_name, symbol_address in p.syms.items():
            symbols_by_address.setdefault(symbol_address, []).append(symbol_name)

    def register_state(u):
        return {
            "pc": hex(u.reg_read(R.UC_ARM64_REG_PC)),
            "lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
            "sp": hex(u.reg_read(R.UC_ARM64_REG_SP)),
            "x0_x7": {f"x{i}": hex(u.reg_read(getattr(R, f"UC_ARM64_REG_X{i}")))
                      for i in range(8)},
            "s0_s7_bits": {f"s{i}": f"{u.reg_read(getattr(R, f'UC_ARM64_REG_S{i}')) & 0xffffffff:08x}"
                           for i in range(8)},
        }

    def nearest_symbol(address):
        candidates = [(entry, names) for entry, names in symbols_by_address.items()
                      if entry <= address]
        if not candidates:
            return None
        entry, names = max(candidates, key=lambda row: row[0])
        if address - entry > 0x4000:
            return None
        return {"names": names[:8], "entry": hex(entry), "offset": hex(address - entry)}

    def early_native_trace(u, address, _size, _data):
        names = symbols_by_address.get(address)
        if names:
            native_events.append({"pc": hex(address), "symbols": names[:8],
                                  "cpu": register_state(u), "phase": phase[0]})
            if len(native_events) > 256:
                del native_events[:-256]
        watched_name = return_watch_by_address.get(address)
        if watched_name:
            return_lr = u.reg_read(R.UC_ARM64_REG_LR)
            pending_native_returns.setdefault(return_lr, []).append({
                "symbol": watched_name, "entry_pc": hex(address),
                "caller_lr": hex(return_lr), "phase": phase[0],
                "entry_cpu": register_state(u),
            })
        returned = pending_native_returns.pop(address, [])
        for record in returned:
            native_return_events.append({**record, "return_pc": hex(address),
                "return_x0": hex(u.reg_read(R.UC_ARM64_REG_X0)),
                "return_cpu": register_state(u)})
            if len(native_return_events) > 256:
                del native_return_events[:-256]
        import_name = p.plt.get(address)
        if import_name:
            native_import_events.append({"pc": hex(address), "symbol": import_name,
                "caller_lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
                "cpu": register_state(u), "phase": phase[0]})
            if len(native_import_events) > 128:
                del native_import_events[:-128]

    def early_invalid_memory(u, access, address, size, value, _data):
        def safe_memory(address_to_read, length):
            try:
                return bytes(u.mem_read(address_to_read, length)).hex()
            except Exception:
                return None
        state = register_state(u)
        lr = u.reg_read(R.UC_ARM64_REG_LR)
        call_insn_hex = safe_memory(max(0, lr - 4), 4)
        branch_register = None
        if call_insn_hex:
            call_insn = int.from_bytes(bytes.fromhex(call_insn_hex), "little")
            if call_insn & 0xFFFFFC1F == 0xD63F0000:
                rn = (call_insn >> 5) & 0x1F
                if rn < 31:
                    branch_register = {"name": f"x{rn}",
                        "value": hex(u.reg_read(getattr(R, f"UC_ARM64_REG_X{rn}")))}
        invalid_memory_events.append({
            "access": int(access),
            "access_name": {19: "read_unmapped", 20: "write_unmapped",
                            21: "fetch_unmapped"}.get(int(access), "other_invalid_access"),
            "address": hex(address), "size": int(size), "value": hex(value),
            "cpu": state,
            "pc_nearest_symbol": nearest_symbol(u.reg_read(R.UC_ARM64_REG_PC)),
            "lr_nearest_symbol": nearest_symbol(lr),
            "lr_callsite_instruction_at_lr_minus_4": call_insn_hex,
            "unresolved_indirect_target_register": branch_register,
            "native_caller_code_window_lr_minus_256_to_plus_16": safe_memory(max(0, lr - 0x100), 0x110),
            "last_native_events": native_events[-64:],
            "last_native_import_events": native_import_events[-32:],
        })
        return False

    refresh_symbol_index()
    p.u.hook_add(UC_HOOK_CODE, early_native_trace)
    p.u.hook_add(UC_HOOK_MEM_INVALID, early_invalid_memory)

    def strncpy_callback():
        destination, source, count = p.x(0), p.x(1), p.x(2)
        import_pc = p.u.reg_read(R.UC_ARM64_REG_PC)
        caller_lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        event = {
            "import_symbol": p.plt.get(import_pc), "import_pc": hex(import_pc),
            "caller_lr": hex(caller_lr), "caller_symbol": nearest_symbol(caller_lr),
            "phase": phase[0], "typed_abi": {"x0": "char* destination", "x1": "const char* source",
                                               "x2": "size_t n", "x0_return": "destination"},
            "destination": hex(destination), "source": hex(source), "n": count,
            "nuls_padded_per_strncpy": True,
        }
        strncpy_calls.append(event)
        native_import_events.append({"pc": hex(import_pc), "symbol": event["import_symbol"],
            "caller_lr": hex(caller_lr), "caller_symbol": event["caller_symbol"],
            "phase": phase[0], "cpu_before": register_state(p.u), "callback": "typed_strncpy"})
        if count > 1024 * 1024:
            raise RuntimeError(f"strncpy count exceeds 1 MiB safety bound: {count}")
        if count and (not destination or not source):
            raise RuntimeError(
                f"strncpy nonzero count requires nonnull pointers: dest={destination:#x}, src={source:#x}, n={count}")
        written = bytearray()
        nul_found = False
        for index in range(count):
            value = p.u.mem_read(source + index, 1)[0]
            written.append(value)
            if value == 0:
                nul_found = True
                written.extend(bytes(count - index - 1))
                break
        if len(written) < count:
            written.extend(bytes(count - len(written)))
        nul_index = next((index for index, value in enumerate(written) if value == 0), None)
        if count:
            p.u.mem_write(destination, bytes(written))
        event.update({
            "source_bytes_before_first_nul_hex": bytes(written[:nul_index]).hex()
                if nul_index is not None else bytes(written).hex(),
            "nul_found_within_n": nul_found,
            "nul_padding_bytes": (count - (nul_index + 1)) if nul_found else 0,
            "written_bytes_hex": bytes(written).hex(),
        })
        p.x(0, destination)

    p.callbacks["strncpy"] = strncpy_callback
    for import_name in p.plt.values():
        if import_name.split("@", 1)[0] == "strncpy":
            p.callbacks[import_name] = strncpy_callback

    def run_init_captured(path, base):
        phase[0] = f"native_init:{path.name}"
        native_call_attempts.append({"symbol": f"init_array:{path.name}", "entry_pc": None,
                                     "phase": phase[0], "status": "running"})
        try:
            rt.run_init(path, base)
        except Exception as exc:
            state = register_state(p.u)
            report = {
                "schema": "sdocx-old-pencil-native-call-diagnostic.v6",
                "status": "native_call_failed_with_diagnostic",
                "scope": "Native initializer failure recorded before Drawing; no unresolved target is mapped or replaced.",
                "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL),
                         "analysis_dso_sha256": digest(PENCIL_ANALYSIS)},
                "native_call": {"symbol": f"init_array:{path.name}", "phase": phase[0],
                    "status": "failed", "exception_type": type(exc).__name__,
                    "exception": str(exc), "terminal_cpu": state,
                    "terminal_pc_nearest_symbol": nearest_symbol(int(state["pc"], 16)),
                    "terminal_lr_nearest_symbol": nearest_symbol(int(state["lr"], 16))},
                "strncpy_calls": strncpy_calls,
                "recent_native_symbol_events": native_events[-128:],
                "recent_native_import_events": native_import_events[-96:],
                "recent_native_call_attempts": native_call_attempts[-32:],
                "invalid_memory_events": invalid_memory_events[-8:],
            }
            raise NativeCallDiagnostic(report, args.output) from exc
        native_call_attempts[-1].update({"status": "returned"})

    set_srand_name = "SPen::PenUtil::SetSrand(unsigned int)"
    set_srand_addr = p.syms.get(set_srand_name)
    set_srand_calls = []
    if set_srand_addr is None:
        raise RuntimeError("pinned PenCommon SetSrand symbol is missing")
    def trace_set_srand(u, address, _size, _data):
        if address == set_srand_addr:
            set_srand_calls.append({"phase": phase[0], "entry_pc": hex(address),
                "seed_w0_u32": u.reg_read(R.UC_ARM64_REG_W0),
                "caller_lr": hex(u.reg_read(R.UC_ARM64_REG_LR))})
    p.u.hook_add(UC_HOOK_CODE, trace_set_srand)
    # Map the pinned Renderer DSO and bring over only the existing Mesa/GLES
    # host callbacks. Pencil's GLV1 constructor depends on RendererFactory.
    renderer_ns = {"at": at, "ip": ip, "fn": fn, "ROOT": ROOT, "LIB": RUNTIME_INPUTS,
        "sys": sys, "os": os, "hashlib": hashlib, "struct": struct,
        "subprocess": subprocess, "re": re, "zlib": zlib, "C": C,
        "json": json, "base64": base64, "argparse": argparse, "Path": Path,
        "ARGS": argparse.Namespace(width=256, height=256, point_limit=0)}
    renderer_tree = ast.parse(RENDERER_ADAPTER.read_text())
    renderer_class = next(node for node in renderer_tree.body
                          if isinstance(node, ast.ClassDef) and node.name == "P")
    exec(compile(ast.Module(body=[renderer_class], type_ignores=[]),
                 "<existing Renderer host adapter>", "exec"), renderer_ns)
    adapter = renderer_ns["P"]()
    adapter.u = p.u
    # The extracted Renderer adapter was constructed with its own Uc heap.
    # Once its Uc member points at Drawing, use Drawing's single allocator.
    adapter_heap_before_handoff = int(getattr(adapter, "heap", 0))
    drawing_heap_before_handoff = int(getattr(p, "heap", 0))
    independent_adapter_alloc = adapter.alloc
    drawing_allocator = p.alloc
    adapter.alloc = drawing_allocator
    adapter_allocator_handoff = {
        "adapter_heap_before_handoff": hex(adapter_heap_before_handoff),
        "drawing_heap_before_handoff": hex(drawing_heap_before_handoff),
        "adapter_allocator_owner_before": "independent Renderer P adapter heap",
        "allocator_owner_after": "Drawing runtime p.alloc monotonic guest allocator",
        "shared_allocator_delegate_installed": adapter.alloc is drawing_allocator,
        "prior_allocator_retained_for_identity": independent_adapter_alloc is not adapter.alloc,
    }
    if (not adapter_allocator_handoff["shared_allocator_delegate_installed"]
            or independent_adapter_alloc is drawing_allocator):
        raise RuntimeError("Renderer adapter allocator was not handed to the Drawing runtime")
    adapter.syms.clear(); adapter.syms.update(p.syms)
    adapter.plt.clear(); adapter.plt.update(p.plt)
    adapter.extra_bases = {}
    renderer_base = 0xA000000
    adapter.map_extra("Renderer", 10)
    def resolve_renderer(name):
        if name in adapter.syms: return adapter.syms[name]
        demangled = subprocess.check_output(
            ["scratch/apk-analysis-runtime/binutils-aarch64/usr/bin/aarch64-linux-gnu-c++filt", "-n", name],
            text=True, env=env).strip()
        if demangled in adapter.syms: return adapter.syms[demangled]
        if name in rt.rawsyms: return rt.rawsyms[name]
        if demangled in rt.rawsyms: return rt.rawsyms[demangled]
        raise RuntimeError(f"unresolved Renderer import {name!r} / {demangled!r}")
    adapter.resolve_symbol = resolve_renderer
    adapter.load_extra_relocs()
    # The host adapter's capability object is a synthetic callback. Remove it
    # so the saved draw follows the pinned native RendererFactory route.
    adapter.callbacks.pop("SPen::RendererFactory::GetRendererDeviceCaps()", None)
    p.syms.update({name: address for name, address in adapter.syms.items()
                   if renderer_base <= address < renderer_base + 0x200000})
    p.plt.update({address: name for address, name in adapter.plt.items()
                  if renderer_base <= address < renderer_base + 0x200000})
    refresh_symbol_index()
    for name, callback in adapter.callbacks.items():
        if name.startswith(("gl", "egl")) or name in (
            "strstr", "strcmp", "strncmp", "memcmp", "memchr", "strlen",
            "__strlen_chk", "__strncpy_chk", "__strncpy_chk2", "crc32", "vsnprintf",
            "fopen", "unlink", "__android_log_print", "__errno", "getauxval",
            "__system_property_get", "SPen::RendererFactory::GetRendererDeviceCaps()",
            "SPen::RendererFactory::CreateGraphicsObject(unsigned int, SPen::PrimitiveType, SPen::VertexDescriptor const*, unsigned int, unsigned int)",
            "SPen::RendererFactory::CreateBlendStateObject(SPen::BlendStateDescriptor const&)"
        ):
            p.callbacks[name] = callback

    def install_gl_callback(name, callback):
        adapter.callbacks[name] = callback
        p.callbacks[name] = callback

    # Passive VBO source ledger. It snapshots actual guest upload bytes before
    # the existing adapter forwards them and remembers storage by the Mesa buffer
    # object name. It never binds or rewrites a GL object.
    native_vbo_buffer_events = []
    native_vbo_pointer_events = []
    native_vbo_enable_events = []
    native_vbo_draw_snapshots = []
    native_vbo_stores = {}
    V17_MAX_BUFFER_CAPTURE = 16 * 1024 * 1024
    def v17_buffer_binding(target):
        pname={0x8892:0x8894,0x8893:0x8895,0x8A11:0x8A28,
               0x8F36:0x8F36,0x8F37:0x8F37}.get(target)
        if pname is None:return None
        value=C.c_int(); gl_get_integer_vbo(pname,C.byref(value))
        return int(value.value)
    gl_get_integer_vbo = ip.cfunc(adapter.gles.gl,"glGetIntegerv",None,
        [C.c_uint,C.POINTER(C.c_int)])
    def v17_payload(pointer,size):
        if size<0 or size>V17_MAX_BUFFER_CAPTURE:
            raise RuntimeError(f"V17 buffer payload outside bounded capture: {size}")
        if not pointer or size==0:
            return {"status":"null_or_empty","guest_pointer":hex(pointer or 0),"byte_length":size,"raw_hex":""}
        raw=bytes(p.u.mem_read(pointer,size))
        if len(raw)!=size:raise RuntimeError(f"V17 short source-buffer read: {len(raw)}/{size}")
        result={"status":"captured_guest_source_bytes","guest_pointer":hex(pointer),"byte_length":size,
            "sha256":hashlib.sha256(raw).hexdigest()}
        if size<=65536:result["raw_hex"]=raw.hex()
        else:result.update({"data_encoding":"zlib+base64","data_base64":base64.b64encode(zlib.compress(raw,6)).decode("ascii")})
        return result
    def v17_payload_bytes(payload):
        if payload.get("status")!="captured_guest_source_bytes":return None
        if "raw_hex" in payload:return bytes.fromhex(payload["raw_hex"])
        return zlib.decompress(base64.b64decode(payload["data_base64"]))
    _v17_original_buffer_data=adapter.callbacks.get("glBufferData")
    if not callable(_v17_original_buffer_data):raise RuntimeError("V17 requires existing glBufferData forwarder")
    def v17_buffer_data():
        target,size_u,pointer,usage=[p.x(i) for i in range(4)]
        size=C.c_ssize_t(size_u).value
        if size<0 or size>V17_MAX_BUFFER_CAPTURE:raise RuntimeError(f"V17 glBufferData size out of bound: {size}")
        buffer=v17_buffer_binding(target)
        payload=v17_payload(pointer,size)
        # Keep the exact source store as delivered to the existing adapter.
        if buffer:
            source_bytes=v17_payload_bytes(payload)
            native_vbo_stores[buffer]={"size":size,"data":bytearray(source_bytes) if source_bytes is not None else None,
                "source":"glBufferData","generation":len(native_vbo_buffer_events)}
        row={"call":"glBufferData","target":target,"buffer_object":buffer,"size":size,"usage":usage,
            "payload":payload,"forwarding":"existing adapter callback; its retained ctypes source copy is forwarded to Mesa synchronously"}
        native_vbo_buffer_events.append(row)
        _v17_original_buffer_data()
    install_gl_callback("glBufferData",v17_buffer_data)
    _v17_original_buffer_sub_data=adapter.callbacks.get("glBufferSubData")
    gl_buffer_sub_data_native=ip.cfunc(adapter.gles.gl,"glBufferSubData",None,
        [C.c_uint,C.c_ssize_t,C.c_ssize_t,C.c_void_p])
    if callable(_v17_original_buffer_sub_data):
        def v17_buffer_sub_data():
            target=p.x(0);offset=C.c_ssize_t(p.x(1)).value;size=C.c_ssize_t(p.x(2)).value;pointer=p.x(3)
            if offset<0 or size<0 or size>V17_MAX_BUFFER_CAPTURE:raise RuntimeError(f"V17 glBufferSubData range invalid: offset={offset} size={size}")
            buffer=v17_buffer_binding(target);payload=v17_payload(pointer,size)
            _v17_original_buffer_sub_data()
            store=native_vbo_stores.get(buffer) if buffer else None
            patch_bytes=v17_payload_bytes(payload)
            if store is not None and store["data"] is not None and patch_bytes is not None and offset+size<=store["size"]:
                store["data"][offset:offset+size]=patch_bytes
            elif store is not None and size:store["data"]=None
            native_vbo_buffer_events.append({"call":"glBufferSubData","target":target,"buffer_object":buffer,
                "offset":offset,"size":size,"payload":payload,"forwarding":"existing adapter callback"})
        install_gl_callback("glBufferSubData",v17_buffer_sub_data)
    elif gl_buffer_sub_data_native is not None:
        def v17_buffer_sub_data():
            target=p.x(0);offset=C.c_ssize_t(p.x(1)).value;size=C.c_ssize_t(p.x(2)).value;pointer=p.x(3)
            if offset<0 or size<0 or size>V17_MAX_BUFFER_CAPTURE:raise RuntimeError(f"V17 glBufferSubData range invalid: offset={offset} size={size}")
            buffer=v17_buffer_binding(target);payload=v17_payload(pointer,size)
            raw=v17_payload_bytes(payload) or b""
            host=C.create_string_buffer(raw) if raw else None
            gl_buffer_sub_data_native(target,offset,size,C.cast(host,C.c_void_p) if host else None)
            store=native_vbo_stores.get(buffer) if buffer else None
            if store is not None and store["data"] is not None and payload["status"]=="captured_guest_source_bytes" and offset+size<=store["size"]:store["data"][offset:offset+size]=raw
            elif store is not None and size:store["data"]=None
            native_vbo_buffer_events.append({"call":"glBufferSubData","target":target,"buffer_object":buffer,
                "offset":offset,"size":size,"payload":payload,
                "forwarding":"typed Mesa GLES; exact guest bytes copied to host-owned ctypes buffer retained through synchronous call"})
        install_gl_callback("glBufferSubData",v17_buffer_sub_data)
    elif "glBufferSubData" in p.plt.values():
        raise RuntimeError("V17 native import requires glBufferSubData but typed Mesa GLES entrypoint is unavailable")
    _v17_original_attrib_pointer=adapter.callbacks.get("glVertexAttribPointer")
    if not callable(_v17_original_attrib_pointer):raise RuntimeError("V17 requires existing glVertexAttribPointer forwarder")
    def v17_vertex_attrib_pointer():
        values=[p.x(i) for i in range(6)]
        array_buffer=v17_buffer_binding(0x8892)
        row={"call":"glVertexAttribPointer","index":values[0],"size":values[1],"type":values[2],
            "normalized":bool(values[3]),"stride":values[4],"pointer_offset":hex(values[5]),
            "array_buffer_binding":array_buffer,"vao_binding":v17_gl_int(0x85B5)}
        native_vbo_pointer_events.append(row)
        _v17_original_attrib_pointer()
    v17_gl_int_fn=ip.cfunc(adapter.gles.gl,"glGetIntegerv",None,[C.c_uint,C.POINTER(C.c_int)])
    def v17_gl_int(pname):
        value=C.c_int();v17_gl_int_fn(pname,C.byref(value));return int(value.value)
    install_gl_callback("glVertexAttribPointer",v17_vertex_attrib_pointer)
    for _v17_name in ("glEnableVertexAttribArray","glDisableVertexAttribArray","glVertexAttribDivisor"):
        _v17_original=adapter.callbacks.get(_v17_name)
        if not callable(_v17_original):continue
        def v17_wrap_attribute_call(name,original):
            def callback():
                count=2 if name=="glVertexAttribDivisor" else 1
                values=[p.x(i) for i in range(count)]
                native_vbo_enable_events.append({"call":name,"values":values,"vao_binding":v17_gl_int(0x85B5)})
                original()
            return callback
        install_gl_callback(_v17_name,v17_wrap_attribute_call(_v17_name,_v17_original))
    v17_max_component_bytes={0x1400:1,0x1401:1,0x1402:2,0x1403:2,0x1404:4,0x1405:4,0x1406:4,0x140B:2,0x140C:4}
    v17_get_vertex_attrib_iv=ip.cfunc(adapter.gles.gl,"glGetVertexAttribiv",None,
        [C.c_uint,C.c_uint,C.POINTER(C.c_int)])
    v17_get_vertex_attrib_pointer=ip.cfunc(adapter.gles.gl,"glGetVertexAttribPointerv",None,
        [C.c_uint,C.c_uint,C.POINTER(C.c_void_p)])
    v17_get_program_iv=ip.cfunc(adapter.gles.gl,"glGetProgramiv",None,
        [C.c_uint,C.c_uint,C.POINTER(C.c_int)])
    v17_get_active_attrib=ip.cfunc(adapter.gles.gl,"glGetActiveAttrib",None,
        [C.c_uint,C.c_uint,C.c_int,C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_uint),C.c_void_p])
    v17_get_attrib_location=ip.cfunc(adapter.gles.gl,"glGetAttribLocation",C.c_int,[C.c_uint,C.c_char_p])
    def v17_query_attrib(index,pname):
        value=C.c_int();v17_get_vertex_attrib_iv(index,pname,C.byref(value));return int(value.value)
    def v17_vertex_input_snapshot(draw_args):
        mode,first,count,instances=draw_args
        program=v17_gl_int(0x8B8D);vao=v17_gl_int(0x85B5);array_buffer=v17_gl_int(0x8894);element_buffer=v17_gl_int(0x8895)
        active_count=C.c_int();v17_get_program_iv(program,0x8B89,C.byref(active_count))
        max_attribs=v17_gl_int(0x8869)
        if not 0<=active_count.value<=64 or not 0<=max_attribs<=32:raise RuntimeError(f"V17 GL attribute bounds invalid: active={active_count.value} max={max_attribs}")
        active=[]
        for index in range(active_count.value):
            length,size,kind=C.c_int(),C.c_int(),C.c_uint();name=C.create_string_buffer(256)
            v17_get_active_attrib(program,index,256,C.byref(length),C.byref(size),C.byref(kind),C.cast(name,C.c_void_p))
            if not 0<=length.value<256:raise RuntimeError(f"V17 active attribute name length invalid: {length.value}")
            raw=name.raw[:length.value];location=int(v17_get_attrib_location(program,raw+b"\0"))
            active.append({"index":index,"location":location,"name_bytes_hex":raw.hex(),"size":size.value,"type":hex(kind.value)})
        rows=[]
        for index in range(max_attribs):
            props={key:v17_query_attrib(index,pname) for key,pname in (
                ("enabled",0x8622),("size",0x8623),("stride",0x8624),("type",0x8625),
                ("normalized",0x886A),("buffer_object",0x889F),("divisor",0x88FE))}
            if not props["enabled"]:continue
            pointer=C.c_void_p();v17_get_vertex_attrib_pointer(index,0x8645,C.byref(pointer));offset=int(pointer.value or 0)
            component_bytes=v17_max_component_bytes.get(props["type"])
            if component_bytes is None or not 1<=props["size"]<=4:raise RuntimeError(f"V17 attribute component format unsupported: {props}")
            stride=props["stride"] or props["size"]*component_bytes
            fetch_indices=([i//props["divisor"] for i in range(instances)] if props["divisor"] else list(range(first,first+count)))
            store=native_vbo_stores.get(props["buffer_object"]);buf=store.get("data") if store else None
            fetches=[];status="source_buffer_bytes_unavailable"
            if buf is not None:
                status="ok"
                for fetch_index in fetch_indices:
                    start=offset+fetch_index*stride;end=start+props["size"]*component_bytes
                    if end>len(buf):status="fetch_outside_captured_buffer";fetches=[];break
                    raw=bytes(buf[start:end]);values=None
                    if props["type"]==0x1406:values=list(struct.unpack("<"+"f"*props["size"],raw))
                    fetches.append({"fetch_index":fetch_index,"byte_offset":start,"raw_hex":raw.hex(),"float_values":values})
            source_events=[{k:v for k,v in row.items() if k!="payload"} for row in native_vbo_buffer_events if row.get("buffer_object")==props["buffer_object"]]
            active_row=next((row for row in active if row["location"]==index),None)
            ptr_row=next((row for row in reversed(native_vbo_pointer_events) if row["index"]==index and row["vao_binding"]==vao),None)
            row={"index":index,"active_attribute":active_row,"properties":props,"pointer_offset":hex(offset),
                "pointer_call_owner":ptr_row,"effective_stride_bytes":stride,"fetch_indices":fetch_indices,
                "fetch_status":status,"fetches":fetches,"buffer_object":props["buffer_object"],
                "buffer_declared_size":store.get("size") if store else None,
                "buffer_generation":store.get("generation") if store else None,
                "buffer_event_history":source_events,
                "buffer_contents_sha256":hashlib.sha256(bytes(buf)).hexdigest() if buf is not None else None,
                "buffer_contents_hex":bytes(buf).hex() if buf is not None and len(buf)<=65536 else None,
                "buffer_contents_compressed_base64":base64.b64encode(zlib.compress(bytes(buf),6)).decode("ascii") if buf is not None and len(buf)>65536 else None}
            rows.append(row)
        return {"draw_args":{"mode":mode,"first":first,"count":count,"instance_count":instances},
            "current_program":program,"vao_binding":vao,"array_buffer_binding_at_draw":array_buffer,
            "element_array_buffer_binding_at_draw":element_buffer,"active_attributes":active,
            "enabled_attribute_arrays":rows,"buffer_upload_events":list(native_vbo_buffer_events),
            "attribute_pointer_events":list(native_vbo_pointer_events),"attribute_enable_divisor_events":list(native_vbo_enable_events),
            "query_method":"read-only direct Mesa GLES queries; buffer contents reconstructed only from captured guest glBufferData/SubData source bytes; no glGetBufferSubData and no GL binding mutation"}

    # Passive native shader/program observer, installed before native Renderer
    # initialization. Shader source uses the pinned Renderer import/callsite and
    # honors a NULL GLint* as NUL-terminated source (not an invented length).
    gl_program_events = {"shader_creates": [], "shader_sources": [],
        "shader_compiles": [], "program_creates": [], "shader_attachments": [], "program_links": [],
        "program_binaries": [], "program_binary_loads": [], "program_uses": []}
    shader_type_by_id = {}
    shader_source_raw_by_id = {}
    program_shaders = {}
    linked_program_by_id = {}
    gl_get_program_iv_observer = ip.cfunc(adapter.gles.gl, "glGetProgramiv", None,
        [C.c_uint, C.c_uint, C.POINTER(C.c_int)])
    def install_gl_callback(name, callback):
        adapter.callbacks[name] = callback
        p.callbacks[name] = callback
    def traced_create_shader():
        shader_type = p.x(0)
        original_create_shader()
        shader = p.x(0)
        shader_type_by_id[shader] = shader_type
        gl_program_events["shader_creates"].append({"shader": shader,
            "shader_type": shader_type, "caller_lr": hex(p.u.reg_read(R.UC_ARM64_REG_LR))})
    original_create_shader = adapter.callbacks["glCreateShader"]
    install_gl_callback("glCreateShader", traced_create_shader)
    original_shader_source = adapter.callbacks["glShaderSource"]
    def traced_shader_source():
        shader, count, strings_ptr, lengths_ptr = (p.x(i) for i in range(4))
        pc, lr = p.u.reg_read(R.UC_ARM64_REG_PC), p.u.reg_read(R.UC_ARM64_REG_LR)
        allowed = (pc == RENDERER_BASE + 0x65580 and p.plt.get(pc) == "glShaderSource"
            and lr in (RENDERER_BASE + 0x5BD7C, RENDERER_BASE + 0x5BDC0))
        if not allowed or count != 1:
            raise RuntimeError(f"V15 shader-source callsite/count mismatch: pc={pc:#x} lr={lr:#x} count={count}")
        stage = "vertex" if lr == RENDERER_BASE + 0x5BD7C else "fragment"
        expected_type = 0x8B31 if stage == "vertex" else 0x8B30
        if shader_type_by_id.get(shader) != expected_type:
            raise RuntimeError(f"V15 {stage} shader source does not match shader type: {shader_type_by_id.get(shader)!r}")
        source_ptr = p.get(strings_ptr, "Q")[0]
        if not source_ptr:
            raise RuntimeError("V15 glShaderSource passed null source pointer")
        explicit_length = p.get(lengths_ptr, "i")[0] if lengths_ptr else None
        if explicit_length is not None and explicit_length < 0:
            # GL treats a negative length as NUL-terminated, per glShaderSource.
            explicit_length = None
        if explicit_length is None:
            raw = bytearray()
            for offset in range(1 << 20):
                byte = bytes(p.u.mem_read(source_ptr + offset, 1))
                if byte == b"\0": break
                raw.extend(byte)
            else: raise RuntimeError("V15 shader source missing NUL within 1 MiB")
            terminator_read = offset + 1
            nul_terminated = True
        else:
            if explicit_length > (1 << 20): raise RuntimeError("V15 explicit shader length exceeds 1 MiB")
            raw = bytearray(p.u.mem_read(source_ptr, explicit_length))
            terminator_read, nul_terminated = explicit_length, False
        original_shader_source()
        decoded = bytes(raw).decode("utf-8", "strict")
        source_row = {"shader": shader, "stage": stage, "count": count,
            "lengths_pointer": hex(lengths_ptr) if lengths_ptr else None,
            "length_semantics": "NULL GLint pointer: NUL-terminated source" if not lengths_ptr else "explicit signed GLint length",
            "length_value": explicit_length, "source_pointer": hex(source_ptr),
            "source_hex": bytes(raw).hex(), "source_sha256": hashlib.sha256(raw).hexdigest(),
            "source_utf8": decoded, "terminator_read_bytes": terminator_read,
            "nul_terminated": nul_terminated, "pc": hex(pc), "lr": hex(lr)}
        shader_source_raw_by_id[shader] = bytes(raw)
        gl_program_events["shader_sources"].append(source_row)
    install_gl_callback("glShaderSource", traced_shader_source)
    original_compile_shader = adapter.callbacks["glCompileShader"]
    gl_get_shader_iv_observer = ip.cfunc(adapter.gles.gl, "glGetShaderiv", None,
        [C.c_uint, C.c_uint, C.POINTER(C.c_int)])
    def traced_compile_shader():
        shader = p.x(0)
        original_compile_shader()
        status = C.c_int()
        gl_get_shader_iv_observer(shader, 0x8B81, C.byref(status))
        gl_program_events["shader_compiles"].append({"shader": shader,
            "shader_type": shader_type_by_id.get(shader), "compile_status": bool(status.value),
            "source_sha256": hashlib.sha256(shader_source_raw_by_id[shader]).hexdigest()
                if shader in shader_source_raw_by_id else None})
    install_gl_callback("glCompileShader", traced_compile_shader)
    original_create_program = adapter.callbacks["glCreateProgram"]
    def traced_create_program():
        original_create_program(); program = p.x(0)
        program_shaders.setdefault(program, [])
        gl_program_events["program_creates"].append({"program": program})
    install_gl_callback("glCreateProgram", traced_create_program)
    original_attach_shader = adapter.callbacks["glAttachShader"]
    def traced_attach_shader():
        program, shader = p.x(0), p.x(1)
        original_attach_shader()
        program_shaders.setdefault(program, []).append(shader)
        gl_program_events["shader_attachments"].append({"program": program, "shader": shader})
    install_gl_callback("glAttachShader", traced_attach_shader)
    original_link_program = adapter.callbacks["glLinkProgram"]
    def traced_link_program():
        program = p.x(0); original_link_program()
        status, count = C.c_int(), C.c_int()
        gl_get_program_iv_observer(program, 0x8B82, C.byref(status))
        gl_get_program_iv_observer(program, 0x8B89, C.byref(count))
        if count.value < 0 or count.value > 32: raise RuntimeError(f"V15 active attrib count out of bounds: {count.value}")
        attached = list(program_shaders.get(program, []))
        row = {"program": program, "link_status": bool(status.value),
            "attached_shader_ids": attached,
            "shader_sources": [{"shader": sh, "shader_type": shader_type_by_id.get(sh),
                "source_sha256": hashlib.sha256(shader_source_raw_by_id[sh]).hexdigest(),
                "source_hex": shader_source_raw_by_id[sh].hex()}
                for sh in attached if sh in shader_source_raw_by_id]}
        gl_program_events["program_links"].append(row)
        linked_program_by_id[program] = row
    install_gl_callback("glLinkProgram", traced_link_program)
    original_get_binary = adapter.callbacks.get("glGetProgramBinary")
    if original_get_binary is not None:
        def traced_get_program_binary():
            program, capacity, length_ptr, format_ptr, output_ptr = [p.x(i) for i in range(5)]
            original_get_binary()
            length = p.get(length_ptr, "i")[0] if length_ptr else None
            fmt = p.get(format_ptr, "I")[0] if format_ptr else None
            raw = bytes(p.u.mem_read(output_ptr, length)) if output_ptr and length and length > 0 else b""
            gl_program_events["program_binaries"].append({"program": program,
                "capacity": capacity, "length_pointer": hex(length_ptr) if length_ptr else None,
                "format_pointer": hex(format_ptr) if format_ptr else None,
                "length": length, "format": fmt, "binary_hex": raw.hex(),
                "binary_sha256": hashlib.sha256(raw).hexdigest() if raw else hashlib.sha256(b"").hexdigest(),
                "linked_source_sha256": [x["source_sha256"] for x in linked_program_by_id.get(program, {}).get("shader_sources", [])]})
        install_gl_callback("glGetProgramBinary", traced_get_program_binary)
    gl_program_binary_native = ip.cfunc(adapter.gles.gl, "glProgramBinary", None,
        [C.c_uint, C.c_uint, C.c_void_p, C.c_int])
    def traced_program_binary():
        program, fmt, source_ptr, length = [p.x(i) for i in range(4)]
        if length < 0 or length > (1 << 20): raise RuntimeError(f"V15 glProgramBinary length out of bounds: {length}")
        raw = bytes(p.u.mem_read(source_ptr, length)) if source_ptr and length else b""
        gl_program_binary_native(program, fmt, C.c_void_p(source_ptr), C.c_int(length & 0xFFFFFFFF).value)
        status = C.c_int(); gl_get_program_iv_observer(program, 0x8B82, C.byref(status))
        gl_program_events["program_binary_loads"].append({"program": program,
            "format": fmt, "length": length, "binary_hex": raw.hex(),
            "binary_sha256": hashlib.sha256(raw).hexdigest(), "link_status_after": bool(status.value)})
    install_gl_callback("glProgramBinary", traced_program_binary)
    original_use_program = adapter.callbacks["glUseProgram"]
    def traced_use_program():
        program = p.x(0); original_use_program()
        gl_program_events["program_uses"].append({"program": program,
            "linked_source_sha256": [x["source_sha256"] for x in linked_program_by_id.get(program, {}).get("shader_sources", [])]})
    install_gl_callback("glUseProgram", traced_use_program)

    # Source-preserving uniform observer: records the exact guest bytes before
    # the existing adapter forwards each call to Mesa GLES. It does not set or
    # replace any uniform values.
    native_uniform_call_snapshots = []
    uniform_name_by_program_location = {}
    gl_get_integer_uniform_native = ip.cfunc(adapter.gles.gl, "glGetIntegerv", None,
        [C.c_uint, C.POINTER(C.c_int)])
    def current_program_id():
        value = C.c_int(); gl_get_integer_uniform_native(0x8B8D, C.byref(value))
        return int(value.value)
    original_get_uniform_location = adapter.callbacks["glGetUniformLocation"]
    def traced_get_uniform_location():
        program, name_ptr = p.x(0), p.x(1)
        name = adapter.cstr(name_ptr, 256).decode("utf-8", "strict")
        original_get_uniform_location()
        location = C.c_int(p.x(0) & 0xffffffff).value
        uniform_name_by_program_location[(program, location)] = name
        native_uniform_call_snapshots.append({"call":"glGetUniformLocation",
            "program":program,"name":name,"location":location,
            "pc":hex(p.u.reg_read(R.UC_ARM64_REG_PC)),
            "lr":hex(p.u.reg_read(R.UC_ARM64_REG_LR))})
    install_gl_callback("glGetUniformLocation", traced_get_uniform_location)
    def snapshot_float_pointer(pointer, count):
        if not pointer or not 0 <= count <= 256:
            raise RuntimeError(f"V16 uniform float pointer/count invalid: ptr={pointer:#x} count={count}")
        raw = bytes(p.u.mem_read(pointer, count * 4))
        vals = list(struct.unpack("<" + "f" * count, raw)) if count else []
        return raw, vals
    def wrap_uniform_matrix():
        original = adapter.callbacks["glUniformMatrix4fv"]
        def traced():
            loc, count, transpose, pointer = [p.x(i) for i in range(4)]
            if not 1 <= count <= 16:
                raise RuntimeError(f"V16 glUniformMatrix4fv count out of bounds: {count}")
            raw, values = snapshot_float_pointer(pointer, 16 * count)
            program = current_program_id()
            pc, lr = p.u.reg_read(R.UC_ARM64_REG_PC), p.u.reg_read(R.UC_ARM64_REG_LR)
            original()
            native_uniform_call_snapshots.append({"call":"glUniformMatrix4fv",
                "program":program,"location":C.c_int(loc & 0xffffffff).value,
                "uniform_name":uniform_name_by_program_location.get((program,C.c_int(loc & 0xffffffff).value)),
                "count":count,"transpose":transpose,"guest_pointer":hex(pointer),
                "raw_f32_le_hex":raw.hex(),"raw_f32_le_sha256":hashlib.sha256(raw).hexdigest(),
                "values_f32":values,"pc":hex(pc),"lr":hex(lr)})
        return traced
    install_gl_callback("glUniformMatrix4fv", wrap_uniform_matrix())
    def wrap_uniform_vector(name, components):
        original = adapter.callbacks[name]
        def traced():
            loc, count, pointer = p.x(0), p.x(1), p.x(2)
            if not 1 <= count <= 256:
                raise RuntimeError(f"V16 {name} count out of bounds: {count}")
            raw, values = snapshot_float_pointer(pointer, components * count)
            program = current_program_id(); pc, lr = p.u.reg_read(R.UC_ARM64_REG_PC), p.u.reg_read(R.UC_ARM64_REG_LR)
            original()
            native_uniform_call_snapshots.append({"call":name,"program":program,
                "location":C.c_int(loc & 0xffffffff).value,
                "uniform_name":uniform_name_by_program_location.get((program,C.c_int(loc & 0xffffffff).value)),
                "count":count,"guest_pointer":hex(pointer),"raw_f32_le_hex":raw.hex(),
                "raw_f32_le_sha256":hashlib.sha256(raw).hexdigest(),"values_f32":values,
                "pc":hex(pc),"lr":hex(lr)})
        return traced
    for uniform_name, components in (("glUniform4fv",4),("glUniform2fv",2)):
        if uniform_name in adapter.callbacks:
            install_gl_callback(uniform_name, wrap_uniform_vector(uniform_name, components))
    for uniform_name in ("glUniform4f", "glUniform1f", "glUniform1i"):
        original = adapter.callbacks[uniform_name]
        def make_scalar_uniform(name, forward):
            def traced():
                loc = C.c_int(p.x(0) & 0xffffffff).value
                program = current_program_id(); pc, lr = p.u.reg_read(R.UC_ARM64_REG_PC), p.u.reg_read(R.UC_ARM64_REG_LR)
                if name == "glUniform4f":
                    vals = [p.f(i) for i in range(4)]
                    raw = b"".join(struct.pack("<f", value) for value in vals)
                    event = {"values_f32":vals,"raw_f32_le_hex":raw.hex(),"raw_f32_le_sha256":hashlib.sha256(raw).hexdigest()}
                elif name == "glUniform1f":
                    value = p.f(0); raw = struct.pack("<f",value)
                    event = {"value_f32":value,"raw_f32_le_hex":raw.hex(),"raw_f32_le_sha256":hashlib.sha256(raw).hexdigest()}
                else:
                    event = {"value_i32":C.c_int(p.x(1)&0xffffffff).value}
                forward()
                native_uniform_call_snapshots.append({"call":name,"program":program,
                    "location":loc,"uniform_name":uniform_name_by_program_location.get((program,loc)),
                    **event,"pc":hex(pc),"lr":hex(lr)})
            return traced
        install_gl_callback(uniform_name, make_scalar_uniform(uniform_name, original))

    gl_pixel_store = ip.cfunc(adapter.gles.gl, "glPixelStorei", None,
        [C.c_uint, C.c_int])
    def forward_pixel_store():
        pname, value = p.x(0), C.c_int(p.x(1) & 0xFFFFFFFF).value
        gl_pixel_store(pname, value)
        pixel_store_events.append({"pname": pname, "value": value,
            "caller_lr": hex(p.u.reg_read(R.UC_ARM64_REG_LR)),
            "backend": "Mesa GLES"})
        adapter.gl_calls.append({"call": "glPixelStorei", "pname": pname,
                                 "value": value, "backend": "Mesa GLES"})
    p.callbacks["glPixelStorei"] = forward_pixel_store

    # Renderer::OpenGLRenderer::InitParameters must observe the actual current
    # Mesa context. Forward its typed capability queries and libc strtof ABI.
    egl_get_current_context = ip.cfunc(adapter.gles.egl, "eglGetCurrentContext", C.c_void_p, [])
    p.callbacks["eglGetCurrentContext"] = lambda: p.x(0, egl_get_current_context() or 0)
    renderer_caps_gl_integer_calls = []
    renderer_caps_strtof_calls = []
    gl_get_integer_native = ip.cfunc(adapter.gles.gl, "glGetIntegerv", None,
        [C.c_uint, C.POINTER(C.c_int)])
    def renderer_gl_get_integer():
        pname, output = p.x(0), p.x(1)
        count = 2 if pname == 0x0D3A else (4 if pname in (0x0BA2,0x0C10) else 1)
        values=(C.c_int*count)(); gl_get_integer_native(pname, values)
        p.u.mem_write(output, bytes(values))
        renderer_caps_gl_integer_calls.append({"enum":hex(pname),"count":count,
            "values":list(values),"backend":"typed current Mesa GLES"})
    def renderer_strtof():
        source, endptr_guest = p.x(0), p.x(1)
        lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        if lr != renderer_base + 0x4BF5C:
            raise RuntimeError(f"Renderer strtof callsite changed: {lr:#x}")
        raw=bytearray()
        for i in range(65536):
            byte=p.u.mem_read(source+i,1)[0]
            if not byte: break
            raw.append(byte)
        else: raise RuntimeError("Renderer strtof input lacks bounded NUL")
        numeric_locale=locale.setlocale(locale.LC_NUMERIC)
        if numeric_locale!="C": raise RuntimeError(f"native Renderer strtof locale is not pinned C: {numeric_locale}")
        host_libc.strtof.argtypes=[C.c_void_p,C.POINTER(C.c_void_p)]
        host_libc.strtof.restype=C.c_float
        host_buffer=C.create_string_buffer(bytes(raw)+b"\0")
        host_start=C.addressof(host_buffer); host_end=C.c_void_p()
        C.set_errno(0); value=host_libc.strtof(C.cast(host_buffer,C.c_void_p),C.byref(host_end))
        host_errno=C.get_errno()
        if host_end.value is None: raise RuntimeError("host strtof returned null endptr")
        consumed=int(host_end.value)-host_start
        if not 0<=consumed<=len(raw): raise RuntimeError("strtof endptr escaped copied input")
        if endptr_guest: p.put(endptr_guest,"Q",source+consumed)
        p.f(0,value)
        renderer_caps_strtof_calls.append({"source":hex(source),"source_hex":bytes(raw).hex(),
            "consumed":consumed,"endptr_guest":hex(endptr_guest) if endptr_guest else None,
            "endptr_value":hex(source+consumed) if endptr_guest else None,
            "host_libc":str(libc_path),"host_libc_sha256":HOST_LIBC_SHA256,
            "host_numeric_locale":numeric_locale,"host_errno":host_errno,"lr":hex(lr),"f0_bits":
                f"{struct.unpack('<I',struct.pack('<f',value))[0]:08x}"})
    p.callbacks["glGetIntegerv"] = renderer_gl_get_integer
    p.callbacks["strtof"] = renderer_strtof

    # Renderer::RasterizerState::SetScissorRect ends in a tail branch to this
    # import. The Graphics caller LR therefore remains at EnableClipRT+0x380.
    gl_scissor = ip.cfunc(adapter.gles.gl, "glScissor", None,
        [C.c_int, C.c_int, C.c_int, C.c_int])
    def signed_glint(register_index):
        return C.c_int(p.x(register_index) & 0xFFFFFFFF).value
    def validate_scissor_callsite(import_pc, caller_lr, import_name):
        if (import_pc != RENDERER_BASE + RENDERER_GL_SCISSOR_PLT_RVA
                or import_name != "glScissor"
                or caller_lr != GRAPHICS_BASE + GRAPHICS_ENABLE_CLIP_SCISSOR_RETURN_RVA):
            raise RuntimeError("glScissor did not arrive from the pinned Renderer SetScissorRect tail call and Graphics EnableClipRT caller")
    def forward_scissor():
        import_pc = p.u.reg_read(R.UC_ARM64_REG_PC)
        caller_lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        import_name = p.plt.get(import_pc)
        validate_scissor_callsite(import_pc, caller_lr, import_name)
        args = [signed_glint(i) for i in range(4)]
        error_before = int(adapter.gles.f["glGetError"]())
        gl_scissor(*args)
        error_after = int(adapter.gles.f["glGetError"]())
        event = {"call": "glScissor", "backend": "Mesa GLES",
            "args_signed_glint_xywh": args, "argument_abi": ["x0 GLint x", "x1 GLint y",
                "x2 GLint width", "x3 GLint height"],
            "import_pc": hex(import_pc), "caller_lr": hex(caller_lr),
            "renderer_tail_branch_rva": hex(RENDERER_SET_SCISSOR_RECT_BRANCH_RVA),
            "scissor_rect_entry_rva": hex(RENDERER_SET_SCISSOR_RECT_RVA),
            "graphics_caller_return_rva": hex(GRAPHICS_ENABLE_CLIP_SCISSOR_RETURN_RVA),
            "gl_error_before": error_before, "gl_error_after": error_after}
        adapter.gl_calls.append(event)
        if error_after != 0:
            raise RuntimeError(f"Mesa GLES glScissor produced GL error {error_after:#x}; boundary={event}")
    p.callbacks["glScissor"] = forward_scissor

    # The existing marker adapter's draw callback reads only a 256x256 GL_RED
    # window and labels it maskReadback. Replace that test-only observer with
    # the actual GLES draw plus an owned framebuffer query and bounded RGBA8
    # before/after readback at the native target dimensions.
    gl = adapter.gles.gl
    gl_get_integer = ip.cfunc(gl, "glGetIntegerv", None, [C.c_uint, C.POINTER(C.c_int)])
    gl_get_attachment = ip.cfunc(gl, "glGetFramebufferAttachmentParameteriv", None,
        [C.c_uint, C.c_uint, C.c_uint, C.POINTER(C.c_int)])
    gl_get_tex_level = ip.cfunc(gl, "glGetTexLevelParameteriv", None,
        [C.c_uint, C.c_int, C.c_uint, C.POINTER(C.c_int)])
    gl_get_renderbuffer = ip.cfunc(gl, "glGetRenderbufferParameteriv", None,
        [C.c_uint, C.c_uint, C.POINTER(C.c_int)])
    gl_bind_texture = ip.cfunc(gl, "glBindTexture", None, [C.c_uint, C.c_uint])
    gl_bind_renderbuffer = ip.cfunc(gl, "glBindRenderbuffer", None, [C.c_uint, C.c_uint])
    gl_get_sampler = ip.cfunc(gl, "glGetSamplerParameteriv", None,
        [C.c_uint, C.c_uint, C.POINTER(C.c_int)])
    gl_is_enabled = ip.cfunc(gl, "glIsEnabled", C.c_ubyte, [C.c_uint])
    gl_read_pixels = ip.cfunc(gl, "glReadPixels", None,
        [C.c_int, C.c_int, C.c_int, C.c_int, C.c_uint, C.c_uint, C.c_void_p])
    gl_draw_instanced = ip.cfunc(gl, "glDrawArraysInstanced", None,
        [C.c_uint, C.c_int, C.c_int, C.c_int])
    def queried_int(pname):
        out = C.c_int(); gl_get_integer(pname, C.byref(out)); return int(out.value)
    def queried_ints(pname, count):
        out = (C.c_int * count)(); gl_get_integer(pname, out); return [int(v) for v in out]
    def queried_attachment(attachment, pname):
        out = C.c_int(); gl_get_attachment(0x8D40, attachment, pname, C.byref(out)); return int(out.value)
    def texture_level_info(target, level):
        out = {}
        for key, pname in (("width", 0x1000), ("height", 0x1001), ("internal_format", 0x1003)):
            value = C.c_int(); gl_get_tex_level(target, level, pname, C.byref(value)); out[key] = int(value.value)
        return out
    def attached_color_target():
        object_type = queried_attachment(0x8CE0, 0x8CD0)
        object_name = queried_attachment(0x8CE0, 0x8CD1)
        info = {"attachment": "GL_COLOR_ATTACHMENT0", "object_type": object_type,
            "object_name": object_name, "framebuffer_status": int(adapter.gles.f["glCheckFramebufferStatus"](0x8D40))}
        if object_type == 0x1702 and object_name:
            level = queried_attachment(0x8CE0, 0x8CD2)
            cube_face = queried_attachment(0x8CE0, 0x8CD3)
            target = cube_face if cube_face else 0x0DE1
            binding_name = 0x8514 if cube_face else 0x8069
            old_binding = queried_int(binding_name)
            gl_bind_texture(0x8513 if cube_face else 0x0DE1, object_name)
            info.update({"texture_level": level, "cube_face": cube_face or None,
                **texture_level_info(target, level)})
            gl_bind_texture(0x8513 if cube_face else 0x0DE1, old_binding)
        elif object_type == 0x8D41 and object_name:
            old_binding = queried_int(0x8CA7)
            gl_bind_renderbuffer(0x8D41, object_name)
            for key, pname in (("width", 0x8D42), ("height", 0x8D43), ("internal_format", 0x8D44)):
                value=C.c_int(); gl_get_renderbuffer(0x8D41, pname, C.byref(value)); info[key]=int(value.value)
            gl_bind_renderbuffer(0x8D41, old_binding)
        return info
    def read_target_rgba(width, height):
        pack = {"alignment": queried_int(0x0D05), "row_length": queried_int(0x0D02),
            "skip_pixels": queried_int(0x0D04), "skip_rows": queried_int(0x0D03),
            "pixel_pack_buffer": queried_int(0x88ED)}
        if pack["row_length"] or pack["skip_pixels"] or pack["skip_rows"] or pack["pixel_pack_buffer"]:
            return {"status": "unsupported_pack_state", "pack_state": pack}
        if width <= 0 or height <= 0 or width * height > 16_777_216:
            return {"status": "target_dimensions_outside_capture_bound", "width": width, "height": height}
        pitch = ((width * 4 + pack["alignment"] - 1) // pack["alignment"]) * pack["alignment"]
        buf = C.create_string_buffer(pitch * height)
        gl_read_pixels(0, 0, width, height, 0x1908, 0x1401, C.cast(buf, C.c_void_p))
        raw = bytes(buf.raw)
        packed = zlib.compress(raw, 6)
        nonzero_pixels = sum(1 for y in range(height) for x in range(width)
            if any(raw[y*pitch + x*4:y*pitch + x*4 + 4]))
        samples = {}
        for label, x, y in (("bottom_left",0,0),("bottom_right",width-1,0),
                ("center",width//2,height//2),("top_left",0,height-1),("top_right",width-1,height-1)):
            off=y*pitch+x*4; samples[label]=list(raw[off:off+4])
        if len(packed) > 1_048_576:
            return {"status":"compressed_readback_exceeds_compact_limit", "width":width, "height":height,
                "row_pitch":pitch, "rgba_bytes":len(raw), "sha256":hashlib.sha256(raw).hexdigest(),
                "nonzero_pixels":nonzero_pixels, "samples":samples, "compressed_bytes":len(packed), "pack_state":pack}
        return {"status":"ok", "width":width, "height":height, "format":"GL_RGBA/GL_UNSIGNED_BYTE",
            "row_pitch":pitch, "rgba_bytes":len(raw), "sha256":hashlib.sha256(raw).hexdigest(),
            "nonzero_pixels":nonzero_pixels, "samples":samples, "data_encoding":"zlib+base64",
            "data_base64":base64.b64encode(packed).decode("ascii"), "compressed_bytes":len(packed),
            "pack_state":pack}
    def forward_draw_instanced():
        values=[p.x(i) for i in range(4)]
        gl_error_before=int(adapter.gles.f["glGetError"]())
        vertex_input_snapshot=v17_vertex_input_snapshot(values)
        native_vbo_draw_snapshots.append(vertex_input_snapshot)
        state={"framebuffer_draw":queried_int(0x8CA6), "viewport":queried_ints(0x0BA2,4),
            "scissor_enabled":bool(gl_is_enabled(0x0C11)), "scissor_box":queried_ints(0x0C10,4),
            "current_program":queried_int(0x8B8D), "active_texture":queried_int(0x84E0),
            "texture_2d":queried_int(0x8069), "sampler_binding":queried_int(0x8919),
            "color_write_mask":queried_ints(0x0C23,4)}
        target=attached_color_target()
        sampler_params={}
        if state["sampler_binding"]:
            for key,pname in (("min_filter",0x2801),("mag_filter",0x2800),("wrap_s",0x2802),("wrap_t",0x2803)):
                value=C.c_int(); gl_get_sampler(state["sampler_binding"],pname,C.byref(value)); sampler_params[key]=int(value.value)
        input_texture=texture_level_info(0x0DE1,0) if state["texture_2d"] else None
        query_error=int(adapter.gles.f["glGetError"]())
        pre=None
        if target.get("object_name") and target.get("framebuffer_status")==0x8CD5 and target.get("width",0)>0 and target.get("height",0)>0 and query_error==0:
            pre=read_target_rgba(target["width"],target["height"])
        clear_events=[dict(event) for event in adapter.gl_calls if event.get("call") in ("glClear","glClearColor")]
        gl_draw_instanced(*values)
        draw_error=int(adapter.gles.f["glGetError"]())
        post=None
        post_target=attached_color_target()
        post_query_error=int(adapter.gles.f["glGetError"]())
        if post_target.get("object_name") and post_target.get("framebuffer_status")==0x8CD5 and post_target.get("width",0)>0 and post_target.get("height",0)>0 and post_query_error==0:
            post=read_target_rgba(post_target["width"],post_target["height"])
        read_error=int(adapter.gles.f["glGetError"]())
        draw_pixel_evidence.append({"phase":phase[0],"native_draw_call":{"call":"glDrawArraysInstanced",
            "mode":values[0],"first":values[1],"count":values[2],"instance_count":values[3]},
            "host_context":dict(adapter.gles.identity),"pre_draw_state":state,"input_texture_level0":input_texture,
            "input_sampler_parameters":sampler_params,"owned_color_target":target,"pre_draw_rgba8":pre,
            "post_draw_color_target":post_target,"post_draw_rgba8":post,"clear_events_before_draw":clear_events,
            "gl_error_before_queries":gl_error_before,"gl_error_after_queries":query_error,
            "gl_error_after_native_draw":draw_error,"gl_error_after_post_readback":read_error,
            "native_vertex_input_snapshot":vertex_input_snapshot,
            "evidence_is_complete":bool(pre and pre.get("status")=="ok" and post and post.get("status")=="ok" and not gl_error_before and not query_error and not draw_error and not read_error)})
    p.callbacks["glDrawArraysInstanced"] = forward_draw_instanced

    gl_tex_subimage = ip.cfunc(adapter.gles.gl, "glTexSubImage2D", None,
        [C.c_uint, C.c_int, C.c_int, C.c_int, C.c_int, C.c_int,
         C.c_uint, C.c_uint, C.c_void_p])
    def mesa_integer(pname):
        fn = ip.cfunc(adapter.gles.gl, "glGetIntegerv", None,
                      [C.c_uint, C.POINTER(C.c_int)])
        value = C.c_int()
        fn(pname, C.byref(value))
        return int(value.value)

    def pencil_texture_subimage():
        sp = p.u.reg_read(R.UC_ARM64_REG_SP)
        pixels = p.get(sp, "Q")[0]
        target, level, xoff, yoff = [p.x(i) for i in range(4)]
        width, height, fmt, pixel_type = [p.x(i) for i in range(4, 8)]
        import_pc = p.u.reg_read(R.UC_ARM64_REG_PC)
        caller_lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        if (import_pc != RENDERER_BASE + RENDERER_GL_SUBIMAGE_PLT_RVA
                or caller_lr != RENDERER_BASE + RENDERER_GL_SUBIMAGE_RETURN_RVA
                or p.plt.get(import_pc) != "glTexSubImage2D"):
            raise RuntimeError("Pencil texture upload did not use pinned Renderer glTexSubImage2D callsite")
        if (target, level, xoff, yoff, width, height, fmt, pixel_type) != (
                0x0DE1, 0, 0, 0, PENCIL_TEXTURE_WIDTH, PENCIL_TEXTURE_HEIGHT,
                0x1908, 0x1401):
            raise RuntimeError("native Pencil source upload tuple differs from pinned 144x144 RGBA8 route")
        source = bytes(p.u.mem_read(pixels, PENCIL_TEXTURE_RGBA8_BYTES))
        source_owner = allocation_owner_of(pixels)
        if not source_owner or int(source_owner["size"]) - int(source_owner["offset"], 16) < len(source):
            raise RuntimeError("Pencil upload source is not wholly owned by a recorded native allocation")
        source_owner_row = next((row for row in reversed(pencil_array_allocations)
            if row.get("buffer") == hex(pixels) and row.get("allocation_owner") == source_owner), None)
        if not source_owner_row:
            raise RuntimeError("Pencil upload pointer is not the exact setTextures operator-new[] source allocation")
        texture_update = next((row for row in reversed(renderer_texture_update_events)
            if row.get("pixel_pointer") == hex(pixels)), None)
        bitmap_update = next((row for row in reversed(pencil_bitmap_update_events)
            if row.get("pixel_pointer") == hex(pixels)), None)
        subbitmap_update = next((row for row in reversed(graphics_subbitmap_update_events)
            if row.get("pixel_pointer") == hex(pixels)), None)
        if not texture_update or not bitmap_update or not subbitmap_update:
            raise RuntimeError("Pencil upload lacks the native Pencil -> SPTextureBitmap -> SPSubBitmapRT -> TextureObject source chain")
        if (bitmap_update.get("caller_lr") != hex(PENCIL_BASE + PENCIL_BITMAP_UPDATE_CALL_RETURN_RVA)
                or bitmap_update.get("stride_argument") != 0
                or subbitmap_update.get("caller_lr") != hex(GRAPHICS_BASE + GRAPHICS_SUBBITMAP_UPDATE_RETURN_RVA)
                or subbitmap_update.get("stride_argument") != 0
                or texture_update.get("caller_lr") != hex(GRAPHICS_BASE + GRAPHICS_SUBBITMAP_UPDATE_RETURN_RVA)
                or texture_update.get("stride_argument") != 0):
            raise RuntimeError("native Pencil source stride or Graphics upload call chain differs from source witness")
        if (texture_update.get("texture_width") != width
                or texture_update.get("texture_height") != height
                or texture_update.get("format_target") != target
                or texture_update.get("GetWidth_return") != width
                or texture_update.get("GetHeight_return") != height
                or texture_update.get("gl_format_index") != 2
                or texture_update.get("gl_type_index") != 6):
            raise RuntimeError(f"Renderer TextureObject live fields/getters/format-index do not match Pencil upload: {texture_update}")
        create_record = next((row for row in reversed(pencil_texture_create_events)
            if row.get("texture_object") == texture_update.get("texture_object")), None)
        if not create_record:
            raise RuntimeError("Pencil upload texture object has no captured native TextureObject::CreateTexture owner")
        created_layout = create_record.get("object_layout_after_create", {})
        if (create_record.get("object_allocation_owner_after_create")
                != texture_update.get("texture_object_allocation")
                or created_layout.get("target_enum_at_plus_40") != target
                or created_layout.get("texture_id_at_plus_44") != texture_update.get("texture_id")
                or created_layout.get("width_at_plus_64") != width
                or created_layout.get("height_at_plus_68") != height
                or created_layout.get("gl_format_index_at_plus_76") != 2
                or created_layout.get("gl_type_index_at_plus_80") != 6):
            raise RuntimeError(f"native TextureObject::CreateTexture allocation/layout does not match upload: {create_record}")
        gl_state = adapter.gl_state()
        native_texture_id = texture_update.get("texture_id")
        if target != 0x0DE1 or gl_state.get("texture2d") != native_texture_id:
            raise RuntimeError(f"Mesa bound texture target/id differs from the native TextureObject: target={target:#x}, state={gl_state}, native_id={native_texture_id}")
        unpack_row_length = mesa_integer(0x0CF2)
        unpack_alignment = mesa_integer(0x0CF5)
        unpack_skip_rows = mesa_integer(0x0CF3)
        unpack_skip_pixels = mesa_integer(0x0CF4)
        unpack_buffer = mesa_integer(0x88EF)
        try:
            unpack_layout = tightly_packed_rgba8_unpack_layout(width, height,
                unpack_alignment, unpack_row_length, unpack_skip_rows,
                unpack_skip_pixels, unpack_buffer)
        except ValueError as exc:
            raise RuntimeError(f"Mesa unpack state cannot describe the exact Pencil client RGBA8 span: {exc}; state={{'row_length': {unpack_row_length}, 'alignment': {unpack_alignment}, 'skip_rows': {unpack_skip_rows}, 'skip_pixels': {unpack_skip_pixels}, 'buffer': {unpack_buffer}}}") from exc
        row_stride = unpack_layout["row_stride_bytes"]
        required_bytes = unpack_layout["source_span_bytes"]
        if required_bytes != len(source):
            raise RuntimeError(f"Pencil source allocation does not cover the Mesa RGBA8 row span: {required_bytes} != {len(source)}")
        if (gl_state.get("texture2d") != native_texture_id
                or texture_update.get("texture_height") != height):
            raise RuntimeError("Mesa-bound texture does not match native TextureObject allocation dimensions/id")
        allocation = next((row for row in reversed(pencil_texture_allocation_events)
            if row.get("target") == target
            and row.get("width") == width and row.get("height") == height
            and row.get("format") == fmt and row.get("type") == pixel_type
            and row.get("internalFormat") == 0x8058
            and row.get("texture_id") == native_texture_id
            and not row.get("pixels_pointer")), None)
        if allocation is None:
            raise RuntimeError("Mesa has no matching native Pencil 144x144 RGBA8 texture allocation")
        before_error = adapter.gles.f["glGetError"]()
        source_buffer = C.create_string_buffer(source)
        gl_tex_subimage(target, level, xoff, yoff, width, height, fmt, pixel_type,
                        C.cast(source_buffer, C.c_void_p))
        after_error = adapter.gles.f["glGetError"]()
        upload = {"status": "mesa_upload_returned",
            "native_pencil_setTextures": source_owner_row,
            "native_texture_object": texture_update,
            "native_TextureObject_CreateTexture": create_record,
            "native_SPTextureBitmap_UpdateBitmap": bitmap_update,
            "native_SPSubBitmapRT_UpdateBitmap": subbitmap_update,
            "gles_callsite": {"import_pc": hex(import_pc), "caller_lr": hex(caller_lr),
                "symbol": p.plt.get(import_pc)},
            "arguments": {"target": target, "level": level, "offset": [xoff, yoff],
                "width": width, "height": height, "format": fmt,
                "type": pixel_type, "pixels": hex(pixels)},
            "source_allocation": source_owner,
            "source_bytes": len(source), "source_sha256": hashlib.sha256(source).hexdigest(),
            "source_zlib_base64": base64.b64encode(zlib.compress(source, 9)).decode("ascii"),
            "row_layout": {"native_stride_argument": 0, **unpack_layout,
                "mesa_unpack_row_length_pixels": unpack_row_length,
                "mesa_unpack_alignment": unpack_alignment,
                "mesa_pixel_unpack_buffer": unpack_buffer,
                "effective_row_stride_bytes": row_stride,
                "source_is_tightly_packed": unpack_layout["tightly_packed"]},
            "mesa_bound_state": gl_state,
            "mesa_texture_allocation": allocation,
            "mesa_gl_error_before": before_error, "mesa_gl_error_after": after_error,
            "backend": "actual host Mesa GLES upload"}
        pencil_mesa_uploads.append(upload)
        adapter.gl_calls.append({"call": "glTexSubImage2D", "backend": "Mesa GLES",
            "target": target, "width": width, "height": height,
            "format": fmt, "type": pixel_type, "bytes": len(source),
            "source_sha256": upload["source_sha256"], "mesa_gl_error_after": after_error})
        if before_error != 0 or after_error != 0:
            raise RuntimeError(f"Mesa rejected native Pencil texture upload: {before_error:#x}->{after_error:#x}")
    native_gl_tex_image = p.callbacks["glTexImage2D"]
    def observe_texture_allocation():
        args = [p.x(i) for i in range(8)]
        sp = p.u.reg_read(R.UC_ARM64_REG_SP)
        pixels_pointer = p.get(sp, "Q")[0]
        texture_id = adapter.gl_state().get("texture2d")
        caller_lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        native_gl_tex_image()
        pencil_texture_allocation_events.append({
            "target": args[0], "level": args[1], "internalFormat": args[2],
            "width": args[3], "height": args[4], "border": args[5],
            "format": args[6], "type": args[7],
            "pixels_pointer": hex(pixels_pointer) if pixels_pointer else None,
            "texture_id": texture_id, "caller_lr": hex(caller_lr),
            "mesa_error_after": adapter.gles.f["glGetError"](),
            "backend": "actual host Mesa GLES allocation"})
    p.callbacks["glTexImage2D"] = observe_texture_allocation
    p.callbacks["glTexSubImage2D"] = pencil_texture_subimage

    pencil_array_new_call_pc = PENCIL_BASE + PENCIL_ARRAY_NEW_CALL_RVA
    pencil_settextures_upload_call_pc = PENCIL_BASE + 0x2EAB0
    def pencil_texture_observer(u, address, _size, _data):
        create_returns = pending_texture_create_returns.pop(address, [])
        for create in create_returns:
            obj = int(create["texture_object"], 16)
            live = bytes(u.mem_read(obj, 96))
            create["create_return_pc"] = hex(address)
            create["object_allocation_owner_after_create"] = allocation_owner_of(obj)
            create["object_vptr_after_create"] = hex(p.get(obj, "Q")[0])
            create["object_layout_after_create"] = {
                **decode_renderer_texture_object_prefix(live), "prefix_96_hex": live.hex()}
            pencil_texture_create_events.append(create)
        if address == PENCIL_BASE + PENCIL_SETTEXTURES_RVA:
            receiver = p.x(0)
            width_argument, height_argument = p.x(1), p.x(2)
            cell_scale = p.get(receiver + 232, "I")[0]
            texture_width, texture_height = cell_scale * width_argument, cell_scale * height_argument
            pencil_settextures_entries.append({"receiver": hex(receiver),
                "width_argument": width_argument, "height_argument": height_argument,
                "cell_scale_this_plus_232": cell_scale,
                "derived_texture_dimensions": [texture_width, texture_height],
                "receiver_matches_active_sequence2_RT": p.x(0) == active_texture_rt[0],
                "phase": phase[0]})
            if (receiver != active_texture_rt[0] or width_argument != 48
                    or height_argument != 48 or cell_scale != 3
                    or (texture_width, texture_height) != (PENCIL_TEXTURE_WIDTH, PENCIL_TEXTURE_HEIGHT)):
                raise RuntimeError("native Pencil setTextures receiver, Init(48,48) inputs, cellScale, or derived source dimensions differ from the APK code path")
        elif address == pencil_array_new_call_pc:
            requested = p.x(0)
            enclosing_caller_lr = u.reg_read(R.UC_ARM64_REG_LR)
            active_entry = pencil_settextures_entries[-1] if pencil_settextures_entries else None
            pencil_array_new_calls.append({"call_pc": hex(address),
                "call_instruction_return_pc": hex(address + 4),
                "requested_bytes_x0": requested,
                "enclosing_caller_lr": hex(enclosing_caller_lr),
                "setTextures_receiver_x19": hex(p.x(19)),
                "setTextures_entry": active_entry, "phase": phase[0]})
            try:
                return_pc = validate_pencil_array_new_call(address, requested,
                                                            enclosing_caller_lr)
            except ValueError as exc:
                raise RuntimeError(f"Pencil setTextures allocation formula/callsite differs from 144x144 RGBA8: {exc}") from exc
            if (not active_entry or active_entry.get("receiver") != hex(p.x(19))
                    or active_entry.get("receiver") != hex(active_texture_rt[0])
                    or active_entry.get("derived_texture_dimensions") !=
                        [PENCIL_TEXTURE_WIDTH, PENCIL_TEXTURE_HEIGHT]):
                raise RuntimeError("Pencil operator-new[] is not owned by the active setTextures(48,48) source receiver")
            pending_pencil_array_allocations.setdefault(return_pc, []).append({
                "requested_bytes": requested, "call_pc": hex(address),
                "call_instruction_return_pc": hex(return_pc),
                "enclosing_caller_lr": hex(enclosing_caller_lr),
                "caller_function_rva": "0x2e9b4",
                "receiver": hex(p.x(19)), "phase": phase[0]})
        elif address == PENCIL_BASE + PENCIL_ARRAY_NEW_CALL_RETURN_RVA:
            pending = pending_pencil_array_allocations.pop(address, [])
            if not pending:
                raise RuntimeError("Pencil operator-new[] return has no exact source-guarded pre-BL allocation call")
            for row in pending:
                if row.get("call_instruction_return_pc") != hex(address):
                    raise RuntimeError("Pencil operator-new[] returned at a different PC than call_pc+4")
                pointer = p.x(0)
                owner = allocation_owner_of(pointer)
                allocator_return = next((entry for entry in reversed(pencil_native_array_allocator_calls)
                    if entry.get("returned_pointer") == hex(pointer)
                    and entry.get("requested_bytes") == row["requested_bytes"]
                    and entry.get("caller_lr") == hex(address)), None)
                try:
                    owner = validate_exact_raw_source_span(pointer, row["requested_bytes"], owner)
                except ValueError as exc:
                    raise RuntimeError(f"Pencil operator-new[] return is not the exact 82,944-byte source owner: {exc}") from exc
                if not allocator_return:
                    raise RuntimeError("Pencil operator-new[] return is not the exact 82,944-byte source owner")
                pencil_array_allocations.append({**row, "buffer": hex(pointer),
                    "allocation_owner": owner, "allocator_return_evidence": allocator_return,
                    "return_pc": hex(address)})
        elif address == pencil_settextures_upload_call_pc:
            source_pointer = p.x(1)
            owner = allocation_owner_of(source_pointer)
            allocation = next((row for row in reversed(pencil_array_allocations)
                if row.get("buffer") == hex(source_pointer)), None)
            if (not allocation or allocation.get("receiver") != hex(active_texture_rt[0])
                    or p.x(2) != 0 or not owner or owner != allocation["allocation_owner"]):
                raise RuntimeError("Pencil setTextures upload call does not use its exact packed native source allocation")
        elif address == GRAPHICS_BASE + GRAPHICS_TEXTURE_BITMAP_UPDATE_RVA:
            caller_lr = u.reg_read(R.UC_ARM64_REG_LR)
            pointer = p.x(1)
            owner = allocation_owner_of(pointer)
            allocation = next((row for row in reversed(pencil_array_allocations)
                if row.get("buffer") == hex(pointer)), None)
            row = {"source_object": hex(p.x(0)), "pixel_pointer": hex(pointer),
                "stride_argument": p.x(2), "caller_lr": hex(caller_lr),
                "source_object_allocation": allocation_owner_of(p.x(0)),
                "pixel_allocation": owner, "matches_Pencil_setTextures_new_array": bool(allocation),
                "phase": phase[0]}
            pencil_bitmap_update_events.append(row)
            if (not allocation or caller_lr != PENCIL_BASE + PENCIL_BITMAP_UPDATE_CALL_RETURN_RVA
                    or p.x(2) != 0):
                raise RuntimeError("SPTextureBitmap upload lacks the exact Pencil setTextures source/callsite")
        elif address == GRAPHICS_BASE + GRAPHICS_SUBBITMAP_RT_UPDATE_THUNK_RVA:
            row = {"receiver": hex(p.x(0)), "pixel_pointer": hex(p.x(1)),
                "stride_argument": p.x(2), "caller_lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
                "phase": phase[0]}
            graphics_subbitmap_update_events.append(row)
        elif address == RENDERER_BASE + RENDERER_TEXTURE_CREATE_RVA:
            obj, descriptor = p.x(0), p.x(1)
            caller_lr = u.reg_read(R.UC_ARM64_REG_LR)
            descriptor_prefix = bytes(u.mem_read(descriptor, 96))
            row = {"texture_object": hex(obj), "descriptor": hex(descriptor),
                "caller_lr": hex(caller_lr), "phase": phase[0],
                "object_allocation_owner_at_create_entry": allocation_owner_of(obj),
                "object_vptr_at_create_entry": hex(p.get(obj, "Q")[0]),
                "descriptor_prefix_96_hex": descriptor_prefix.hex(),
                "descriptor_sha256_96": hashlib.sha256(descriptor_prefix).hexdigest(),
                "object_prefix_96_before_create_hex": bytes(u.mem_read(obj, 96)).hex()}
            pending_texture_create_returns.setdefault(caller_lr, []).append(row)
        elif address == RENDERER_BASE + RENDERER_TEXTURE_UPDATE_RVA:
            obj = p.x(0)
            object_prefix = bytes(u.mem_read(obj, 96))
            object_layout = decode_renderer_texture_object_prefix(object_prefix)
            row = {"texture_object": hex(obj), "texture_object_allocation": allocation_owner_of(obj),
                "texture_vptr": hex(p.get(obj, "Q")[0]),
                "texture_id": object_layout["texture_id_at_plus_44"],
                "format_target": object_layout["target_enum_at_plus_40"],
                "texture_width": object_layout["width_at_plus_64"],
                "texture_height": object_layout["height_at_plus_68"],
                "width_field_offset": 64, "height_field_offset": 68,
                "gl_format_index": object_layout["gl_format_index_at_plus_76"],
                "gl_type_index": object_layout["gl_type_index_at_plus_80"],
                "gl_format_index_field_offset": 76, "gl_type_index_field_offset": 80,
                "object_layout": object_layout,
                "pixel_pointer": hex(p.x(1)), "stride_argument": p.x(2),
                "caller_lr": hex(u.reg_read(R.UC_ARM64_REG_LR)), "phase": phase[0]}
            renderer_texture_update_events.append(row)
        elif address == RENDERER_BASE + RENDERER_TEXTURE_GET_WIDTH_RETURN_RVA:
            obj = p.x(20)
            row = next((entry for entry in reversed(renderer_texture_update_events)
                if entry.get("texture_object") == hex(obj)
                and "GetWidth_return" not in entry), None)
            if row:
                row["GetWidth_return"] = p.x(0)
                row["GetWidth_return_pc"] = hex(address)
        elif address == RENDERER_BASE + RENDERER_TEXTURE_GET_HEIGHT_RETURN_RVA:
            obj = p.x(20)
            row = next((entry for entry in reversed(renderer_texture_update_events)
                if entry.get("texture_object") == hex(obj)
                and "GetHeight_return" not in entry), None)
            if row:
                row["GetHeight_return"] = p.x(0)
                row["GetHeight_return_pc"] = hex(address)
    p.u.hook_add(UC_HOOK_CODE, pencil_texture_observer)
    run_init_captured(RUNTIME_INPUTS / "libSPenRenderer.so", renderer_base)
    libc_path = next((path for path in (Path("/lib/x86_64-linux-gnu/libc.so.6"),
                                        Path("/usr/lib/x86_64-linux-gnu/libc.so.6"),
                                        Path("/lib64/libc.so.6")) if path.is_file()), None)
    if libc_path is None: raise RuntimeError("host glibc libc.so.6 was not found")
    libc_path = libc_path.resolve()
    host_libc = C.CDLL(str(libc_path), use_errno=True)
    host_libc.srand.argtypes = [C.c_uint]; host_libc.srand.restype = None
    host_libc.rand.argtypes = []; host_libc.rand.restype = C.c_int
    host_libc.gnu_get_libc_version.argtypes = []; host_libc.gnu_get_libc_version.restype = C.c_char_p
    libc_version = host_libc.gnu_get_libc_version().decode("ascii")
    host_libc.clock_gettime.argtypes = [C.c_int, C.c_void_p]
    host_libc.clock_gettime.restype = C.c_int
    if digest(libc_path) != HOST_LIBC_SHA256 or libc_version != "2.41":
        raise RuntimeError("host clock profile differs from the pinned glibc 2.41 service")
    clock_service_profile = {"service": "host glibc clock_gettime",
        "host_libc_path": str(libc_path), "host_libc_sha256": HOST_LIBC_SHA256,
        "host_glibc_version": libc_version,
        "target_abi": "int clock_gettime(int clockid, struct timespec *); x0=clockid, x1=timespec*, x0=int result",
        "target_timespec": "AArch64 little-endian int64 tv_sec followed by int64 tv_nsec",
        "source_callsite": "SPen::GetTimeStamp() at pinned Base RVA 0x9a1f0; return LR RVA 0x9a21c",
        "clock_id": 0, "clock_name": "CLOCK_REALTIME", "import_plt_rva": hex(CLOCK_GETTIME_PLT_RVA),
        "platform_scope": "host Linux, not Android device time"}
    class HostTimespec(C.Structure):
        _fields_ = [("tv_sec", C.c_int64), ("tv_nsec", C.c_int64)]
    host_libc.srand(args.initial_seed)
    rand_trace, rand_index, srand_trace, host_rng_calls = [], [0], [], [
        {"call": "harness_initial_srand", "seed_u32": args.initial_seed}]
    def srand_callback():
        seed = p.x(0) & 0xFFFFFFFF
        srand_trace.append(seed); rand_index[0] = 0
        host_rng_calls.append({"call": "native_srand_import", "seed_u32": seed,
            "caller_lr": hex(p.u.reg_read(R.UC_ARM64_REG_LR)), "phase": phase[0]})
        host_libc.srand(seed)
    def rand_callback():
        caller_lr = hex(p.u.reg_read(R.UC_ARM64_REG_LR))
        if random_values is None:
            value = int(host_libc.rand())
            host_rng_calls.append({"call": "host_libc_rand", "return_i32": value,
                "caller_lr": caller_lr, "phase": phase[0]})
        else:
            if rand_index[0] >= len(random_values):
                raise RuntimeError("forced --rand-values exhausted")
            value = random_values[rand_index[0]]
            host_rng_calls.append({"call": "forced_rand", "return_i32": value,
                "index": rand_index[0], "caller_lr": caller_lr, "phase": phase[0]})
            rand_index[0] += 1
        rand_trace.append({"value": value, "index": len(rand_trace)})
        p.x(0, value)
    p.callbacks["srand"] = srand_callback; p.callbacks["srand@LIBC"] = srand_callback
    p.callbacks["rand"] = rand_callback; p.callbacks["rand@LIBC"] = rand_callback
    clock_gettime_calls = []
    def clock_gettime_callback():
        clock_id = C.c_int(p.x(0) & 0xFFFFFFFF).value
        target_timespec = p.x(1)
        caller_lr = p.u.reg_read(R.UC_ARM64_REG_LR)
        import_pc = p.u.reg_read(R.UC_ARM64_REG_PC)
        import_name = p.plt.get(import_pc)
        stack_low, stack_high = 0x20000000, 0x20100000
        try:
            validate_clock_gettime_callsite(clock_id, target_timespec, caller_lr,
                                            stack_low, stack_high, import_pc, import_name)
        except ValueError as exc:
            clock_gettime_calls.append({"status": "rejected_unpinned_callsite",
                "clock_id": clock_id, "timespec": hex(target_timespec),
                "import_pc": hex(import_pc), "import_name": import_name,
                "caller_lr": hex(caller_lr), "phase": phase[0], "guard_error": str(exc)})
            raise RuntimeError(f"clock_gettime source guard failed: {exc}") from exc
        host_timespec = HostTimespec()
        C.set_errno(0)
        result = int(host_libc.clock_gettime(clock_id, C.byref(host_timespec)))
        host_errno = C.get_errno() if result else 0
        target_bytes = encode_target_timespec(int(host_timespec.tv_sec),
                                              int(host_timespec.tv_nsec))
        p.u.mem_write(target_timespec, target_bytes)
        event = {"status": "returned", "clock_id": clock_id,
            "clock_name": "CLOCK_REALTIME", "timespec_pointer": hex(target_timespec),
            "target_timespec_layout": "AArch64 struct timespec { int64 tv_sec; int64 tv_nsec; }",
            "tv_sec": int(host_timespec.tv_sec), "tv_nsec": int(host_timespec.tv_nsec),
            "target_timespec_bytes_hex": target_bytes.hex(), "return_i32": result,
            "errno": host_errno, "import_pc": hex(import_pc), "import_name": import_name,
            "caller_lr": hex(caller_lr), "caller_symbol": "SPen::GetTimeStamp()",
            "phase": phase[0], "service": "host glibc clock_gettime",
            "host_libc_path": str(libc_path), "host_libc_sha256": HOST_LIBC_SHA256,
            "host_glibc_version": libc_version}
        clock_gettime_calls.append(event)
        p.x(0, result)
    clock_name_aliases = [name for name in p.plt.values()
                          if name.split("@", 1)[0] == "clock_gettime"]
    if "clock_gettime" not in clock_name_aliases:
        raise RuntimeError("pinned Base DSO does not expose the expected clock_gettime PLT import")
    for name in set(clock_name_aliases):
        p.callbacks[name] = clock_gettime_callback

    lib_path = PENCIL
    raw = lib_path.read_bytes()
    phoff = struct.unpack_from("<Q", raw, 32)[0]
    phentsize, phnum = struct.unpack_from("<HH", raw, 54)
    extent = 0
    segments = []
    for i in range(phnum):
        row = struct.unpack_from("<II6Q", raw, phoff + i * phentsize)
        typ, flags, off, va, _pa, filesz, memsz, _align = row
        if typ == 1:
            extent = max(extent, va + memsz)
            segments.append((off, va, filesz, memsz))
    p.u.mem_map(PENCIL_BASE, (extent + 0xFFF) & ~0xFFF)
    for off, va, filesz, memsz in segments:
        if memsz:
            p.u.mem_write(PENCIL_BASE + va, raw[off:off + filesz])
            if memsz > filesz:
                p.u.mem_write(PENCIL_BASE + va + filesz, bytes(memsz - filesz))

    nm_demangled = subprocess.check_output(["nm", "-D", "-C", str(lib_path)], text=True, env=env)
    nm_raw = subprocess.check_output(["nm", "-D", str(lib_path)], text=True, env=env)
    defined = {}
    p.rtti_syms = {}
    for line in nm_demangled.splitlines():
        fields = line.strip().split(" ", 2)
        if len(fields) == 3 and fields[1] in ("T", "W"):
            p.syms[fields[2]] = PENCIL_BASE + int(fields[0], 16)
        elif len(fields) == 3 and fields[1] == "V" and fields[2].startswith("typeinfo for "):
            # Itanium RTTI exports are weak objects (`V`), distinct from the
            # function-only p.syms map. Keep them in a separate exact ELF map.
            p.rtti_syms[fields[2]] = PENCIL_BASE + int(fields[0], 16)
    for line in nm_raw.splitlines():
        fields = line.strip().split()
        if len(fields) == 3 and fields[1].upper() in ("T", "W", "D", "B", "R", "V"):
            defined[fields[2]] = int(fields[0], 16)
            rt.rawsyms.setdefault(fields[2], PENCIL_BASE + int(fields[0], 16))

    # Rebase this DSO's dynamic relocations against the already pinned Drawing,
    # PenCommon, Base, Model and libc++ runtime. Unsupported imports fail closed.
    shoff = struct.unpack_from("<Q", raw, 40)[0]
    shentsize, shnum, shstrndx = struct.unpack_from("<HHH", raw, 58)
    sections = [struct.unpack_from("<IIQQQQIIQQ", raw, shoff + i * shentsize)
                for i in range(shnum)]
    names_section = sections[shstrndx]
    section_names = raw[names_section[4]:names_section[4] + names_section[5]]
    by_name = {section_names[s[0]:section_names.find(b"\0", s[0])].decode(): s for s in sections}
    dynsym, dynstr = by_name[".dynsym"], by_name[".dynstr"]
    strings = raw[dynstr[4]:dynstr[4] + dynstr[5]]
    symbols = []
    for off in range(dynsym[4], dynsym[4] + dynsym[5], dynsym[9]):
        no, _info, _other, _ndx, value, _size = struct.unpack_from("<IBBHQQ", raw, off)
        end = strings.find(b"\0", no) if no else 0
        symbols.append((strings[no:end].decode() if no else "", value))
    unresolved_imports = []
    for secname in (".rela.dyn", ".rela.plt"):
        sec = by_name.get(secname)
        if not sec:
            continue
        for off in range(sec[4], sec[4] + sec[5], sec[9]):
            where, info, addend = struct.unpack_from("<QQq", raw, off)
            kind, index = info & 0xFFFFFFFF, info >> 32
            if kind == 0x403:
                target = PENCIL_BASE + addend
            elif kind in (0x401, 0x402, 0x101, 0x1025, 0x1026):
                symbol, value = symbols[index]
                target = (PENCIL_BASE + value if value else
                          rt.rawsyms.get(symbol, 0) or p.syms.get(symbol, 0))
                if target and kind in (0x401, 0x101):
                    target += addend
                if not target:
                    unresolved_imports.append({"symbol": symbol, "type": hex(kind), "relocation": hex(where)})
                    target = 0
            else:
                raise RuntimeError(f"unsupported Pencil relocation type {kind:#x} at {where:#x}")
            p.u.mem_write(PENCIL_BASE + where, struct.pack("<Q", target & 0xFFFFFFFFFFFFFFFF))
    for off, symbol in elf_plt.resolve(lib_path).items():
        pretty = subprocess.check_output(["c++filt", "-n", symbol], text=True, env=env).strip() if symbol.startswith("_Z") else symbol
        p.plt[PENCIL_BASE + off] = pretty
    run_init_captured(lib_path, PENCIL_BASE)
    refresh_symbol_index()

    # The queue is a host scheduler boundary. Native tasks are accepted and
    # retained here; they are not run synchronously from PostTask.
    queue = p.alloc(64); qvt = p.alloc(64); p.put(queue, "Q", qvt)
    p.put(qvt + 16, "Q", 0x20001000)
    p.u.mem_write(0x20001000, bytes.fromhex("1f2003d5c0035fd6"))
    p.u.mem_write(0x20001020, bytes.fromhex("1f2003d5c0035fd6"))
    p.u.mem_write(0x20001040, bytes.fromhex("1f2003d5c0035fd6"))
    p._runtime_queue = queue; p._task_returns = []; p._task_log = []
    queue_submissions = []
    native_task_runs = []
    dispatch_blockers = []
    canvas_owner_rows = []
    def native_object_window(address, length=64):
        if not address:
            return None
        try:
            vptr = p.get(address, "Q")[0]
            typeinfo = p.get(vptr - 8, "Q")[0] if vptr >= 8 else 0
            return {"address": hex(address), "vptr": hex(vptr),
                "typeinfo": hex(typeinfo) if typeinfo else None,
                "allocation_owner": allocation_owner_of(address),
                "prefix_hex": bytes(p.u.mem_read(address, length)).hex()}
        except Exception as exc:
            return {"address": hex(address), "read_error": f"{type(exc).__name__}: {exc}",
                "allocation_owner": allocation_owner_of(address)}

    def dispatch_native_task(row, expected):
        """Run one retained task only after its source-owned ABI is checked."""
        sequence = row["sequence"]
        task = int(row["task"], 16)
        vptr = int(row["task_vptr"], 16)
        run_entry = int(row["run_method"], 16)
        raw = bytes.fromhex(row["task_bytes_at_submission"])
        try:
            validate_task_snapshot(row, bytes(p.u.mem_read(task, len(raw))),
                p.get(vptr + 16, "Q")[0], expected, queue)
        except ValueError as exc:
            raise RuntimeError(f"retained task {sequence} failed source snapshot validation: {exc}") from exc
        for key, value in expected.items():
            if key in ("member_method", "identity", "receiver"):
                continue
            if row.get(key) != value:
                raise RuntimeError(f"task {sequence} source witness mismatch for {key}: {row.get(key)!r} != {value!r}")
        member = expected.get("member_method")
        if member is not None and p.get(task + 24, "Q")[0] != member:
            raise RuntimeError(f"task {sequence} member function pointer mismatch")
        method_symbol = expected.get("method_symbol")
        if method_symbol:
            resolution = row.get("member_method_resolution")
            if (row.get("method_symbol") != method_symbol or not resolution
                    or resolution.get("symbol") != method_symbol
                    or resolution.get("address") != hex(member)
                    or resolution.get("dso_sha256") not in
                    (PIN["graphics_dso"], PIN["pencommon_dso"], PIN["pencil"])):
                raise RuntimeError(f"task {sequence} member address lacks exact pinned ELF resolution for {method_symbol}")
        elif member == 0x48:
            resolution = row.get("member_method_resolution")
            if (row.get("method_symbol") is not None or not resolution
                    or resolution.get("kind") != "virtual_slot_offset"
                    or resolution.get("offset") != "0x48"):
                raise RuntimeError(f"task {sequence} virtual member offset lacks typed slot metadata")
        before = bytes(p.u.mem_read(task, len(raw))).hex()
        gl_start = len(adapter.gl_calls)
        gl_error_before = adapter.gles.f["glGetError"]() if adapter.gles else None
        p.x(0, task)
        if sequence == 2:
            active_texture_rt[0] = p.get(task + 16, "Q")[0]
        p.u.reg_write(R.UC_ARM64_REG_SP, 0x200EF000)
        p.u.reg_write(R.UC_ARM64_REG_LR, STOP)
        try:
            p.u.emu_start(run_entry, STOP, count=5_000_000)
            if p.u.reg_read(R.UC_ARM64_REG_PC) != STOP:
                raise RuntimeError(f"native WorkerTask Run {sequence} failed to return: PC={p.u.reg_read(R.UC_ARM64_REG_PC):#x}")
        except Exception as exc:
            regs = (R.UC_ARM64_REG_X0, R.UC_ARM64_REG_X1, R.UC_ARM64_REG_X2,
                    R.UC_ARM64_REG_X3, R.UC_ARM64_REG_X4, R.UC_ARM64_REG_X5,
                    R.UC_ARM64_REG_X6, R.UC_ARM64_REG_X7)
            failure = {"schema": "sdocx-old-pencil-native-task-dispatch-failure.v10",
                "status": "native_task_run_failed_with_register_diagnostic",
                "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL)},
                "phase": phase[0], "sequence": sequence, "task": row,
                "native_run_entry": hex(run_entry), "exception": f"{type(exc).__name__}: {exc}",
                "cpu": {"pc": hex(p.u.reg_read(R.UC_ARM64_REG_PC)),
                    "lr": hex(p.u.reg_read(R.UC_ARM64_REG_LR)),
                    "sp": hex(p.u.reg_read(R.UC_ARM64_REG_SP)),
                    "x0_x7": [hex(p.u.reg_read(reg)) for reg in regs]},
                "native_run_task_bytes_before": before,
                "native_run_task_bytes_at_failure": bytes(p.u.mem_read(task, len(raw))).hex(),
                "recent_renderer_gl_calls": adapter.gl_calls[gl_start:],
                "recent_native_symbols": native_events[-64:],
                "recent_native_import_events": native_import_events[-32:],
                "clock_gettime_calls": list(clock_gettime_calls),
                "pencil_texture_source_trace": {
                    "setTextures_entries": pencil_settextures_entries,
                    "setTextures_operator_new_array_calls": pencil_array_new_calls,
                    "host_operator_new_array_allocator_calls": pencil_native_array_allocator_calls,
                    "setTextures_operator_new_array": pencil_array_allocations,
                    "SPTextureBitmap_UpdateBitmap": pencil_bitmap_update_events,
                    "SPSubBitmapRT_UpdateBitmap": graphics_subbitmap_update_events,
                    "TextureObject_CreateTexture": pencil_texture_create_events,
                    "Renderer_TextureObject_Update": renderer_texture_update_events,
                    "Mesa_texture_allocations": pencil_texture_allocation_events,
                    "Mesa_texture_uploads": pencil_mesa_uploads,
                    "glPixelStorei": pixel_store_events},
                "completed_native_task_runs": list(native_task_runs),
                "geometry_call_count": len(add_calls),
                "paint_limit": "No pixel readback in V10; execution failure here is not a paint result."}
            emit_json(failure, args.output)
            raise
        after = bytes(p.u.mem_read(task, len(raw))).hex()
        gl_error_after = adapter.gles.f["glGetError"]() if adapter.gles else None
        if sequence == 7:
            for pixel_row in draw_pixel_evidence:
                if pixel_row.get("phase") == phase[0] and "native_task_gl_error_after_return" not in pixel_row:
                    pixel_row["native_task_gl_error_after_return"] = int(gl_error_after) if gl_error_after is not None else None
                    pixel_row["evidence_is_complete"] = bool(pixel_row.get("evidence_is_complete") and gl_error_after == 0)
        row["run_state"] = "native_Run_returned_by_controlled_scheduler"
        if sequence == 2:
            active_texture_rt[0] = 0
        native_task_runs.append({"sequence": sequence, "task": row,
            "native_run_entry": hex(run_entry), "member_method": hex(member) if member else None,
            "source_identity": expected["identity"], "task_bytes_before_run": before,
            "task_bytes_after_run": after,
            "renderer_gl_calls": adapter.gl_calls[gl_start:],
            "mesa_gl_error_before": gl_error_before, "mesa_gl_error_after": gl_error_after,
            "host_scheduler_boundary": "host invoked the retained native Run entry in strict source queue order",
            "native_run_returned": True})
    queue_task_vtables = {}
    pencommon_nm = subprocess.check_output(
        ["nm", "-D", "-C", str(RUNTIME_INPUTS / "libSPenPenCommon.so")],
        text=True, env=env)
    for line in pencommon_nm.splitlines():
        fields = line.strip().split(" ", 2)
        if (len(fields) == 3 and fields[1] in ("D", "V")
                and fields[2].startswith(("vtable for SPen::WorkerTask::", "vtable for SPen::PenGLRenderMsg"))):
            queue_task_vtables[0x1000000 + int(fields[0], 16) + 16] = fields[2]
    graphics_nm = subprocess.check_output(
        ["nm", "-D", "-C", str(RUNTIME_INPUTS / "libSPenGraphics.so")],
        text=True, env=env)
    for line in graphics_nm.splitlines():
        fields = line.strip().split(" ", 2)
        if (len(fields) == 3 and fields[1] in ("D", "V")
                and fields[2].startswith("vtable for SPen::WorkerTask::")):
            queue_task_vtables[0x4000000 + int(fields[0], 16) + 16] = fields[2]
    # Resolve captured member pointers against exact demangled exports from the
    # already hash-pinned APK DSOs. Runtime helper symbol indexing is partial
    # and is not accepted as the source of method identity.
    member_method_exports = {}
    member_method_export_inputs = (
        ("libSPenPenCommon.so", 0x1000000, PIN["pencommon_dso"], pencommon_nm),
        ("libSPenGraphics.so", 0x4000000, PIN["graphics_dso"], graphics_nm),
    )
    pencil_nm = subprocess.check_output(
        ["nm", "-D", "-C", str(PENCIL)], text=True, env=env)
    member_method_export_inputs += (("libSPenPencil.so", PENCIL_BASE, PIN["pencil"], pencil_nm),)
    for soname, base, dso_hash, output in member_method_export_inputs:
        for line in output.splitlines():
            fields = line.strip().split(" ", 2)
            if len(fields) != 3 or fields[1] not in ("T", "t", "W", "w"):
                continue
            try:
                rva = int(fields[0], 16)
            except ValueError:
                continue
            if rva:
                member_method_exports[base + rva] = {
                    "kind": "exported_function", "symbol": fields[2],
                    "dso": soname, "dso_sha256": dso_hash,
                    "address": hex(base + rva), "rva": hex(rva)}
    bitmap_setup_vtable_names = {
        address + 16: name for name, address in p.syms.items()
        if name.startswith("vtable for SPen::WorkerTask::")
    }
    p.managed_queue = p.alloc(32); p.managed_queue_vtable = p.alloc(64)
    p.put(p.managed_queue, "Q", p.managed_queue_vtable)
    renderer_nm = subprocess.check_output(
        ["nm", "-D", str(RUNTIME_INPUTS / "libSPenRenderer.so")], text=True, env=env)
    queue_typeinfo = next((0xA000000 + int(fields[0], 16)
        for line in renderer_nm.splitlines()
        if (fields := line.strip().split()) and len(fields) == 3
        and fields[2] == "_ZTIN4SPen11IGLMsgQueueE"), 0)
    if not queue_typeinfo:
        raise RuntimeError("pinned Renderer DSO lacks IGLMsgQueue typeinfo for the typed queue adapter")
    p.put(qvt - 16, "qQ", 0, queue_typeinfo)
    p.put(qvt + 56, "Q", 0x20001060)
    p.put(p.managed_queue_vtable + 16, "Q", 0x20001080)
    p.put(p.managed_queue_vtable + 24, "Q", 0x200010A0)
    # Separate setup queue: it runs only CreateBitmap's native initialization
    # tasks. The primary canvas queue below retains callback tasks as deferred.
    bitmap_setup_queue = p.alloc(32); bitmap_setup_vtable = p.alloc(64)
    p.put(bitmap_setup_queue, "Q", bitmap_setup_vtable)
    p.put(bitmap_setup_vtable - 16, "qQ", 0, queue_typeinfo)
    p.put(bitmap_setup_vtable + 16, "Q", 0x20001100)
    p.put(bitmap_setup_vtable + 56, "Q", 0x20001120)
    bitmap_setup_tasks = []
    bitmap_setup_return_stack = []
    for addr in (0x20001060, 0x20001080, 0x200010A0, 0x20001100, 0x20001120):
        p.u.mem_write(addr, bytes.fromhex("1f2003d5c0035fd6"))
    ctx = p.alloc(32); ctxvt = p.alloc(256); p.put(ctx, "Q", ctxvt)
    child = p.alloc(64); childvt = p.alloc(128); p.put(child, "Q", childvt)
    for addr in (0x200F2300, 0x200F2340, 0x200F2380, 0x200F23C0, 0x200F23E0,
                 0x200F2200, 0x200F2400, 0x200F2420, 0x200F2440, 0x200F2460):
        p.u.mem_write(addr, bytes.fromhex("c0035fd6"))
    p.put(ctxvt + 16, "Q", 0x200F2300); p.put(ctxvt + 24, "Q", 0x200F23E0)
    p.put(ctxvt + 80, "Q", 0x200F2340); p.put(ctxvt + 144, "Q", 0x200F2200)
    p.put(ctxvt + 152, "Q", 0x200F2200)
    p.put(childvt + 32, "Q", 0x200F2380); p.put(childvt + 40, "Q", 0x200F23C0)
    def context_hook(u, a, _size, _data):
        if a == 0x200F2300: p.x(0, child)
        elif a == 0x200F23E0: p.x(0, queue)
        elif a == 0x200F2340: p.x(0, p.x(1))
        elif a == 0x200F2380: p.x(0, 1920)
        elif a == 0x200F23C0: p.x(0, 1080)
        elif a in (0x200F2400, 0x200F2420, 0x200F2440, 0x200F2460): p.x(0, 0)
        else: return
        u.reg_write(R.UC_ARM64_REG_PC, u.reg_read(R.UC_ARM64_REG_LR))
    def task_hook(u, a, _size, _data):
        if a == 0x20001040:
            p.x(0, 1); u.reg_write(R.UC_ARM64_REG_PC, u.reg_read(R.UC_ARM64_REG_LR))
        elif a == 0x20001060:
            p.x(0, p.managed_queue); u.reg_write(R.UC_ARM64_REG_PC, u.reg_read(R.UC_ARM64_REG_LR))
        elif a in (0x20001080, 0x200010A0):
            p.x(0, 1); u.reg_write(R.UC_ARM64_REG_PC, u.reg_read(R.UC_ARM64_REG_LR))
        elif a == 0x20001000:
            queue_receiver, task = p.x(0), p.x(1)
            if queue_receiver != queue:
                raise RuntimeError(f"IGLMsgQueue slot +16 received unexpected queue {queue_receiver:#x}")
            if not task:
                raise RuntimeError("IGLMsgQueue slot +16 received a null task")
            vptr = p.get(task, "Q")[0]
            run_method = p.get(vptr + 16, "Q")[0]
            if not run_method:
                raise RuntimeError(f"queued WorkerTask has null Run method: task={task:#x} vptr={vptr:#x}")
            allocation = next((row for row in reversed(p._newlog) if row[0] == task), None)
            if allocation is None:
                raise RuntimeError(f"queued task pointer is not an exact native operator-new allocation: {task:#x}")
            task_size = int(allocation[1])
            if not 0 < task_size <= 4096:
                raise RuntimeError(f"queued task allocation outside evidence cap: {task_size}")
            task_symbol = queue_task_vtables.get(vptr)
            task_typeinfo = p.get(vptr - 8, "Q")[0] if vptr >= 8 else 0
            typeinfo_symbol = next((name for name, address in p.rtti_syms.items()
                                    if address == task_typeinfo), None)
            member_method = p.get(task + 24, "Q")[0] if task_size >= 32 else 0
            task_receiver = p.get(task + 16, "Q")[0] if task_size >= 24 else 0
            payload_receiver = 0
            if task_symbol == "vtable for SPen::PenGLRenderMsg" and task_size >= 48:
                payload_receiver = p.get(task + 32, "Q")[0]
            receiver = payload_receiver or task_receiver
            if task_symbol and "SPPenCanvasImpl" in task_symbol:
                role = "canvas_clip_runtime"
            elif task_symbol == "vtable for SPen::PenGLRenderMsg":
                role = "pen_render_message_payload"
            elif typeinfo_symbol and "PenStrokeDataManager" in typeinfo_symbol:
                role = "stroke_data_manager_cleanup"
            elif task_symbol and "PenDrawableRT" in task_symbol:
                role = "PenDrawableRT_member_receiver"
            elif typeinfo_symbol and "WorkerTask::Member1<SPen::PenDrawableRT" in typeinfo_symbol:
                role = "PenDrawableRT_member_receiver"
            elif typeinfo_symbol and "WorkerTask::Member2<SPen::PenDrawableRT" in typeinfo_symbol:
                role = "PenDrawableRT_member_receiver"
            elif task_symbol and "Delete<" in task_symbol:
                role = "owned_vector_cleanup"
            else:
                role = "native_task_role_unresolved"
            owner_matches = [dict(owner) for owner in canvas_owner_rows
                if owner.get("this_plus_16_rt_member") == hex(receiver)
                and owner.get("canvas_argument") == hex(getattr(p, "pen_canvas", 0))]
            queue_submissions.append({
                "sequence": len(queue_submissions), "queue": hex(queue_receiver),
                "task": hex(task), "allocation_size": task_size,
                "task_vptr": hex(vptr), "task_vtable_symbol": queue_task_vtables.get(vptr),
                "run_method": hex(run_method), "run_entry_role": "native WorkerTask virtual entry +16",
                "caller_lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
                "acceptance_result_w0": 1, "accepted": True,
                "ownership_transferred_to_queue": True, "run_state": "deferred_not_run",
                "task_bytes_at_submission": bytes(u.mem_read(task, task_size)).hex(),
                "ownership": "accepted and retained by host queue adapter; native Run not called here",
                "role": role,
                # Source witness keys are validated at the submission boundary;
                # expose the resolved ELF name directly as well as in the detailed RTTI object.
                "typeinfo_symbol": typeinfo_symbol,
                "task_typeinfo": {"address": hex(task_typeinfo) if task_typeinfo else None,
                    "symbol": typeinfo_symbol},
                "member_method_pointer": hex(member_method) if member_method else None,
                "method_symbol": (member_method_exports.get(member_method, {}).get("symbol")
                                  if member_method > 0x10000 else None),
                "member_method_resolution": (member_method_exports.get(member_method)
                    if member_method > 0x10000 else
                    ({"kind": "virtual_slot_offset", "offset": hex(member_method)}
                     if member_method else None)),
                "receiver_layout": {"role_receiver": hex(receiver) if receiver else None,
                    "member_receiver": hex(task_receiver) if task_receiver else None,
                    "message_payload_receiver": hex(payload_receiver) if payload_receiver else None,
                    "object_window": native_object_window(receiver),
                    "source_SetCanvas_owner_matches": owner_matches},
            })
            # Destructor checks this bool: true transfers task ownership to the
            # queue and skips its failure-path virtual delete.
            p.x(0, 1)
            u.reg_write(R.UC_ARM64_REG_PC, u.reg_read(R.UC_ARM64_REG_LR))
        elif a == 0x20001020:
            p.x(0, 1); u.reg_write(R.UC_ARM64_REG_PC, p._task_returns.pop())
        elif a == 0x20001100:
            queue_receiver, task = p.x(0), p.x(1)
            if queue_receiver != bitmap_setup_queue:
                raise RuntimeError(f"bitmap setup queue received unexpected receiver {queue_receiver:#x}")
            if len(bitmap_setup_tasks) >= 16:
                raise RuntimeError("native bitmap setup task cap exceeded")
            vptr = p.get(task, "Q")[0]
            run_method = p.get(vptr + 16, "Q")[0]
            allocation = next((row for row in reversed(p._newlog) if row[0] == task), None)
            if not task or not run_method or allocation is None:
                raise RuntimeError(f"invalid native CreateBitmap task: task={task:#x}, vptr={vptr:#x}")
            task_size = int(allocation[1])
            if not 0 < task_size <= 4096:
                raise RuntimeError(f"bitmap setup task outside evidence cap: {task_size}")
            bitmap_setup_tasks.append({
                "sequence": len(bitmap_setup_tasks), "task": hex(task),
                "queue": hex(queue_receiver), "allocation_size": task_size,
                "task_vptr": hex(vptr),
                "task_vtable_symbol": bitmap_setup_vtable_names.get(vptr),
                "run_method": hex(run_method),
                "caller_lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
                "task_bytes_at_run": bytes(u.mem_read(task, task_size)).hex(),
                "run_state": "native_Run_executed_by_setup_queue",
            })
            bitmap_setup_return_stack.append(
                (u.reg_read(R.UC_ARM64_REG_LR), len(bitmap_setup_tasks) - 1))
            p.x(0, task); u.reg_write(R.UC_ARM64_REG_LR, 0x20001120)
            u.reg_write(R.UC_ARM64_REG_PC, run_method)
        elif a == 0x20001120:
            if not bitmap_setup_return_stack:
                raise RuntimeError("bitmap setup task returned without a saved queue caller")
            caller_lr, task_record_index = bitmap_setup_return_stack.pop()
            bitmap_setup_tasks[task_record_index]["native_Run_return_x0"] = hex(p.x(0))
            p.x(0, 1)
            u.reg_write(R.UC_ARM64_REG_LR, caller_lr)
            u.reg_write(R.UC_ARM64_REG_PC, caller_lr)
    p.u.hook_add(UC_HOOK_CODE, context_hook); p.u.hook_add(UC_HOOK_CODE, task_hook)

    loader = []
    def cstr(address):
        return bytes(p.u.mem_read(address, 256)).split(b"\0", 1)[0].decode("ascii", "replace")
    def dlopen():
        name = cstr(p.x(0)); loader.append({"fn": "dlopen", "name": name})
        if Path(name).name != "libSPenPencil.so": raise RuntimeError(f"unexpected plugin {name!r}")
        p.x(0, PENCIL_HANDLE)
    def dlsym():
        handle, name = p.x(0), cstr(p.x(1)); loader.append({"fn": "dlsym", "handle": hex(handle), "name": name})
        if handle != PENCIL_HANDLE or name != "createPenInst": raise RuntimeError(f"unexpected dlsym {handle:#x} {name!r}")
        address = PENCIL_BASE + defined.get(name, 0)
        if not defined.get(name): raise RuntimeError("old Pencil DSO lacks createPenInst")
        p.x(0, address)
    p.callbacks["dlopen"] = dlopen; p.callbacks["dlsym"] = dlsym
    p.callbacks["dlerror"] = lambda: p.x(0, 0)

    def call(name, x=(), f=(), limit=5_000_000):
        if name not in p.syms: raise RuntimeError(f"missing pinned symbol: {name}")
        for i, value in enumerate(x): p.x(i, value)
        for i, value in enumerate(f): p.f(i, value)
        p.u.reg_write(R.UC_ARM64_REG_SP, 0x200EF000); p.u.reg_write(R.UC_ARM64_REG_LR, STOP)
        attempt = {"symbol": name, "entry_pc": hex(p.syms[name]),
                   "phase": phase[0], "arguments_x0_x7": [hex(p.x(i)) for i in range(min(8, len(x)))],
                   "status": "running"}
        native_call_attempts.append(attempt)
        try:
            p.u.emu_start(p.syms[name], STOP, count=limit)
            if p.u.reg_read(R.UC_ARM64_REG_PC) != STOP:
                raise RuntimeError(f"{name} did not return to the native call sentinel")
        except Exception as exc:
            state = register_state(p.u)
            caller = nearest_symbol(int(state["lr"], 16))
            attempt.update({"status": "failed", "exception_type": type(exc).__name__,
                "exception": str(exc), "terminal_cpu": state,
                "terminal_pc_nearest_symbol": nearest_symbol(int(state["pc"], 16)),
                "terminal_lr_nearest_symbol": caller})
            report = {
                "schema": "sdocx-old-pencil-native-call-diagnostic.v6",
                "status": "native_call_failed_with_diagnostic",
                "scope": "Native call failure captured across setup, bitmap factory, canvas construction, and Drawing; no unresolved target is mapped or replaced.",
                "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL),
                         "analysis_dso_sha256": digest(PENCIL_ANALYSIS)},
                "native_call": attempt,
                "strncpy_calls": strncpy_calls,
                "recent_native_symbol_events": native_events[-128:],
                "recent_native_import_events": native_import_events[-96:],
                "recent_native_call_attempts": native_call_attempts[-32:],
                "invalid_memory_events": invalid_memory_events[-8:],
                "queue_state_at_failure": {
                    "bitmap_setup_tasks": list(bitmap_setup_tasks),
                    "callback_queue_submissions": list(queue_submissions),
                },
            }
            raise NativeCallDiagnostic(report, args.output) from exc
        attempt.update({"status": "returned", "return_x0": hex(p.x(0)),
                        "return_pc": hex(p.u.reg_read(R.UC_ARM64_REG_PC))})
        return p.x(0)

    def make_string(value):
        obj = p.alloc(32); call("SPen::String::String()", [obj]); call("SPen::String::Construct()", [obj])
        data = p.alloc(len(value.encode()) + 1); p.u.mem_write(data, value.encode() + b"\0")
        call("SPen::String::Set(char const*)", [obj, data]); return obj

    def string_utf8_snapshot(string_object):
        if not string_object:
            return {"object": None, "utf8": None}
        call("SPen::String::GetUTF8Size() const", [string_object])
        size = p.x(0)
        if not 0 <= size <= 4096:
            raise RuntimeError(f"native string UTF-8 size outside capture bound: {size}")
        buffer = p.alloc(size + 1)
        p.u.mem_write(buffer, bytes(size + 1))
        call("SPen::String::GetUTF8(char*, int) const", [string_object, buffer, size])
        raw = bytes(p.u.mem_read(buffer, size))
        return {"object": hex(string_object), "size": size,
                "bytes_hex": raw.hex(), "utf8": raw.decode("utf-8", "replace")}

    def initialize_native_renderer_caps():
        phase[0] = "renderer_caps_native_init"
        expected={
            "SPen::ShaderManager::ShaderManager()":renderer_base+0x45BDC,
            "SPen::ShaderManager::GetInstance()":renderer_base+0x45BD0,
            "SPen::OpenGLRenderer::InitParameters()":renderer_base+0x4BB58,
            "SPen::OpenGLRenderer::getMaxTextureSize()":renderer_base+0x4C464,
            "SPen::RendererFactory::GetRendererDeviceCaps()":renderer_base+0x45AA4,
            "SPen::GLES::RendererFactoryImpl::GetRendererDeviceCaps()":renderer_base+0x5B088,
            "SPen::GLES::RendererDeviceCaps::GetMaxTextureSize() const":renderer_base+0x5AC50,
            "SPen::CriticalSection::CriticalSection(bool)":BASE_BASE+0x99B38}
        for name,address in expected.items():
            if p.syms.get(name)!=address:
                raise RuntimeError(f"native Renderer symbol/RVA mismatch: {name}: {p.syms.get(name)!r} != {address:#x}")
        host_context=egl_get_current_context()
        if not host_context: raise RuntimeError("no current actual Mesa EGLContext for native Renderer init")
        shader_manager=p.alloc(512); call("SPen::ShaderManager::ShaderManager()",[shader_manager])
        p.put(renderer_base+0x6D480,"Q",shader_manager)
        call("SPen::ShaderManager::GetInstance()",[])
        if p.x(0)!=shader_manager: raise RuntimeError("native ShaderManager singleton mismatch")
        call("SPen::CriticalSection::CriticalSection(bool)",[renderer_base+0x73290,0])
        call("SPen::OpenGLRenderer::InitParameters()",[],limit=3_000_000)
        mesa_max=C.c_int(); viewport=(C.c_int*2)()
        gl_get_integer_native(0x0D33,C.byref(mesa_max)); gl_get_integer_native(0x0D3A,viewport)
        if mesa_max.value<=0 or min(viewport)<=0: raise RuntimeError("Mesa returned invalid caps")
        call("SPen::RendererFactory::GetRendererDeviceCaps()",[])
        caps=p.x(0); vtable=p.get(caps,"Q")[0] if caps else 0
        getter=p.get(vtable+16,"Q")[0] if vtable else 0
        expected_getter=p.syms["SPen::GLES::RendererDeviceCaps::GetMaxTextureSize() const"]
        if not caps or not (renderer_base<=vtable<renderer_base+0x200000) or getter!=expected_getter:
            raise RuntimeError("native RendererDeviceCaps object/vtable mismatch")
        call("SPen::GLES::RendererDeviceCaps::GetMaxTextureSize() const",[caps]); native_max=p.x(0)&0xffffffff
        call("SPen::OpenGLRenderer::getMaxTextureSize()",[]); renderer_max=p.x(0)&0xffffffff
        expected_max=min(mesa_max.value,viewport[0],viewport[1])
        if native_max!=renderer_max or native_max!=expected_max:
            raise RuntimeError(f"native caps {native_max}/{renderer_max} disagree with Mesa {expected_max}")
        phase[0]="post_renderer_caps_native_init"
        return {"provider":"native RendererFactory -> GLES RendererFactoryImpl; synthetic adapter callback removed",
            "renderer_dso_sha256":PIN["renderer_dso"],"host_egl_context":hex(int(host_context)),
            "caps_object":hex(caps),"caps_vtable":hex(vtable),"native_getter":hex(getter),
            "mesa_GL_MAX_TEXTURE_SIZE":mesa_max.value,"mesa_GL_MAX_VIEWPORT_DIMS":list(viewport),
            "native_caps_max":native_max,"renderer_getter_max":renderer_max,
            "renderer_glGetIntegerv_calls":renderer_caps_gl_integer_calls,
            "renderer_strtof_calls":renderer_caps_strtof_calls,
            "GL_context_ownership":"actual current Mesa EGL context; no Android device renderer claim"}

    renderer_caps_receipt=initialize_native_renderer_caps()

    # Create an actual native SPBitmap through the exported Graphics factory.
    # The pinned BrushPen full-queue caller/evidence use the same factory and
    # raw TextureMemoryLayout/TextureTargetLayout values (6,2). Its setup queue
    # executes only the real bitmap creation task(s); callback tasks use the
    # separate primary queue and stay deferred.
    bitmap_width, bitmap_height = 1920, 1080
    phase[0] = "bitmap_factory_setup"
    bitmap_pixels = bytes(bitmap_width * bitmap_height * 4)
    bitmap_pixels_ptr = p.alloc(len(bitmap_pixels))
    p.u.mem_write(bitmap_pixels_ptr, bitmap_pixels)
    bitmap_source_initial_sha256 = hashlib.sha256(
        bytes(p.u.mem_read(bitmap_pixels_ptr, len(bitmap_pixels)))).hexdigest()
    if bitmap_source_initial_sha256 != hashlib.sha256(bitmap_pixels).hexdigest():
        raise RuntimeError("host-initialized CreateBitmap source bytes did not round trip")
    bitmap_source_write_events = []
    bitmap_source_write_stats = {"guest_cpu_write_calls": 0, "host_mem_write_calls": 0,
        "memory_callback_calls": 0, "overlap_cap": 4096, "dropped_events": 0,
        "wrapper_installed": False, "wrapped_memory_callbacks": []}
    bitmap_source_base, bitmap_source_limit = bitmap_pixels_ptr, bitmap_pixels_ptr + len(bitmap_pixels)
    def bitmap_cpu_write_observer(u, access, address, size, value, _user_data):
        lo, hi = max(address, bitmap_source_base), min(address + size, bitmap_source_limit)
        if lo >= hi: return
        bitmap_source_write_stats["guest_cpu_write_calls"] += 1
        row = {"boundary": "guest_cpu_store", "phase": phase[0],
            "pc": hex(u.reg_read(R.UC_ARM64_REG_PC)), "lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
            "address": hex(address), "size": int(size), "overlap_offset": lo - bitmap_source_base,
            "overlap_bytes": hi - lo}
        if size <= 8:
            row["store_value_le_hex"] = int(value).to_bytes(size, "little", signed=False).hex()
        if len(bitmap_source_write_events) < bitmap_source_write_stats["overlap_cap"]:
            bitmap_source_write_events.append(row)
        else: bitmap_source_write_stats["dropped_events"] += 1
    bitmap_cpu_write_hook = p.u.hook_add(UC_HOOK_MEM_WRITE, bitmap_cpu_write_observer)
    original_source_mem_write = p.u.mem_write
    original_source_mem_read = p.u.mem_read
    def traced_source_mem_write(address, data):
        raw = data if isinstance(data, bytes) else bytes(data)
        lo, hi = max(address, bitmap_source_base), min(address + len(raw), bitmap_source_limit)
        if lo < hi:
            bitmap_source_write_stats["host_mem_write_calls"] += 1
            before = bytes(original_source_mem_read(lo, hi - lo))
            part = raw[lo - address:hi - address]
            pc, lr = p.u.reg_read(R.UC_ARM64_REG_PC), p.u.reg_read(R.UC_ARM64_REG_LR)
            owner = next(({"base": hex(base), "size": int(size), "offset": hex(address-base)}
                for base, size, *_rest in reversed(p._newlog)
                if base <= address < base + size), None)
            frames = []
            frame = sys._getframe(1)
            while frame is not None and len(frames) < 8:
                try: filename = str(Path(frame.f_code.co_filename).resolve().relative_to(ROOT))
                except (ValueError, OSError): filename = Path(frame.f_code.co_filename).name
                frames.append({"file": filename, "line": frame.f_lineno, "function": frame.f_code.co_name})
                frame = frame.f_back
            row = {"boundary": "Uc.mem_write", "phase": phase[0],
                "address": hex(address), "size": len(raw),
                "overlap_offset": lo - bitmap_source_base, "overlap_bytes": hi - lo,
                "payload_sha256": hashlib.sha256(raw).hexdigest(),
                "overlap_before_sha256": hashlib.sha256(before).hexdigest(),
                "overlap_after_sha256": hashlib.sha256(part).hexdigest(),
                "overlap_before_hex": before[:128].hex(), "overlap_after_hex": part[:128].hex(),
                "changed_bytes": sum(a != b for a,b in zip(before,part)),
                "pc": hex(pc), "lr": hex(lr),
                "pc_symbol": nearest_symbol(pc), "lr_symbol": nearest_symbol(lr),
                "destination_allocation_owner": owner, "python_call_stack": frames}
            if len(bitmap_source_write_events) < bitmap_source_write_stats["overlap_cap"]:
                bitmap_source_write_events.append(row)
            else: bitmap_source_write_stats["dropped_events"] += 1
        return original_source_mem_write(address, data)
    p.u.mem_write = traced_source_mem_write
    bitmap_source_write_stats["wrapper_installed"] = p.u.mem_write is traced_source_mem_write
    original_source_callbacks = {}
    for memory_name in ("memcpy", "memmove", "memset"):
        original_callback = p.callbacks.get(memory_name)
        if original_callback is None: continue
        original_source_callbacks[memory_name] = original_callback
        def traced_source_callback(name=memory_name, original=original_callback):
            destination, second, count = p.x(0), p.x(1), p.x(2)
            lo, hi = max(destination, bitmap_source_base), min(destination + count, bitmap_source_limit)
            if lo >= hi:
                original(); return
            before = bytes(p.u.mem_read(lo, hi-lo))
            source = None if name == "memset" else second
            data = (bytes([second & 0xff]) * count if name == "memset"
                else bytes(p.u.mem_read(source, count)))
            original()
            after = bytes(p.u.mem_read(lo, hi-lo))
            bitmap_source_write_stats["memory_callback_calls"] += 1
            row = {"boundary": "native_memory_import", "operation": name,
                "phase": phase[0], "destination": hex(destination),
                "source": hex(source) if source is not None else None,
                "fill_u8": second & 0xff if name == "memset" else None,
                "size": count, "overlap_offset": lo-bitmap_source_base,
                "overlap_bytes": hi-lo, "caller_lr": hex(p.u.reg_read(R.UC_ARM64_REG_LR)),
                "before_sha256": hashlib.sha256(before).hexdigest(),
                "after_sha256": hashlib.sha256(after).hexdigest(),
                "source_payload_overlap_hex": data[lo-destination:hi-destination][:128].hex(),
                "changed_bytes": sum(a != b for a,b in zip(before,after))}
            if len(bitmap_source_write_events) < bitmap_source_write_stats["overlap_cap"]:
                bitmap_source_write_events.append(row)
            else: bitmap_source_write_stats["dropped_events"] += 1
        p.callbacks[memory_name] = traced_source_callback
        bitmap_source_write_stats["wrapped_memory_callbacks"].append(memory_name)
    bitmap_tag = p.alloc(32)
    p.u.mem_write(bitmap_tag, b"synthetic-old-pencil-canvas\0")
    bitmap_factory_symbol = (
        "SPen::SPGraphicsFactory::CreateBitmap(SPen::IGLMsgQueue*, int, int, "
        "char const*, void const*, bool, int, bool, SPen::TextureMemoryLayout, "
        "SPen::TextureTargetLayout)")
    p.put(0x200EF000, "2Q", 6, 2)
    try:
        call(bitmap_factory_symbol,
             [bitmap_setup_queue, bitmap_width, bitmap_height, bitmap_tag,
              bitmap_pixels_ptr, 0, 0, 0], limit=5_000_000)
    finally:
        p.u.hook_del(bitmap_cpu_write_hook)
        p.u.mem_write = original_source_mem_write
        for memory_name, original_callback in original_source_callbacks.items():
            p.callbacks[memory_name] = original_callback
    bitmap_source_after_factory = bytes(p.u.mem_read(bitmap_pixels_ptr, len(bitmap_pixels)))
    changed_source_offsets = [i for i, (before, after) in enumerate(zip(bitmap_pixels, bitmap_source_after_factory))
        if before != after]
    bitmap_source_provenance = {
        "scope": "CreateBitmap source interval only; intentional zero initialization precedes observers",
        "source_guest_pointer": hex(bitmap_pixels_ptr), "source_bytes": len(bitmap_pixels),
        "source_initial_sha256": bitmap_source_initial_sha256,
        "source_after_factory_sha256": hashlib.sha256(bitmap_source_after_factory).hexdigest(),
        "source_unchanged": not changed_source_offsets,
        "changed_byte_count": len(changed_source_offsets),
        "changed_byte_samples": [{"offset": i, "initial": bitmap_pixels[i],
            "after": bitmap_source_after_factory[i]} for i in changed_source_offsets[:256]],
        "changed_byte_samples_truncated": len(changed_source_offsets) > 256,
        "allocator_handoff": adapter_allocator_handoff,
        "renderer_caps": renderer_caps_receipt,
        "write_stats": bitmap_source_write_stats,
        "overlap_events": bitmap_source_write_events,
        "coverage_boundary": "guest CPU write hook plus the exact Drawing Uc.mem_write method; direct C API calls and other Uc instances are not observed",
    }
    actual_bitmap = p.x(0)
    if not actual_bitmap:
        raise RuntimeError("native SPGraphicsFactory::CreateBitmap returned null")
    actual_bitmap_vptr = p.get(actual_bitmap, "Q")[0]
    if not actual_bitmap_vptr:
        raise RuntimeError("native SPGraphicsFactory returned bitmap without a vptr")
    call("SPen::SPBitmap::GetWidth() const", [actual_bitmap])
    actual_bitmap_width = p.x(0)
    call("SPen::SPBitmap::GetHeight() const", [actual_bitmap])
    actual_bitmap_height = p.x(0)
    if (actual_bitmap_width, actual_bitmap_height) != (bitmap_width, bitmap_height):
        raise RuntimeError(
            "native bitmap dimensions disagree with CreateBitmap input: "
            f"{actual_bitmap_width}x{actual_bitmap_height} != {bitmap_width}x{bitmap_height}")
    bitmap_factory_record = {
        "factory_symbol": bitmap_factory_symbol,
        "bitmap": hex(actual_bitmap), "vptr": hex(actual_bitmap_vptr),
        "width_height_from_native_getters": [actual_bitmap_width, actual_bitmap_height],
        "source_kind": "explicit all-zero RGBA synthetic canvas surface",
        "source_bytes": len(bitmap_pixels), "source_sha256": hashlib.sha256(bitmap_pixels).hexdigest(),
        "texture_memory_layout_raw_u32": 6, "texture_target_layout_raw_u32": 2,
        "layout_provenance": "hash-pinned BrushPen full-queue actual-canvas source/evidence; values are raw enums, not named here",
        "setup_queue": hex(bitmap_setup_queue), "setup_queue_tasks": bitmap_setup_tasks,
    }
    phase[0] = "native_canvas_constructor"
    actual_pen_canvas = p.alloc(256)
    call("SPen::SPPenCanvas::SPPenCanvas(SPen::IGLMsgQueue*, SPen::ISPBitmap*)",
         [actual_pen_canvas, queue, actual_bitmap], limit=1_000_000)
    actual_canvas_vptr = p.get(actual_pen_canvas, "Q")[0]
    actual_get_queue = p.get(actual_canvas_vptr + 184, "Q")[0]
    expected_get_queue = p.syms.get("SPen::SPPenCanvas::GetMsgQueue()")
    actual_canvas_queue = p.get(actual_pen_canvas + 24, "Q")[0]
    actual_canvas_impl = p.get(actual_pen_canvas + 32, "Q")[0]
    actual_impl_bitmap = p.get(actual_canvas_impl + 8, "Q")[0] if actual_canvas_impl else 0
    actual_get_bitmap = p.get(actual_canvas_vptr + 192, "Q")[0]
    expected_get_bitmap = p.syms.get("SPen::SPPenCanvas::GetBitmap()")
    if actual_get_queue != expected_get_queue or actual_canvas_queue != queue:
        raise RuntimeError(
            "native SPPenCanvas GetMsgQueue slot/constructor queue mismatch: "
            f"slot={actual_get_queue:#x}, expected={expected_get_queue}, queue={actual_canvas_queue:#x}")
    if (not actual_canvas_impl or actual_impl_bitmap != actual_bitmap
            or actual_get_bitmap != expected_get_bitmap):
        raise RuntimeError(
            "native SPPenCanvasImpl/GetBitmap contract mismatch: "
            f"impl={actual_canvas_impl:#x}, impl_bitmap={actual_impl_bitmap:#x}, "
            f"bitmap={actual_bitmap:#x}, slot192={actual_get_bitmap:#x}, "
            f"expected={expected_get_bitmap}")
    # Source-order barrier: SPenCanvasImpl's native constructor posts
    # createClippingRT. Run that exact native task before SetClipRect, whose
    # RT receiver accesses the resulting owned clipping object.
    constructor_tasks = [row for row in queue_submissions if row["sequence"] == 0]
    clipping_method = p.syms.get("SPen::SPPenCanvasImpl::createClippingRT()")
    clipping_bytes = bytes.fromhex(
        "fd7bbea9f44f01a9fd030091f30300aa001a805268620094610640f9f40300aa"
        "c9650094740a00f9f44f41a9fd7bc2a8c0035fd6f30300aae00314aa62620094"
        "e00313aa012eff97")
    if len(constructor_tasks) != 1:
        raise RuntimeError(f"native canvas constructor must post one createClippingRT task: {constructor_tasks}")
    constructor_task = constructor_tasks[0]
    if (clipping_method != 0x40AFB4C
            or bytes(p.u.mem_read(clipping_method, len(clipping_bytes))) != clipping_bytes
            or constructor_task["task_vtable_symbol"] !=
              "vtable for SPen::WorkerTask::Member0<SPen::SPPenCanvasImpl, void (SPen::SPPenCanvasImpl::*)()>"
            or p.get(int(constructor_task["task"], 16) + 16, "Q")[0] != actual_canvas_impl
            or p.get(int(constructor_task["task"], 16) + 24, "Q")[0] != clipping_method
            or constructor_task["run_method"] != hex(p.get(int(constructor_task["task_vptr"], 16) + 16, "Q")[0])
            or constructor_task["caller_lr"] != "0x40afbf4"):
        raise RuntimeError("native constructor task does not match pinned createClippingRT receiver/method/Run/caller")
    dispatch_native_task(constructor_task, {
        "sequence": 0, "identity": "SPenCanvasImpl::createClippingRT()",
        "task_vtable_symbol": "vtable for SPen::WorkerTask::Member0<SPen::SPPenCanvasImpl, void (SPen::SPPenCanvasImpl::*)()>",
    })
    constructor_task["run_state"] = "native_Run_executed_at_constructor_to_SetClipRect_barrier"
    # The hash-pinned full-queue canvas caller initializes its native viewport
    # from native bitmap dimensions before drawing. Reproduce that bounded
    # source setup; this submits an actual native ClipInfo WorkerTask to the
    # same accepted queue, whose submission is recorded and kept deferred.
    clip_task_start = len(queue_submissions)
    canvas_clip_count_before = p.get(actual_pen_canvas + 252, "I")[0]
    phase[0] = "native_canvas_clip_setup"
    clip_rect_args = [0, 0, actual_bitmap_width, actual_bitmap_height, 0]
    call("SPen::SPPenCanvas::SetClipRect(int, int, int, int, SPen::ISPCanvasBase::ClipOp)",
         [actual_pen_canvas, *clip_rect_args], limit=1_000_000)
    native_canvas_clip_setup = {
        "source": "hash-pinned BrushPen full-queue actual-canvas caller",
        "method": "SPen::SPPenCanvas::SetClipRect(int, int, int, int, SPen::ISPCanvasBase::ClipOp)",
        "native_bitmap_dimensions": [actual_bitmap_width, actual_bitmap_height],
        "arguments_x1_x5": clip_rect_args,
        "native_canvas_clip_count_before": canvas_clip_count_before,
        "native_canvas_clip_count_after": p.get(actual_pen_canvas + 252, "I")[0],
        "queue_submission_count": len(queue_submissions) - clip_task_start,
        "native_queue_submissions": queue_submissions[clip_task_start:],
        "task_execution": "accepted and deferred on callback queue; not Run inside SetClipRect",
    }
    p.pen_canvas = actual_pen_canvas
    native_pen_canvas = {
        "object": hex(actual_pen_canvas), "vptr": hex(actual_canvas_vptr),
        "slot_184_target": hex(actual_get_queue),
        "slot_184_symbol": "SPen::SPPenCanvas::GetMsgQueue()",
        "queue_member": hex(actual_canvas_queue), "queue": hex(queue),
        "impl": hex(actual_canvas_impl), "impl_bitmap": hex(actual_impl_bitmap),
        "slot_192_target": hex(actual_get_bitmap),
        "slot_192_symbol": "SPen::SPPenCanvas::GetBitmap()",
        "constructor_bitmap": hex(actual_bitmap),
        "bitmap_factory": bitmap_factory_record,
        "clip_setup": native_canvas_clip_setup,
    }

    phase[0] = "drawing_setup"
    drawing = call("SPen::DrawingFactory::CreateDrawing(SPen::IContext const*)", [ctx], limit=1_000_000)
    if not drawing: raise RuntimeError("DrawingFactory returned null")
    add_name = "SPen::PencilStrokeDrawableRTV1::AddPoint(SPen::Vector3<float>, float)"
    if p.syms.get(add_name) != PENCIL_BASE + 0x2EFC0:
        raise RuntimeError(f"typed Pencil AddPoint symbol/RVA drift: {p.syms.get(add_name)}")
    redraw_names = [
        "SPen::PencilStrokeDrawableGLV1::RedrawPen(SPen::ObjectStroke const*, SPen::RectF*)",
        "SPen::PencilStrokeDrawableGLV1::RedrawPen(SPen::MotionEvent const*, SPen::RectF*)",
    ]
    draw_names = ["SPen::PencilStrokeDrawableGLV1::Draw(SPen::MotionEvent const*, SPen::RectF*)",
                  "SPen::PencilStrokeStyle::drawPoint(SPen::SmPoint*, float, SPen::RectF*)",
                  "SPen::PencilStrokeCurveStyle::drawLine(float, float, float, SPen::RectF*)",
                  "SPen::SmPath::moveTo(float, float)",
                  "SPen::SmPath::quadTo(float, float, float, float)",
                  "SPen::SmPath::getLength()",
                  "SPen::SmPath::getPosTan(float, SPen::SmPoint*, SPen::SmPoint*)",
                  "SPen::PencilStrokeStyle::getSize()"]
    set_canvas_name = "SPen::PenStrokeDrawableGL::SetCanvas(SPen::ISPPenCanvas*)"
    if set_canvas_name not in p.syms:
        raise RuntimeError("pinned PenCommon PenStrokeDrawableGL::SetCanvas symbol is missing")
    draw_names.append(set_canvas_name)
    watched = {p.syms[n]: n for n in redraw_names + draw_names if n in p.syms}
    set_size_name = "SPen::Pen::SetSize(float)"
    if set_size_name not in p.syms:
        raise RuntimeError("pinned PenCommon SetSize symbol is missing")
    watched[p.syms[set_size_name]] = set_size_name
    add_addr = p.syms[add_name]
    add_calls, route_calls, pending = [], [], {}
    selected_drawable_ref = [0]
    factory_entry = PENCIL_BASE + defined.get("createPenInst", 0)
    factory_pending, factory_returns = set(), []
    refresh_symbol_index()

    def nearest_symbol(address):
        candidates = [(entry, names) for entry, names in symbols_by_address.items()
                      if entry <= address]
        if not candidates:
            return None
        entry, names = max(candidates, key=lambda row: row[0])
        if address - entry > 0x4000:
            return None
        return {"names": names[:8], "entry": hex(entry), "offset": hex(address - entry)}

    def register_state(u):
        return {
            "pc": hex(u.reg_read(R.UC_ARM64_REG_PC)),
            "lr": hex(u.reg_read(R.UC_ARM64_REG_LR)),
            "sp": hex(u.reg_read(R.UC_ARM64_REG_SP)),
            "x0_x7": {f"x{i}": hex(u.reg_read(getattr(R, f"UC_ARM64_REG_X{i}")))
                      for i in range(8)},
            "s0_s7_bits": {f"s{i}": f"{u.reg_read(getattr(R, f'UC_ARM64_REG_S{i}')) & 0xffffffff:08x}"
                           for i in range(8)},
        }

    def safe_read(address, size):
        if not address or size < 0:
            return None
        try:
            return bytes(p.u.mem_read(address, size)).hex()
        except Exception:
            return None

    def invalid_memory_hook(u, access, address, size, value, _data):
        state = register_state(u)
        lr = u.reg_read(R.UC_ARM64_REG_LR)
        pc = u.reg_read(R.UC_ARM64_REG_PC)
        call_insn_hex = safe_read(max(0, lr - 4), 4)
        branch_register = None
        if call_insn_hex:
            call_insn = int.from_bytes(bytes.fromhex(call_insn_hex), "little")
            if call_insn & 0xFFFFFC1F == 0xD63F0000:  # AArch64 BLR Xn
                rn = (call_insn >> 5) & 0x1F
                if rn < 31:
                    branch_register = {"name": f"x{rn}",
                                       "value": hex(u.reg_read(getattr(R, f"UC_ARM64_REG_X{rn}")))}
        caller = nearest_symbol(lr)
        caller_entry = int(caller["entry"], 16) if caller else max(0, lr - 0x100)
        window_start = max(caller_entry, lr - 0x100)
        window_length = min(0x110, max(0, lr + 16 - window_start))
        invalid_memory_events.append({
            "access": int(access),
            "access_name": {19: "read_unmapped", 20: "write_unmapped",
                            21: "fetch_unmapped"}.get(int(access), "other_invalid_access"),
            "address": hex(address), "size": int(size), "value": hex(value),
            "cpu": state,
            "pc_nearest_symbol": nearest_symbol(pc),
            "lr_nearest_symbol": caller,
            "lr_callsite_instruction_at_lr_minus_4": call_insn_hex,
            "lr_callsite_is_blr": branch_register is not None,
            "unresolved_indirect_target_register": branch_register,
            "native_caller_code_window_start": hex(window_start),
            "native_caller_code_window_lr_minus_256_to_plus_16": safe_read(window_start, window_length),
            "lr_callsite_bytes_lr_minus_12_to_lr_plus_4": safe_read(max(0, lr - 12), 16),
            "last_native_events": native_events[-64:],
        })
        # Observe and stop. Do not map or emulate the unresolved fetch target.
        return False

    def vector_bytes(receiver):
        descriptor = p.get(receiver + 80, "Q")[0]
        if not descriptor: return {"descriptor": None, "floats_hex": ""}
        begin, end, capacity = p.get(descriptor, "QQQ")
        if (not begin <= end <= capacity or (end - begin) % 4
                or end - begin > 32 * 1024 * 1024):
            raise RuntimeError(f"invalid Pencil RTV1 vector at {descriptor:#x}")
        return {"descriptor": hex(descriptor), "begin_end_capacity": [hex(begin), hex(end), hex(capacity)],
                "floats_hex": bytes(p.u.mem_read(begin, end - begin)).hex()}
    def trace(u, address, _size, _data):
        if address == factory_entry:
            factory_pending.add(u.reg_read(R.UC_ARM64_REG_LR))
        elif address in factory_pending:
            factory_pending.remove(address)
            factory_returns.append({"pen": hex(p.x(0)), "return_pc": hex(address), "phase": phase[0]})
        if address == add_addr:
            receiver = p.x(0); before = vector_bytes(receiver); lr = u.reg_read(R.UC_ARM64_REG_LR)
            pending.setdefault(lr, []).append({"receiver": receiver, "before": before})
            add_calls.append({"phase": phase[0], "entry_pc": hex(address), "return_pc": hex(lr),
                              "x0_this": hex(receiver), "s0_s3_f32_bits": [f"{u.reg_read(getattr(R, f'UC_ARM64_REG_S{i}')) & 0xffffffff:08x}" for i in range(4)],
                              "typed_abi": {"x0": "this", "s0_s2": "Vector3<float> x/y/z", "s3": "float"},
                              "container_before": before})
        elif address in watched:
            method = watched[address]
            lr = u.reg_read(R.UC_ARM64_REG_LR)
            row = {"phase": phase[0], "entry": method, "pc": hex(address),
                   "x0_this": hex(p.x(0)), "x1": hex(p.x(1)), "x2": hex(p.x(2)),
                   "s0_s7_f32_bits": [f"{u.reg_read(getattr(R, f'UC_ARM64_REG_S{i}')) & 0xffffffff:08x}" for i in range(8)],
                   "lr": hex(lr)}
            if "PencilStrokeStyle::drawPoint" in method:
                style = p.x(0)
                owner = p.get(style + 8, "Q")[0] if style else 0
                owner_snapshot = {
                    "source": "PencilStrokeStyle::drawPoint at Pencil RVA 0x31d24..0x31d34",
                    "style_object": hex(style) if style else None,
                    "owner_pointer_at_style_plus_8": hex(owner) if owner else None,
                    "owner_bytes_0_to_31_hex": safe_read(owner, 32) if owner else None,
                    "owner_override_flag_byte_plus_9_hex": safe_read(owner + 9, 1) if owner else None,
                    "owner_override_width_f32_bits_plus_12_le": safe_read(owner + 12, 4) if owner else None,
                    "drawPoint_input_width_f32_bits_s0": row["s0_s7_f32_bits"][0],
                    "branch_semantics": "nonzero byte(owner+9) selects f32(owner+12) instead of input s0",
                }
                row["sm_point_x1_first8_hex"] = safe_read(p.x(1), 8)
                row["style_receiver_x0_prefix64_hex_raw_window"] = safe_read(p.x(0), 64)
                row["pencil_data_owner_readback"] = owner_snapshot
                pencil_data_owner_readbacks.append({"phase": phase[0], **owner_snapshot})
                pending_drawpoint_returns.setdefault(lr, []).append({
                    "phase": phase[0], "lr": hex(lr), "receiver": p.x(0),
                    "receiver_prefix64_before": row["style_receiver_x0_prefix64_hex_raw_window"]})
            if method == set_canvas_name:
                owner_this = p.x(0)
                canvas_arg = p.x(1)
                rt_member = p.get(owner_this + 16, "Q")[0] if owner_this else 0
                owner_row = {
                    "source_method": method,
                    "source_method_rva": hex(p.syms[set_canvas_name] - 0x1000000),
                    "entry_pc": hex(address), "caller_lr": hex(lr),
                    "this": hex(owner_this), "canvas_argument": hex(canvas_arg),
                    "this_plus_16_rt_member": hex(rt_member) if rt_member else None,
                    "owner_object": native_object_window(owner_this),
                    "rt_member_object": native_object_window(rt_member),
                    "owner_allocation": allocation_owner_of(owner_this),
                    "rt_member_allocation": allocation_owner_of(rt_member),
                    "canvas_matches_native_pen_canvas": canvas_arg == getattr(p, "pen_canvas", 0),
                    "owner_matches_selected_drawable": None,
                }
                canvas_owner_rows.append(owner_row)
                row["penstroke_setcanvas_owner_snapshot"] = owner_row
            if "SmPath::getPosTan" in method:
                row["distance_s0_f32_bits"] = f"{u.reg_read(R.UC_ARM64_REG_S0) & 0xffffffff:08x}"
                pending_smpath_returns.setdefault(lr, []).append({
                    "phase": phase[0], "lr": hex(lr), "path": p.x(0),
                    "position_out": p.x(1), "tangent_out": p.x(2),
                    "distance_s0_f32_bits": row["distance_s0_f32_bits"]})
                smpath_call_entries.append(row.copy())
            route_calls.append(row)
        if address in pending_smpath_returns:
            for item in pending_smpath_returns.pop(address):
                smpath_call_returns.append({**item, "return_pc": hex(address),
                    "return_x0": hex(u.reg_read(R.UC_ARM64_REG_X0)),
                    "position_out_first8_hex": safe_read(item["position_out"], 8),
                    "tangent_out_first8_hex": safe_read(item["tangent_out"], 8)})
        if address in pending_drawpoint_returns:
            for item in pending_drawpoint_returns.pop(address):
                pencil_drawpoint_state.append({**item, "return_pc": hex(address),
                    "receiver_prefix64_after": safe_read(item["receiver"], 64)})
        for lr in list(pending):
            if address == lr:
                for item in pending.pop(lr):
                    item["after"] = vector_bytes(item["receiver"])
                    # Attach the post-state to the matching most recent entry.
                    for record in reversed(add_calls):
                        if record["return_pc"] == hex(lr) and "container_after" not in record:
                            record["container_after"] = item["after"]; break
    p.u.hook_add(UC_HOOK_CODE, trace)

    return_watch_names = (
        "SPen::ObjectStroke::GetPointCount() const",
        "SPen::ObjectStroke::GetPenName() const",
        "SPen::ObjectStroke::GetAdvancedPenSetting() const",
        "SPen::ObjectBase::IsVisible() const",
        "SPen::PenManager::GetPenData(SPen::String*)",
        "SPen::PenManagerST::GetPen(SPen::String*)",
        "SPen::SmPath::getLength()",
        "SPen::SmPath::getPosTan(float, SPen::SmPoint*, SPen::SmPoint*)",
        "SPen::PencilStrokeStyle::getSize()",
    )
    missing_return_watch_symbols = []
    for watch_name in return_watch_names:
        watch_address = p.syms.get(watch_name)
        if watch_address is None:
            missing_return_watch_symbols.append(watch_name)
        else:
            return_watch_by_address[watch_address] = watch_name

    cases = []
    vtable_symbols = [int(fields[0], 16) for line in nm_demangled.splitlines()
                      if (fields := line.strip().split(" ", 2)) and len(fields) == 3
                      and fields[1] in ("D", "V")
                      and fields[2] == "vtable for SPen::PencilStrokeDrawableGLV1"]
    if len(vtable_symbols) != 1:
        raise RuntimeError(f"expected one pinned GLV1 vtable symbol, got {vtable_symbols}")
    pencil_vtables = []
    for line in nm_demangled.splitlines():
        fields = line.strip().split(" ", 2)
        if (len(fields) == 3 and fields[1] in ("D", "V")
                and fields[2].startswith("vtable for SPen::Pencil")):
            symbol_value = int(fields[0], 16)
            pencil_vtables.append({"name": fields[2], "symbol": hex(PENCIL_BASE + symbol_value),
                                   "address_point": hex(PENCIL_BASE + symbol_value + 16)})

    def object_identity(address):
        if not address:
            return {"object": None, "vptr": None, "vtable_match": None}
        try:
            vptr = p.get(address, "Q")[0]
        except Exception as exc:
            return {"object": hex(address), "vptr": None,
                    "read_error": f"{type(exc).__name__}: {exc}", "vtable_match": None}
        matches = [row["name"] for row in pencil_vtables
                   if int(row["address_point"], 16) == vptr]
        return {"object": hex(address), "vptr": hex(vptr),
                "vtable_match": matches if matches else None,
                "pencil_vtable_candidates": matches}

    def safe_rt_state(address):
        if not address:
            return None
        try:
            return vector_bytes(address)
        except Exception as exc:
            return {"snapshot_error": f"{type(exc).__name__}: {exc}"}

    # This first material oracle is intentionally the already grounded cold
    # default case. Cache mutation controls remain in immutable V9 evidence.
    case_specs = (("fresh_default_s2_p050", 2.0, [0.5, 0.5, 0.5, 0.5], None),)
    for setting_state, pen_size, pressure, advanced_setting in case_specs:
        phase[0] = setting_state
        pixel_evidence_start = len(draw_pixel_evidence)
        obj = p.alloc(256); impl = p.alloc(512)
        call("SPen::ObjectStroke::ObjectStroke()", [obj])
        call("SPen::ObjectStrokeImpl::ObjectStrokeImpl(SPen::ObjectStroke*)", [impl, obj])
        p.put(obj + 32, "Q", impl)
        call("SPen::ObjectStroke::SetPenName(SPen::String const*)", [obj, make_string(PEN_NAME)])
        if advanced_setting is not None:
            call("SPen::ObjectStroke::SetAdvancedPenSetting(SPen::String const*)", [obj, make_string(advanced_setting)])
        call("SPen::ObjectStroke::SetPenSize(float)", [obj], [pen_size])
        call("SPen::ObjectStroke::SetToolType(SPen::ToolType)", [obj, 2])
        call("SPen::ObjectStroke::SetStrokeType(SPen::StrokeType)", [obj, 0])
        call("SPen::ObjectStroke::SetColor(unsigned int)", [obj, 0xFF000000])
        call("SPen::ObjectStroke::SetCurveEnabled(bool)", [obj, 1])
        call("SPen::ObjectBase::SetVisibility(bool)", [obj, 1])
        points = [(0.0, 0.0), (10.0, 0.0), (20.0, 0.0), (30.0, 10.0)]
        timestamps = [10, 20, 30, 40]
        tilt = [0.0] * 4; orientation = [0.0] * 4
        pts, prs, ts, tl, ori = (p.alloc(n) for n in (32, 16, 16, 16, 16))
        p.put(pts, "8f", *(v for xy in points for v in xy)); p.put(prs, "4f", *pressure)
        p.put(ts, "4i", *timestamps); p.put(tl, "4f", *tilt); p.put(ori, "4f", *orientation)
        call("SPen::ObjectStroke::SetPoint(SPen::PointF const*, float const*, int const*, float const*, float const*, int)",
             [obj, pts, prs, ts, tl, ori, 4])
        getters = {}
        for label, name in (("points", "GetPoint() const"), ("pressure", "GetPressure() const"),
                            ("timestamps", "GetTimeStamp() const"), ("tilt", "GetTilt() const"),
                            ("orientation", "GetOrientation() const")):
            call("SPen::ObjectStroke::" + name, [obj]); getters[label] = p.x(0)
        call("SPen::ObjectStroke::GetPointCount() const", [obj]); point_count = p.x(0)
        call("SPen::ObjectStroke::GetPenName() const", [obj]); source_pen_name_ptr = p.x(0)
        source_pen_name = string_utf8_snapshot(source_pen_name_ptr)
        call("SPen::ObjectBase::IsVisible() const", [obj]); source_visibility = bool(p.x(0))
        call("SPen::ObjectStroke::GetAdvancedPenSetting() const", [obj]); advanced_ptr = p.x(0)
        advanced_hex = bytes(p.u.mem_read(advanced_ptr, 32)).hex() if advanced_ptr else None
        if advanced_setting == "" and not advanced_ptr:
            raise RuntimeError("explicit empty setting did not produce a String object")
        loader.clear(); add_start = len(add_calls); route_start = len(route_calls)
        factory_start = len(factory_returns)
        rand_start = len(rand_trace); srand_start = len(srand_trace)
        host_rng_start = len(host_rng_calls); set_srand_start = len(set_srand_calls)
        clock_start = len(clock_gettime_calls)
        queue_start = len(queue_submissions)
        native_event_start = len(native_events)
        native_import_start = len(native_import_events)
        native_return_start = len(native_return_events)
        smpath_return_start = len(smpath_call_returns)
        drawpoint_state_start = len(pencil_drawpoint_state)
        owner_readback_start = len(pencil_data_owner_readbacks)
        native_call_start = len(native_call_attempts)
        try:
            rc = call("SPen::ObjectDrawing::drawObjectStroke(SPen::ISPCanvas&, SPen::ISPPenCanvas&, SPen::ObjectStroke const*, bool)",
                      [drawing, p.draw_canvas, p.pen_canvas, obj, 1])
        except NativeCallDiagnostic:
            raise
        except Exception as exc:
            invalid = invalid_memory_events[-1] if invalid_memory_events else None
            candidate_pen = int(factory_returns[-1]["pen"], 16) if len(factory_returns) > factory_start else 0
            partial_addpoint_calls = []
            for record in add_calls[add_start:]:
                partial = dict(record)
                if "container_after" not in partial:
                    partial["container_state_at_failure"] = safe_rt_state(
                        int(partial["x0_this"], 16))
                partial_addpoint_calls.append(partial)
            drawable = 0
            getter_result = {"status": "not_called", "drawable": None}
            if candidate_pen:
                try:
                    phase[0] = "post_dispatch_failure_getter"
                    drawable = call("SPen::Pencil::GetStrokeDrawableGL()", [candidate_pen], limit=100_000)
                    getter_result = {"status": "returned", "drawable": hex(drawable) if drawable else None}
                except NativeCallDiagnostic:
                    raise
                except Exception as getter_exc:
                    getter_result = {"status": "failed", "error": f"{type(getter_exc).__name__}: {getter_exc}"}
                finally:
                    phase[0] = setting_state
            if drawable:
                getter_result["drawable_identity"] = object_identity(drawable)
                getter_result["rtv1_state"] = safe_rt_state(drawable)
            case_failure = {
                "case": setting_state,
                "source_object": hex(obj),
                "source_object_stroke_arrays": {
                    "point_count": point_count,
                    "pen_name": source_pen_name,
                    "is_visible_getter": source_visibility,
                    "array_bytes_hex": {key: safe_read(getters[key], size)
                        for key, size in (("points", 32), ("pressure", 16), ("timestamps", 16),
                                          ("tilt", 16), ("orientation", 16))},
                    "advanced_getter_32_bytes": advanced_hex,
                },
                "loader_events": list(loader),
                "factory_returns": factory_returns[factory_start:],
                "actual_pen": object_identity(candidate_pen),
                "actual_drawable_getter": getter_result,
                "partial_native_AddPoint_calls": partial_addpoint_calls,
                "partial_geometry_AddPoint_count": len(partial_addpoint_calls),
                "pencil_data_owner_readbacks": pencil_data_owner_readbacks[owner_readback_start:],
                "route_calls": route_calls[route_start:],
                "native_rng": {
                    "host_rng_events": host_rng_calls[host_rng_start:],
                    "rand_returns": rand_trace[rand_start:],
                    "srand_seeds": srand_trace[srand_start:],
                    "PenUtil_SetSrand_entries": set_srand_calls[set_srand_start:],
                },
                "host_clock_gettime_calls": clock_gettime_calls[clock_start:],
                "native_PostTask_submissions": queue_submissions[queue_start:],
                "callback_queue_deferred_count": len(queue_submissions[queue_start:]),
            }
            result = {
                "schema": "sdocx-old-pencil-native-drawing-diagnostic.v6",
                "status": "native_dispatch_failed_with_diagnostic",
                "scope": "Actual Drawing/ObjectStroke route; native SPPenCanvas, native SPBitmap factory result, setup task queue, and accepted callback queue; no Pencil/callback virtual target is substituted.",
                "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL),
                         "analysis_dso_sha256": digest(PENCIL_ANALYSIS)},
                "source_interface_proof": {
                    "canvas_constructor": "SPen::SPPenCanvas::SPPenCanvas(SPen::IGLMsgQueue*, SPen::ISPBitmap*)",
                    "bitmap_producer": bitmap_factory_symbol,
                    "canvas_get_queue_vtable_byte_offset": 184,
                    "canvas_get_bitmap_vtable_byte_offset": 192,
                    "GetBitmap_requires_impl_and_bitmap": "pinned libSPenGraphics.so GetBitmap ELF 0xaef08 loads [canvas+32], then [impl+8]",
                    "constructor_nonnull_gate": "pinned libSPenGraphics.so constructor ELF 0xae260 calls bitmap vtable byte offset +168 and branches on returned texture at ELF 0xae2dc before constructing SPenCanvasImpl",
                    "bitmap_evidence_runner_sha256": PIN["brush_canvas_runner"],
                    "bitmap_evidence_json_sha256": PIN["brush_canvas_evidence"],
                },
                "failure": {
                    "phase": setting_state,
                    "exception_type": type(exc).__name__,
                    "exception": str(exc),
                    "invalid_memory_events": invalid_memory_events[-8:],
                    "terminal_invalid_memory": invalid,
                    "last_native_symbol_events": native_events[-64:],
                    "likely_native_caller": (invalid or {}).get("lr_nearest_symbol"),
                    "unresolved_virtual_target": (invalid or {}).get("address"),
                    "callsite_instruction_at_lr_minus_4": (invalid or {}).get(
                        "lr_callsite_instruction_at_lr_minus_4"),
                    "indirect_target_register": (invalid or {}).get(
                        "unresolved_indirect_target_register"),
                    "native_caller_code_window": (invalid or {}).get(
                        "native_caller_code_window_lr_minus_256_to_plus_16"),
                },
                "runtime": {"helper": str(RUNTIME.relative_to(ROOT)),
                    "context": [1920, 1080],
                    "clock_service_profile": clock_service_profile,
                    "native_pen_canvas": native_pen_canvas,
                    "bitmap_factory": bitmap_factory_record,
                    "bitmap_setup_queue": {"queue": hex(bitmap_setup_queue),
                        "task_count": len(bitmap_setup_tasks), "tasks": bitmap_setup_tasks},
                    "callback_queue_deferred_count": len(queue_submissions),
                    "callback_queue_deferred_tasks": queue_submissions,
                    "random_profile": {"implementation": "host glibc libc.so.6",
                        "path": str(libc_path), "sha256": digest(libc_path),
                        "version": libc_version, "initial_harness_seed_u32": args.initial_seed,
                        "forced_values": random_values,
                        "boundary": "host libc is recorded input, not Android/Samsung RNG evidence"}},
                "partial_case": case_failure,
                "native_call_history": native_call_attempts,
                "native_import_events": native_import_events,
                "strncpy_calls": strncpy_calls,
                "interpretation_boundary": "The host adapter retains accepted native tasks without running them inside the native callback destructor.",
            }
            emit_json(result, args.output)
            return
        set_size = [row for row in route_calls[route_start:] if "Pen::SetSize" in row.get("entry", "")]
        created = [row for row in loader if row.get("fn") == "dlsym" and row.get("name") == "createPenInst"]
        selected_pen = int(factory_returns[-1]["pen"], 16) if len(factory_returns) > factory_start else 0
        if not selected_pen:
            pen_data_events = [row for row in native_return_events[native_return_start:]
                if row.get("symbol") == "SPen::PenManager::GetPenData(SPen::String*)"]
            pen_manager_get_events = [row for row in native_return_events[native_return_start:]
                if row.get("symbol") == "SPen::PenManagerST::GetPen(SPen::String*)"]
            pen_data_pointer = (int(pen_data_events[-1]["return_x0"], 16)
                                if pen_data_events and int(pen_data_events[-1]["return_x0"], 16) else 0)
            cached_pen_pointer = p.get(pen_data_pointer + 16, "Q")[0] if pen_data_pointer else 0
            cache_slot = p.get(drawing + 144, "Q")[0]
            manager_slot = p.get(drawing + 16, "Q")[0]
            pen_data_identity = object_identity(pen_data_pointer) if pen_data_pointer else None
            cached_pen_identity = object_identity(cached_pen_pointer) if cached_pen_pointer else None
            case_result = {
                "case": setting_state,
                "status": "drawing_returned_without_createPenInst",
                "source_object": hex(obj),
                "synthetic_input": {"tool_type": 2, "stroke_type": 0,
                    "pen_size_f32": pen_size, "color_argb": "0xff000000", "curve_enabled": True,
                    "points": points, "pressure": pressure, "timestamps": timestamps,
                    "tilt": tilt, "orientation": orientation},
                "source_getters": {
                    "point_count": point_count, "points_hex": safe_read(getters["points"], 32),
                    "pressure_hex": safe_read(getters["pressure"], 16),
                    "timestamps_hex": safe_read(getters["timestamps"], 16),
                    "tilt_hex": safe_read(getters["tilt"], 16),
                    "orientation_hex": safe_read(getters["orientation"], 16),
                    "pen_name": source_pen_name, "is_visible": source_visibility,
                    "advanced_setting_pointer": hex(advanced_ptr) if advanced_ptr else None,
                    "advanced_setting_hex": advanced_hex},
                "drawing_return": rc,
                "loader_events": list(loader),
                "createPenInst_dlsym_observed": bool(created),
                "native_factory_returns": factory_returns[factory_start:],
                "native_pen_getter": {"status": "not called; no selected native factory instance returned",
                    "selected_pen": None, "selected_vptr": None, "getVersion": None,
                    "GetStrokeDrawableGL": None},
                "drawing_cache_readback": {
                    "drawing_object": hex(drawing), "PenManager_member_offset_16": hex(manager_slot),
                    "cached_pen_data_member_offset_144": hex(cache_slot),
                    "PenManager_GetPenData_returns": pen_data_events,
                    "PenManagerST_GetPen_returns": pen_manager_get_events,
                    "returned_PenData_identity": pen_data_identity,
                    "PenData_plus_16_IPen_identity_from_native_layout": cached_pen_identity,
                    "interpretation": "ObjectDrawing::drawObjectStroke reads PenManager* at +16; on the path where GetPenData is null, pinned Drawing control flow returns with false before redrawIPen."},
                "native_canvas": native_pen_canvas,
                "bitmap_factory": bitmap_factory_record,
                "bitmap_dimensions": [actual_bitmap_width, actual_bitmap_height],
                "native_canvas_clip_setup": native_canvas_clip_setup,
                "pencil_texture_uploads": pencil_mesa_uploads,
                "callback_queue": {"submissions": queue_submissions[queue_start:],
                    "submission_count": len(queue_submissions[queue_start:]),
                    "run_not_called": not any(row.get("run_state") == "native_Run_returned_by_controlled_scheduler" for row in queue_submissions[queue_start:]),
                    "controlled_native_runs": [run for run in native_task_runs if run["sequence"] >= queue_start],
                    "pending_native_tasks": [row for row in queue_submissions[queue_start:] if row.get("run_state") == "deferred_not_run"]},
                "native_call_history": native_call_attempts[native_call_start:],
                "native_return_events": native_return_events[native_return_start:],
                "native_import_events": native_import_events[native_import_start:],
                "host_clock_gettime_calls": clock_gettime_calls[clock_start:],
                "pencil_texture_source_trace": {
                    "setTextures_entries": pencil_settextures_entries,
                    "setTextures_operator_new_array_calls": pencil_array_new_calls,
                    "host_operator_new_array_allocator_calls": pencil_native_array_allocator_calls,
                    "setTextures_operator_new_array": pencil_array_allocations,
                    "SPTextureBitmap_UpdateBitmap": pencil_bitmap_update_events,
                    "SPSubBitmapRT_UpdateBitmap": graphics_subbitmap_update_events,
                    "TextureObject_CreateTexture": pencil_texture_create_events,
                    "Renderer_TextureObject_Update": renderer_texture_update_events,
                    "Mesa_texture_allocations": pencil_texture_allocation_events,
                    "Mesa_texture_uploads": pencil_mesa_uploads,
                    "glPixelStorei": pixel_store_events},
                "native_symbol_events": native_events[native_event_start:],
                "native_interpolation_trace": {
                    "SmPath_getPosTan_returns": smpath_call_returns[smpath_return_start:],
                    "drawPoint_SmPoint_and_receiver_state_windows": pencil_drawpoint_state[drawpoint_state_start:],
                    "note": "SmPoint bytes are limited to the first 8 bytes (x/y output contract); style receiver windows are raw 64-byte prefixes without inferred field layout."},
                "pencil_data_owner_readbacks": pencil_data_owner_readbacks[owner_readback_start:],
                "route_calls": route_calls[route_start:],
                "AddPoint_calls": add_calls[add_start:],
                "host_rng_events": host_rng_calls[host_rng_start:],
            }
            cases.append(case_result)
            continue
        drawable = call("SPen::Pencil::GetStrokeDrawableGL()", [selected_pen]) if selected_pen else 0
        selected_drawable_ref[0] = drawable
        for owner in canvas_owner_rows:
            owner["owner_matches_selected_drawable"] = owner.get("this") == hex(drawable)
            owner["owner_is_selected_drawable_plus_8"] = (int(owner.get("this", "0"), 16) == drawable + 8) if drawable else False
        native_pen_version = None
        if selected_pen:
            call("SPen::Pen::getVersion()", [selected_pen])
            native_pen_version = p.x(0)
        drawable_vptr = p.get(drawable, "Q")[0] if drawable else 0
        dispatch_rows = {row["sequence"]: row for row in queue_submissions}
        if args.dispatch_through >= 1:
            if drawable == 0 or 2 not in dispatch_rows:
                dispatch_blockers.append({"guard": "selected_drawable_and_rt_init_task_present",
                    "selected_drawable": hex(drawable) if drawable else None,
                    "sequence_2_present": 2 in dispatch_rows})
            rt = (p.get(int(dispatch_rows[2]["task"], 16) + 16, "Q")[0]
                  if 2 in dispatch_rows else 0)
            rt_vptr = p.get(rt, "Q")[0] if rt else 0
            rt_typeinfo = p.get(rt_vptr - 8, "Q")[0] if rt_vptr >= 8 else 0
            rt_vtable_names = [name for name, address in p.syms.items()
                if name.startswith("vtable for SPen::") and address + 16 == rt_vptr]
            rt_typeinfo_names = [name for name, address in p.syms.items()
                if name.startswith("typeinfo for SPen::") and address == rt_typeinfo]
            rt_slot_48 = p.get(rt_vptr + 0x48, "Q")[0] if rt_vptr else 0
            rt_slot_48_names = [name for name, address in p.syms.items() if address == rt_slot_48]
            setcanvas_owner_matches = [owner for owner in canvas_owner_rows
                if owner.get("this_plus_16_rt_member") == hex(rt)
                and owner.get("canvas_argument") == hex(actual_pen_canvas)]
            selected_allocation = allocation_owner_of(drawable)
            for owner in setcanvas_owner_matches:
                owner["shares_selected_drawable_allocation"] = bool(selected_allocation and
                    owner.get("owner_allocation", {}).get("base") == selected_allocation.get("base"))
            setcanvas_rt_role = {
                "role": "SetCanvas-owned PenDrawableRT receiver",
                "task_receiver": hex(rt) if rt else None,
                "receiver_vptr": hex(rt_vptr) if rt_vptr else None,
                "receiver_typeinfo": hex(rt_typeinfo) if rt_typeinfo else None,
                "receiver_vtable_symbols": rt_vtable_names,
                "receiver_typeinfo_symbols": rt_typeinfo_names,
                "virtual_slot_byte_offset": "0x48",
                "virtual_slot_target": hex(rt_slot_48) if rt_slot_48 else None,
                "virtual_slot_target_symbols": rt_slot_48_names,
                "expected_CreatePenCanvas_target": hex(p.syms.get("SPen::PencilStrokeDrawableRTV1::CreatePenCanvas(int, int, SPen::IGLMsgQueue*)", 0)),
                "virtual_slot_matches_CreatePenCanvas": rt_slot_48 == p.syms.get("SPen::PencilStrokeDrawableRTV1::CreatePenCanvas(int, int, SPen::IGLMsgQueue*)"),
                "setcanvas_owner_match_count": len(setcanvas_owner_matches),
                "setcanvas_owner_matches": setcanvas_owner_matches,
                "matches_selected_gl_object": any(owner.get("owner_matches_selected_drawable") for owner in setcanvas_owner_matches),
                "matches_canvas_clip_impl": rt == actual_canvas_impl,
                "allocation_owner": allocation_owner_of(rt),
                "selected_drawable_allocation": selected_allocation,
            }
            if len(setcanvas_owner_matches) != 1:
                dispatch_blockers.append({"guard": "unique_native_SetCanvas_owner_for_task_receiver",
                    "sequence": 2, "diagnostic": setcanvas_rt_role,
                    "action": "retain deferred tasks and emit diagnostic; do not dispatch RT work"})
            if setcanvas_owner_matches and not any(owner.get("shares_selected_drawable_allocation") for owner in setcanvas_owner_matches):
                dispatch_blockers.append({"guard": "SetCanvas_owner_belongs_to_selected_drawable_allocation",
                    "sequence": 2, "diagnostic": setcanvas_rt_role,
                    "action": "retain deferred tasks; selected GL/RT owner relationship remains unknown"})
            if rt == actual_canvas_impl:
                dispatch_blockers.append({"guard": "pen_rt_is_distinct_from_canvas_clip_container",
                    "sequence": 2, "diagnostic": setcanvas_rt_role,
                    "action": "retain deferred tasks; do not treat CanvasImpl as selected Pencil RT"})
            if not setcanvas_rt_role["virtual_slot_matches_CreatePenCanvas"]:
                dispatch_blockers.append({"guard": "native_RT_slot_0x48_resolves_to_CreatePenCanvas",
                    "sequence": 2, "diagnostic": setcanvas_rt_role,
                    "action": "retain deferred tasks; do not invoke an unproven virtual target"})
            dispatch_specs = {
                1: {"task_vtable_symbol": "vtable for SPen::WorkerTask::Member1<SPen::SPPenCanvasImpl, void (SPen::SPPenCanvasImpl::*)(SPen::ClipInfo), SPen::ClipInfo>",
                    "run_method": "0x40aefe0", "caller_lr": "0x40aed0c", "receiver": actual_canvas_impl,
                    "member_method": 0x40AFF84, "method_symbol": "SPen::SPPenCanvasImpl::AddClipRectRT(SPen::ClipInfo)", "identity": "SPenCanvasImpl::AddClipRectRT(ClipInfo)"},
                2: {"task_vtable_symbol": "vtable for SPen::WorkerTask::Member3<SPen::PenDrawableRT, void (SPen::PenDrawableRT::*)(int, int, SPen::IGLMsgQueue*), int, int, SPen::IGLMsgQueue*>",
                    "run_method": "0x104a274", "caller_lr": "0x1049ffc", "receiver": rt,
                    "member_method": 0x48, "identity": "PenDrawableRT virtual slot +0x48 (target recorded from task receiver vptr)"},
                3: {"task_vptr": hex(PENCIL_BASE + 0x398A8), "run_method": hex(PENCIL_BASE + 0x2E5F0), "caller_lr": "0xb02e104",
                    "typeinfo_symbol": "typeinfo for SPen::WorkerTask::Member1<SPen::PenDrawableRT, void (SPen::PenDrawableRT::*)(bool), bool>",
                    "receiver": rt, "member_method": 0x104A4A4, "method_symbol": "SPen::PenDrawableRT::SetRedrawState(bool)", "identity": "PenDrawableRT::SetRedrawState(bool)"},
                4: {"task_vptr": hex(PENCIL_BASE + 0x39B18), "run_method": hex(PENCIL_BASE + 0x2D770), "caller_lr": "0xb02ca1c",
                    "typeinfo_symbol": "typeinfo for SPen::WorkerTask::Member2<SPen::PenDrawableRT, void (SPen::PenDrawableRT::*)(float, int), float, int>",
                    "receiver": rt, "member_method": 0x104A558, "method_symbol": "SPen::PenDrawableRT::SetPenData(float, int)", "identity": "PenDrawableRT::SetPenData(float,int)"},
                5: {"task_vptr": hex(PENCIL_BASE + 0x39D28), "run_method": hex(PENCIL_BASE + 0x2E5C4), "caller_lr": "0xb02debc",
                    "typeinfo_symbol": "typeinfo for SPen::WorkerTask::Member1<SPen::PenDrawableRT, void (SPen::PenDrawableRT::*)(SPen::RectF), SPen::RectF>",
                    "receiver": rt, "member_method": 0x104A4AC, "method_symbol": "SPen::PenDrawableRT::SetRect(SPen::RectF)", "identity": "PenDrawableRT::SetRect(RectF)"},
                6: {"task_vtable_symbol": "vtable for SPen::WorkerTask::Member2<SPen::PenDrawableRT, void (SPen::PenDrawableRT::*)(std::__ndk1::vector<float, std::__ndk1::allocator<float> >*, std::__ndk1::vector<float, std::__ndk1::allocator<float> >*), std::__ndk1::vector<float, std::__ndk1::allocator<float> >*, std::__ndk1::vector<float, std::__ndk1::allocator<float> >*>",
                    "run_method": "0x10506b4", "caller_lr": "0x10504d4", "receiver": rt,
                    "member_method": 0x104A5C4, "method_symbol": "SPen::PenDrawableRT::SendDataToGPU(std::__ndk1::vector<float, std::__ndk1::allocator<float> >*, std::__ndk1::vector<float, std::__ndk1::allocator<float> >*)", "identity": "PenDrawableRT::SendDataToGPU(vector*,vector*)"},
                7: {"task_vtable_symbol": "vtable for SPen::PenGLRenderMsg", "run_method": "0x104676c", "caller_lr": "0x105059c",
                    "identity": "PenGLRenderMsg::Run()"},
                8: {"task_vtable_symbol": "vtable for SPen::WorkerTask::Delete<std::__ndk1::vector<float, std::__ndk1::allocator<float> > >",
                    "run_method": "0x1045e6c", "caller_lr": "0x1045990", "identity": "WorkerTask::Delete<vector<float>>"},
                9: {"task_vptr": hex(PENCIL_BASE + 0x39908), "run_method": hex(PENCIL_BASE + 0x2E700), "caller_lr": "0xb02e4f8",
                    "typeinfo_symbol": "typeinfo for SPen::WorkerTask::Member1<SPen::PenStrokeDataManager, void (SPen::PenStrokeDataManager::*)(int), int>",
                    "member_method": 0x1050FD0, "method_symbol": "SPen::PenStrokeDataManager::ReleaseStrokeData(int)", "identity": "PenStrokeDataManager::ReleaseStrokeData(int)"},
            }
            for sequence in range(1, args.dispatch_through + 1):
                if sequence >= 2 and dispatch_blockers:
                    break
                row = dispatch_rows.get(sequence)
                spec = dispatch_specs[sequence]
                if row is None:
                    raise RuntimeError(f"source-verified queue prefix is missing sequence {sequence}")
                for field in ("task_vptr", "task_vtable_symbol", "run_method", "caller_lr"):
                    if field in spec and row.get(field) != spec[field]:
                        raise RuntimeError(f"Pencil task {sequence} {field} does not match the pinned source case")
                task = int(row["task"], 16)
                if sequence == 2:
                    width, height = struct.unpack("<ii", bytes(p.u.mem_read(task + 40, 8)))
                    queue_arg = p.get(task + 48, "Q")[0]
                    if (p.get(task + 32, "Q")[0] != 1
                            or (width, height) != (actual_bitmap_width, actual_bitmap_height)
                            or queue_arg != queue
                            or p.get(p.get(rt, "Q")[0] + 0x48, "Q")[0] != PENCIL_BASE + 0x2EFA8):
                        raise RuntimeError("CreatePenCanvas task method, width, height, or queue differs from native owner")
                if "typeinfo_symbol" in spec:
                    typeinfo = p.rtti_syms.get(spec["typeinfo_symbol"])
                    if not typeinfo or p.get(int(row["task_vptr"], 16) - 8, "Q")[0] != typeinfo:
                        raise RuntimeError(f"Pencil task {sequence} local vtable RTTI does not resolve to {spec['typeinfo_symbol']}")
                if "receiver" in spec and p.get(task + 16, "Q")[0] != spec["receiver"]:
                    raise RuntimeError(f"Pencil task {sequence} receiver does not match its native owner")
                if sequence == 7:
                    payload_rt = p.get(task + 32, "Q")[0]
                    payload_canvas = p.get(task + 40, "Q")[0]
                    if payload_rt != rt or payload_canvas != actual_pen_canvas:
                        raise RuntimeError("PenGLRenderMsg payload does not target selected native RT and canvas")
                    if row.get("allocation_size") != 144:
                        raise RuntimeError("PenGLRenderMsg native allocation is not the captured 144-byte layout")
                if sequence == 8:
                    vector_from_send = p.get(int(dispatch_rows[6]["task"], 16) + 40, "Q")[0]
                    if not vector_from_send or p.get(task + 16, "Q")[0] != vector_from_send:
                        raise RuntimeError("vector delete task owner differs from SendDataToGPU source vector")
                if sequence == 9:
                    if p.get(task + 16, "Q")[0] == 0:
                        raise RuntimeError("stroke data release task has null PenStrokeDataManager receiver")
                if sequence == 3 and (p.get(task + 40, "I")[0] != 1):
                    raise RuntimeError("SetRedrawState task payload is not native true")
                if sequence == 4:
                    size_bits, color = struct.unpack("<fI", bytes(p.u.mem_read(task + 40, 8)))
                    if struct.pack("<f", size_bits) != struct.pack("<f", 2.0) or color != 0xFF000000:
                        raise RuntimeError("SetPenData task differs from captured size/color inputs")
                if sequence == 5:
                    rect = struct.unpack("<4f", bytes(p.u.mem_read(task + 40, 16)))
                    if rect != (-2.0, -2.0, 36.0, 16.0):
                        raise RuntimeError(f"SetRect task differs from captured native bounds: {rect}")
                if sequence == 6:
                    if (p.get(task + 40, "Q")[0] == 0 or p.get(task + 48, "Q")[0] != 0):
                        raise RuntimeError("SendDataToGPU task vector arguments differ from native capture")
                if sequence == 9 and p.get(task + 40, "I")[0] != 0:
                    raise RuntimeError("ReleaseStrokeData task id differs from native source event")
                dispatch_native_task(row, spec)
        vtable_symbol = PENCIL_BASE + vtable_symbols[0]
        expected_address_point = vtable_symbol + 16
        cases.append({"case": setting_state, "bitmap_source_provenance": bitmap_source_provenance, "synthetic_input": {"tool_type": 2, "stroke_type": 0,
            "pen_size_f32": pen_size, "color_argb": "0xff000000", "curve_enabled": True,
            "points": points, "pressure": pressure, "timestamps": timestamps,
            "tilt": tilt, "orientation": orientation},
            "source_getters": {"count": point_count,
                "pen_name": source_pen_name,
                "is_visible": source_visibility,
                "array_bytes_hex": {"points": bytes(p.u.mem_read(getters["points"], 32)).hex(),
                    "pressure": bytes(p.u.mem_read(getters["pressure"], 16)).hex(),
                    "timestamps": bytes(p.u.mem_read(getters["timestamps"], 16)).hex(),
                    "tilt": bytes(p.u.mem_read(getters["tilt"], 16)).hex(),
                    "orientation": bytes(p.u.mem_read(getters["orientation"], 16)).hex()},
                "advanced_getter_pointer": hex(advanced_ptr) if advanced_ptr else None,
                "advanced_getter_pointer_nonnull": bool(advanced_ptr),
                "advanced_getter_32_bytes": advanced_hex},
            "drawing_return": rc, "loader_events": list(loader),
            "native_Pencil_factory_returns": factory_returns[factory_start:],
            "actual_selected_pen": object_identity(selected_pen),
            "native_pen_getVersion": native_pen_version,
            "selected_drawable": {"object": hex(drawable) if drawable else None,
                "primary_vptr": hex(drawable_vptr) if drawable_vptr else None,
                "expected_GLV1_vtable_address_point": hex(expected_address_point),
                "is_GLV1": drawable_vptr == expected_address_point},
            "AddPoint_calls": add_calls[add_start:], "route_calls": route_calls[route_start:],
            "native_PostTask_submissions": queue_submissions[queue_start:],
            "post_draw_submission_count": len(queue_submissions[queue_start:]),
            "post_draw_pending_tasks": sum(row.get("run_state") == "deferred_not_run" for row in queue_submissions[queue_start:]),
            "srand_seeds": list(srand_trace[srand_start:]), "rand_returns": list(rand_trace[rand_start:]),
            "PenUtil_SetSrand_entries": set_srand_calls[set_srand_start:],
            "host_rng_events": host_rng_calls[host_rng_start:],
            "host_clock_gettime_calls": clock_gettime_calls[clock_start:],
            "pencil_texture_uploads": pencil_mesa_uploads,
            "native_interpolation_trace": {
                "SmPath_getPosTan_returns": smpath_call_returns[smpath_return_start:],
                "drawPoint_SmPoint_and_receiver_state_windows": pencil_drawpoint_state[drawpoint_state_start:],
                "note": "SmPoint bytes are limited to the first 8 bytes (x/y output contract); style receiver windows are raw 64-byte prefixes without inferred field layout."},
            "pencil_data_owner_readbacks": pencil_data_owner_readbacks[owner_readback_start:],
            "dispatched_native_tasks": [row for row in native_task_runs],
            "scheduler_blockers": dispatch_blockers,
            "SetCanvas_rt_role_ledger": setcanvas_rt_role if args.dispatch_through >= 1 and 2 in dispatch_rows else None,
            "setcanvas_owner_ledger": canvas_owner_rows,
            "pencil_shader_source_evidence": pencil_shader_evidence(),
            "runtime_shader_program_binary_join": gl_program_events,
            "native_uniform_call_snapshots": native_uniform_call_snapshots,
            "native_vertex_input_observer": {"draw_snapshots":native_vbo_draw_snapshots,"buffer_events":native_vbo_buffer_events,"pointer_events":native_vbo_pointer_events,"attribute_enable_divisor_events":native_vbo_enable_events},
            "pixel_evidence": {"backend": "host Mesa GLES", "draw_observations": draw_pixel_evidence[pixel_evidence_start:],
                "complete": bool(draw_pixel_evidence[pixel_evidence_start:]) and all(row["evidence_is_complete"] for row in draw_pixel_evidence[pixel_evidence_start:])}})
    no_factory_cases = [case for case in cases
                        if case.get("status") == "drawing_returned_without_createPenInst"]
    if no_factory_cases:
        result = {
            "schema": "sdocx-old-pencil-native-drawing-postcondition-diagnostic.v17",
            "status": ("native_drawing_returned_without_pen_factory"
                       if len(no_factory_cases) == len(cases)
                       else "mixed_native_pen_factory_dispatch"),
            "scope": "V17 records actual GLES vertex-array state at the native instanced draw and joins enabled attributes to buffer contents reconstructed from guest glBufferData/SubData payloads; it does not bind, rewrite, or synthesize GL objects.",
            "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL),
                     "analysis_dso_sha256": digest(PENCIL_ANALYSIS)},
            "runtime": {"context": [1920, 1080], "native_pen_canvas": native_pen_canvas,
                "clock_service_profile": clock_service_profile,
                "bitmap_factory": bitmap_factory_record,
                "bitmap_dimensions": [actual_bitmap_width, actual_bitmap_height],
                "native_canvas_clip_setup": native_canvas_clip_setup,
                "queue_boundary": {"task_count": len(queue_submissions), "tasks": queue_submissions,
                    "controlled_native_runs": native_task_runs,
                    "pending_task_count": sum(row.get("run_state") == "deferred_not_run" for row in queue_submissions)},
                "SetCanvas_owner_ledger": canvas_owner_rows},
            "source_control_flow": {
                "drawing_symbol": "SPen::ObjectDrawing::drawObjectStroke(SPen::ISPCanvas&, SPen::ISPPenCanvas&, SPen::ObjectStroke const*, bool)",
                "drawing_dso_sha256": PIN["drawing_dso"],
                "point_count_branch": "Drawing ELF 0x81a64 calls GetPointCount; count <= 1 returns false at 0x81a70-0x81a78.",
                "pen_name_branch": "Drawing ELF 0x81a7c calls GetPenName; null returns false at 0x81a84.",
                "pen_data_branch": "Drawing ELF 0x81ad0 calls PenManager::GetPenData; null takes 0x81adc -> 0x81b48, logs/sets error 13, and returns false before redrawIPen.",
                "pen_manager_cache_branch": "PenCommon GetPenData searches its PenData vector and then PenManagerST::GetPen; V9 records both native return values and Drawing's +144 cache pointer.",
                "clip_setup": "V9 follows the hash-pinned full-queue actual-canvas caller and records SetClipRect using native bitmap width/height before Drawing.",
            },
            "return_watch_symbols_missing": missing_return_watch_symbols,
            "native_call_history": native_call_attempts,
            "native_return_events": native_return_events,
            "native_import_events": native_import_events,
            "native_symbol_events": native_events,
            "interpolation_call_returns": smpath_call_returns,
            "drawpoint_state_windows": pencil_drawpoint_state,
            "cases": cases,
        }
        emit_json(result, args.output)
        return
    if any(not case["selected_drawable"]["is_GLV1"] for case in cases
           if "selected_drawable" in case):
        raise RuntimeError("Drawing-selected Pencil drawable did not match the pinned GLV1 vtable")
    result = {"schema": "sdocx-old-pencil-native-drawing-capture.v17",
        "scope": "Native Drawing/ObjectStroke -> old Pencil GLV1 saved redraw, typed RTV1 AddPoint calls, role-aware SetCanvas RT ownership, source-ordered native canvas clipping, and a controlled native queue prefix on host Mesa. Native synthetic bitmap/input; host Mesa owned-target RGBA8 readback only; no native-device comparison.",
        "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL), "analysis_dso_sha256": digest(PENCIL_ANALYSIS)},
        "runtime": {"helper": str(RUNTIME.relative_to(ROOT)), "context": [1920, 1080],
            "clock_service_profile": clock_service_profile,
            "context_and_queue": "native SPPenCanvas::GetMsgQueue slot +184 returns the explicitly bounded host IGLMsgQueue; PostTask slot +16 records and retains native WorkerTask objects",
            "native_pen_canvas": native_pen_canvas,
            "bitmap_factory": bitmap_factory_record,
            "bitmap_setup_queue": {"queue": hex(bitmap_setup_queue),
                "task_count": len(bitmap_setup_tasks), "tasks": bitmap_setup_tasks,
                "execution_boundary": "native CreateBitmap setup tasks execute before Drawing; callback destructor tasks remain deferred"},
            "queue_boundary": {"slot_byte_offset": 16,
                "exact_method_symbol": None,
            "method_name_boundary": "IGLMsgQueue method symbol is not exported in the pinned native DSOs; the slot contract is established by the native callsite and ownership branch",
                "typed_call_shape": "x0=IGLMsgQueue receiver, x1=native WorkerTask pointer, w0=acceptance bool",
                "accepted_task_lifetime": "queue retains native allocations and byte snapshots; selected RT roles are joined to source SetCanvas owner+16, while CanvasImpl clip tasks remain a separate role",
                "deferred_task_count": len(queue_submissions),
                "deferred_tasks_not_run": not bool(native_task_runs),
                "controlled_native_run_count": len(native_task_runs),
                "pending_task_count": sum(row.get("run_state") == "deferred_not_run" for row in queue_submissions),
                "deferred_run_list": [{
                    "sequence": row["sequence"], "task": row["task"],
                    "task_vtable_symbol": row["task_vtable_symbol"],
                    "run_method": row["run_method"],
                    "run_state": row["run_state"],
                } for row in queue_submissions],
                "native_task_records": queue_submissions,
                "controlled_native_runs": native_task_runs,
                "dispatch_blockers": dispatch_blockers,
                "SetCanvas_owner_ledger": canvas_owner_rows,
                "SetCanvas_RT_role_ledger": setcanvas_rt_role if args.dispatch_through >= 1 and 2 in dispatch_rows else None},
            "renderer_adapter_sha256": PIN["renderer_adapter"],
            "unresolved_plugin_relocations": unresolved_imports,
            "random_profile": {"implementation": "host glibc libc.so.6",
                "path": str(libc_path), "sha256": digest(libc_path), "version": libc_version,
                "initial_harness_seed_u32": args.initial_seed,
                "forced_values": random_values,
                "boundary": "host libc outputs are recorded test inputs; they do not establish Android bionic/Samsung runtime behavior"}},
        "native_call_history": native_call_attempts,
        "native_import_events": native_import_events,
        "host_clock_gettime_calls": clock_gettime_calls,
        "pencil_texture_uploads": pencil_mesa_uploads,
        "native_return_events": native_return_events,
        "strncpy_calls": strncpy_calls,
        "pencil_data_owner_readbacks": pencil_data_owner_readbacks,
        "cases": cases}
    emit_json(result, args.output)


def emit_json(value, output_path):
    serialized = json.dumps(value, indent=2, sort_keys=True) + "\n"
    if output_path is not None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(serialized)
    print(serialized, end="")


if __name__ == "__main__":
    try:
        main()
    except NativeCallDiagnostic as failure:
        emit_json(failure.report, failure.output_path)
    except Exception as failure:
        tb_rows = traceback.extract_tb(failure.__traceback__)
        capture_frame = None
        walk = failure.__traceback__
        while walk:
            if walk.tb_frame.f_code.co_name == "main":
                capture_frame = walk.tb_frame
            walk = walk.tb_next
        local = capture_frame.f_locals if capture_frame else {}
        args = local.get("args")
        p = local.get("p")
        R = local.get("R")
        cpu = None
        if p is not None and R is not None:
            try:
                cpu = {"pc": hex(p.u.reg_read(R.UC_ARM64_REG_PC)),
                    "lr": hex(p.u.reg_read(R.UC_ARM64_REG_LR)),
                    "sp": hex(p.u.reg_read(R.UC_ARM64_REG_SP)),
                    "x0_x7": [hex(p.u.reg_read(getattr(R, f"UC_ARM64_REG_X{i}"))) for i in range(8)],
                    "s0_s7_bits": [f"{p.u.reg_read(getattr(R, f'UC_ARM64_REG_S{i}')) & 0xffffffff:08x}" for i in range(8)]}
            except Exception as cpu_error:
                cpu = {"snapshot_error": f"{type(cpu_error).__name__}: {cpu_error}"}
        source_frame = next((row for row in reversed(tb_rows)
                             if row.filename == __file__), tb_rows[-1] if tb_rows else None)
        queue_rows = local.get("queue_submissions", [])
        native_events = local.get("native_events", [])
        adapter = local.get("adapter")
        result = {"schema": "sdocx-old-pencil-native-guard-failure.v17",
            "status": "guard_failed_with_structured_context",
            "pins": {**PIN, "decoded_dso_sha256": digest(PENCIL) if PENCIL.is_file() else None},
            "failure": {"exception_type": type(failure).__name__, "message": str(failure),
                "source_file": source_frame.filename if source_frame else None,
                "source_line": source_frame.lineno if source_frame else None,
                "source_text": linecache.getline(source_frame.filename, source_frame.lineno).strip() if source_frame else None,
                "traceback_tail": [{"file": row.filename, "line": row.lineno, "function": row.name}
                                   for row in tb_rows[-8:]],
                "phase": local.get("phase", [None])[0] if local.get("phase") else None,
                "sequence": local.get("sequence"), "current_task": local.get("row"),
                "cpu": cpu},
            "partial_state": {"native_tasks": queue_rows,
                "completed_task_runs": local.get("native_task_runs", []),
                "runtime_shader_program_binary_join": local.get("gl_program_events", {}),
                "native_uniform_call_snapshots": local.get("native_uniform_call_snapshots", []),
                "native_vertex_input_observer": {"draw_snapshots":local.get("native_vbo_draw_snapshots",[]),"buffer_events":local.get("native_vbo_buffer_events",[]),"pointer_events":local.get("native_vbo_pointer_events",[]),"attribute_enable_divisor_events":local.get("native_vbo_enable_events",[])},
                "SetCanvas_owner_ledger": local.get("canvas_owner_rows", []),
                "scheduler_blockers": local.get("dispatch_blockers", []),
                "selected_RT_role": local.get("selected_rt_role"),
                "selected_pen": local.get("selected_pen"),
                "selected_drawable": local.get("drawable"),
                "native_AddPoint_count": len(local.get("add_calls", [])),
                "recent_native_symbols": native_events[-64:],
                "recent_renderer_gl_calls": (adapter.gl_calls[-128:] if adapter is not None else []),
                "pencil_texture_source_trace": {
                    "setTextures_entries": local.get("pencil_settextures_entries", []),
                    "setTextures_operator_new_array_calls": local.get("pencil_array_new_calls", []),
                    "host_operator_new_array_allocator_calls": local.get("pencil_native_array_allocator_calls", []),
                    "setTextures_pending_new_array_returns": {
                        hex(pc): rows for pc, rows in local.get("pending_pencil_array_allocations", {}).items()},
                    "setTextures_operator_new_array": local.get("pencil_array_allocations", []),
                    "SPTextureBitmap_UpdateBitmap": local.get("pencil_bitmap_update_events", []),
                    "SPSubBitmapRT_UpdateBitmap": local.get("graphics_subbitmap_update_events", []),
                    "TextureObject_CreateTexture": local.get("pencil_texture_create_events", []),
                    "Renderer_TextureObject_Update": local.get("renderer_texture_update_events", []),
                    "Mesa_texture_allocations": local.get("pencil_texture_allocation_events", []),
                    "Mesa_texture_uploads": local.get("pencil_mesa_uploads", []),
                    "glPixelStorei": local.get("pixel_store_events", [])},
                "invalid_memory_events": local.get("invalid_memory_events", [])[-8:]},
            "scope": "This structured failure receipt is diagnostic only; it does not imply any captured RT roles are equal or that a paint completed."}
        emit_json(result, args.output if args else None)
        raise SystemExit(1)
