#!/usr/bin/env python3
"""Pencil2 RTV4 Mesa Draw candidate using source-pinned native framebuffer lifecycle and the TextureOracle native-return trampoline with an RGBA8 target.

--preflight only parses this file and checks pinned source hashes. --capture is
for an explicit root run. The candidate uses Pencil2 RTV4 and Renderer factory
implementations, real Mesa object IDs, a native ShaderManager constructor, a
source-pinned typed host IGLMsgQueue boundary that executes native bitmap setup
WorkerTasks, and four pinned saved Drawing AddPoint inputs and native saved-style inputs. A native
PenReturnCallback::GetBuffer creates the empty vector; native SetBuffer binds it
to the RTV4 input, AddPoint fills it, and native SendDataToGPU publishes it to
the normal Update(false)/Draw path. This is an explicit single-threaded RT replay
boundary, not a natural Drawing/queue lifecycle capture. It records full-frame
readback only after native Draw returns without GL errors.

The V31 libc++ posix_memalign bridge is limited to its two pinned callsites and
allocates aligned guest heap memory with the POSIX pointer-output/return-code
ABI. It never returns a host pointer. Requests are bounded by the mapped guest
heap and explicit 16 MiB/1 MiB size/alignment caps.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
import struct
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
CAPTURES = HERE / "captures"
LIB = ROOT / "scratch/apk-analysis-native/arm64-v8a"
HELPERS = ROOT / "tmp/conformance-cleanup/native-capture-a241793/conformance"
TEXTURE_V3 = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-texture-v3/captures/root-rtv4-textures-v3/capture.json"
DRAWPOINT_RECEIPT = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v29/captures/explicit14/capture.json"
DRAWPOINT_CAPTURE_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v29/source_capture_candidate.py"
DRAWPOINT_CAPTURE_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v29/handoff-manifest.json"
V30_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v30/captures/root-draw-v30/failure.json"
V30_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v30/capture_candidate.py"
V30_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v30/handoff-manifest.json"
V31_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v31/captures/root-draw-v31/failure.json"
V31_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v31/capture_candidate.py"
V31_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v31/handoff-manifest.json"
V32_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v32/captures/root-draw-v32/failure.json"
V32_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v32/capture_candidate.py"
V32_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v32/handoff-manifest.json"
V33_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v33/captures/root-draw-v33/failure.json"
V33_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v33/capture_candidate.py"
V33_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v33/handoff-manifest.json"
V34_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v34/captures/root-draw-v34/failure.json"
V34_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v34/capture_candidate.py"
V34_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v34/handoff-manifest.json"
V35_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v35/captures/root-draw-v35/failure.json"
V35_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v35/capture_candidate.py"
V35_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v35/handoff-manifest.json"
V35_FAILURE_SHA256 = "05b7fd5bc8030942b9f8bdc61729a29fc484d5cfd87d5f9930eee4ef548ee0c3"
V35_CANDIDATE_SHA256 = "11d960c0950ca6045df16f794ccf862d4f7bd3f77a4eb7ba593715ec337abd33"
V35_MANIFEST_SHA256 = "69b8a255f220fe7267ef0a3295411067e99bffe205101151e2873df783ca308d"
V36_FAILURE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v36/captures/root-draw-v36/failure.json"
V36_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v36/capture_candidate.py"
V36_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v36/handoff-manifest.json"
V36_FAILURE_SHA256 = "5f360c14ccc6e37b997ed764a3869d7bcbfa0078919e0b5d59f919df88d1871f"
V36_CANDIDATE_SHA256 = "9e888486d42908f9861255f86d09e9659ed81fc9c47202849b7dbca8f8a4f154"
V36_MANIFEST_SHA256 = "f95d123ff1f9ee3e247472d73eb58a5fc5dc7aea4cf09faaee0ad20db18da1f1"
V37_SUCCESS = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v37/captures/root-draw-v37/capture.json"
V37_RETROSPECTIVE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v37/retrospective-evidence.json"
V37_CANDIDATE = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v37/capture_candidate.py"
V37_MANIFEST = ROOT / "tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v37/handoff-manifest.json"
V37_SUCCESS_SHA256 = "c1b6bf7d6f3baa66b1a098f394d970eec237561547412fe726c6ac3a68f183f8"
V37_RETROSPECTIVE_SHA256 = "a06e6df09c32989d1c793fbcf398bf374c081456f369f4a17239c156c9a9fcbf"
V37_CANDIDATE_SHA256 = "db43fc795289cc2c0b867ddb168f4e63c65a354486277cf40ec0c38a0a143bc7"
V37_MANIFEST_SHA256 = "6d95def0e578c57de01dc1ff696dfb6d30ab1d1c9cc8a4cd0effc187b23b28c3"
V34_FAILURE_SHA256 = "95219fb27f6c019e1c28e41907babe3a7030b5d410f3aca93d1abb16bc6b6398"
V34_CANDIDATE_SHA256 = "333547c7a87ed5e04889b865688e9d37dee106a19a15579fb46c619381fdde96"
V34_MANIFEST_SHA256 = "db4261763723349afe0ce2527a778e0e290acdcd6bf8deaf62dcc8b8ff343abd"
V33_FAILURE_SHA256 = "c075c300ad0e9834f7da525e1ce6b4fd5542b542260d501c366fa33260f2ae8f"
V33_CANDIDATE_SHA256 = "40bbab54527a85d14625541b660635c055aa57e1464c014910e426d7a10a38e3"
V33_MANIFEST_SHA256 = "c0e781fa47c6b4752a4d68caffae796e1e8a41ffa61e4dc3d34a7c187f449b34"
V32_FAILURE_SHA256 = "c342ebf4af7cb623f0e241310b4f6d0cb8d448d64bcd3a8adebdbb881fda65b5"
V32_CANDIDATE_SHA256 = "f4827e1ac12925789aadfebdc9874318dbdf8fcc9c3b6b87e0b3e38e797b6d21"
V32_MANIFEST_SHA256 = "00b8f0e4057451c309f4e01df5a09e50b0cff8c5043dcaec0ec5a045864fcd73"

DSO_PINS = {
    "libSPenPencil2.so": "3e7d7118ea0fea370d491a5582ac81c09dc063ac75dbcc396abdc32976a42b0f",
    "libSPenPenCommon.so": "afd39c0d55ec5cf47153be48222c8a9ddc0057fc772dd870af9ced74a59ec33d",
    "libSPenBase.so": "e10da0116946691cf68302437ef261282e1dfe0eec15bf2dfa66093286985deb",
    "libSPenFountainPen.so": "1fed4e071caffcb88a4df4ca345b6df5e3374852c9ef18044793fc2e340ac6ec",
    "libSPenAirBrushPen.so": "92ebe10993ebfcb42fa3f5c55e86f6d469ccac6638421bbd71f92e0558587423",
    "libSPenGraphics.so": "aac858ce3a9d0353d760b4b0ef09f1e88b0d4a87f5e0906fe8d53936ee8a6621",
    "libSPenRenderer.so": "f38df5db5e64f80c0641b6cee980e14533bd78e8e6eb34f250bd703d28119aed",
    "libc++_shared.so": "4397241b4bd20a8e579bfb41d21107857e12985f6a01ca0c2a5f83380d1270b4",
}
SOURCE_PINS = {
    "airbrush_texture_native.py": "76bb130daef795be53296cff4f778be6e7be5f487c8b1d4c4b6d159bb688e470",
    "airbrush_saved_native.py": "cad2bd9ec88a393f0b0b4a7dbe58c7b469f9b00b283d4c544f491a8ab190999a",
    "fountain_native.py": "40cb917c7f286302d8519e9b953c3c21b7fe6ea0b6b0a80ccc13e2e724cfad30",
    "inkpen_paint_native.py": "a3e65b2b37b2913b4bb2787b72ab2dbad0a9660cb66435b142f5acfa4d5051ae",
    "elf_plt.py": "816eceff5b532b35c8ef9ea904a8aa64767422b0799347a18fbd4602b70f373b",
}
DRAWPOINT_RECEIPT_SHA256 = "2ffb4594797d25d9cf8fc24e88a260acb2a3a2db007b4ea12520f7e075178ac9"
DRAWPOINT_CAPTURE_CANDIDATE_SHA256 = "f256e0e94c284995c581a92c29a18684fb3e19206b43e65b36f49cdf081eb420"
DRAWPOINT_CAPTURE_MANIFEST_SHA256 = "f7d3906b363b51d5eab8ff4efbcdf33a4d4e25541322ca7a746e3fb475aba6c2"
V30_FAILURE_SHA256 = "11503f0509a241fcaf86335145f49265d32bf25c9ecff803d004d648d02dd989"
V30_CANDIDATE_SHA256 = "372cbb3ab00937db431e1da39d6dce15ca78c15c80c204dba826a13dab9e7191"
V30_MANIFEST_SHA256 = "bbf0a66fa1aaf35f36f8b1feee99ae5793aa82ac576dc2d357b19d78bc646ef2"
V31_FAILURE_SHA256 = "2199bcc32fdaba50918542e507cd3d977f9f8cd497a47b7e3aff76cc9cceb6e9"
V31_CANDIDATE_SHA256 = "dee959a02dba3532b355d021db48093c64234ff30955794811de068fb6806902"
V31_MANIFEST_SHA256 = "5bd789dec2a3e3849052d21d486cdf92faa96a35ffda167850d0be6f64cbb0d6"
COLOR_LAYOUT_DOC = ROOT / "docs/reverse-engineering/fountain-rainbow.md"
COLOR_LAYOUT_DOC_SHA256 = "89fe385d2d67477cb59d681e0d40edf0b00500d14ff7a36de01708ad2494d8fd"
TEXTURE_V3_SHA256 = "5841c342facf9ffe02462a3cb0aef09aac1f2986293dbc1850217a47e66b997a"
DRAWPOINT_FULL_STREAM_BYTES = 4704
DRAWPOINT_FULL_STREAM_ROWS = 84
DRAWPOINT_FULL_STREAM_SHA256 = "770651fc1b27bfa8a73731f1a3e24cf1a37847e920581aa36855c5107835c2fe"
LAST_PROBE = None
LAST_REGS = None

RT_CTOR = "SPen::Pencil2StrokeDrawableRTV4::Pencil2StrokeDrawableRTV4(SPen::PenGLDataManager*)"
RT_INIT = "SPen::Pencil2StrokeDrawableRTV4::Init()"
RT_ADD = "SPen::Pencil2StrokeDrawableRTV4::AddPoint(SPen::Vector2<float>*, float, float, float, int, SPen::Vector3<float>)"
RT_UPDATE = "SPen::Pencil2StrokeDrawableRTV4::Update(bool)"
RT_DRAW = "SPen::Pencil2StrokeDrawableRTV4::Draw(SPen::ISPSubBitmap*, SPen::Matrix4<float>&)"
RT_SET_INVERSE_SCALE = "SPen::Pencil2StrokeDrawableRTV4::SetInverseScale(SPen::Vector2<float> const&)"
PEN_DRAWABLE_SET_PEN_DATA = "SPen::PenDrawableRT::SetPenData(float, int)"
PEN_RETURN_CALLBACK_CTOR = "SPen::PenReturnCallback::PenReturnCallback(SPen::PenDrawableRT*, SPen::ISPPenCanvas*)"
PEN_RETURN_CALLBACK_GET_BUFFER = "SPen::PenReturnCallback::GetBuffer()"
PEN_DRAWABLE_SET_BUFFER = "SPen::PenDrawableRT::SetBuffer(std::__ndk1::vector<float, std::__ndk1::allocator<float> >*, std::__ndk1::vector<float, std::__ndk1::allocator<float> >*)"
PEN_DRAWABLE_SEND_DATA_TO_GPU = "SPen::PenDrawableRT::SendDataToGPU(std::__ndk1::vector<float, std::__ndk1::allocator<float> >*, std::__ndk1::vector<float, std::__ndk1::allocator<float> >*)"
ACTIVATE_SUBBITMAP_RT = "SPen::SPSubBitmapRT::ActivateFrameBufferRT(bool)"
CREATE_SUBBITMAP_FRAMEBUFFER = "SPen::SPSubBitmapRT::CreateFrameBuffer()"
FRAMEBUFFER_CALL_STOP = 0x200f1000
CREATE_TEXTURE_RT = "SPen::SPSubBitmapRT::createTextureRT(int, int, int, char const*, void const*, bool, SPen::TextureMemoryLayout, SPen::TextureTargetLayout)"
GET_CURRENT_MSG_QUEUE = "SPen::GetCurrentMsgQueue()"
MANAGED_OBJECT_REGISTER = "SPen::ManagedObject::Register()"
GET_CURRENT_MSG_QUEUE_RVA = 0x44e68
MANAGED_OBJECT_REGISTER_RVA = 0x45528
EXPECTED_ACTIVATE_CALLSITE_RTV4 = 0x996d4
EXPECTED_STRTOF_LR_RENDERER_RVA = 0x4bf5c
GL_EXTENSIONS_ENUM = 0x1f03
GL_EXTENSIONS_MAX_BYTES = 1 << 20
EXPECTED_EXTENSIONS_STRTSTR_LR_RENDERER_RVA = 0x4b904
LIBCPP_BASE = 0x08000000
LIBCPP_SHA256 = "4397241b4bd20a8e579bfb41d21107857e12985f6a01ca0c2a5f83380d1270b4"
LIBCPP_POSIX_MEMALIGN_PLT_RVA = 0x132c98
LIBCPP_POSIX_MEMALIGN_CALLS = {
    0xa023c: {"return_rva":0xa0240,"alignment":16,"size_rule":"max(incoming x0, 1)"},
    0xba81c: {"return_rva":0xba820,"alignment_rule":"max(incoming x1, 8)","size_rule":"max(incoming x0, 1)"},
}
LIBCPP_POSIX_MEMALIGN_MAX_REQUEST = 1 << 24
LIBCPP_ASSIGN_CSTR = "std::__ndk1::basic_string<char, std::__ndk1::char_traits<char>, std::__ndk1::allocator<char> >::assign(char const*)"
LIBCPP_ASSIGN_CSTR_MANGLED = "_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6assignEPKc"
EXPECTED_CACHE_PATH_ASSIGN_LR_RENDERER_RVA = 0x47520
SYSTEM_GET_CACHE_PATH = "SPen::System::GetSDKCacheDirectoryPath()"
EXPECTED_CACHE_PATH_GETTER_LR_RENDERER_RVA = 0x47508
EXPECTED_CACHE_ACCESS_LR_RENDERER_RVA = 0x47608
EXPECTED_CACHE_MKDIR_LR_RENDERER_RVA = 0x47650
EXPECTED_CACHE_MKDIR_LR_BASE_RVA = 0x945cc
EXPECTED_CACHE_PARENT_ACCESS_LR_BASE_RVA = 0x94690
BASE_DSO_BASE = 0x02000000
PEN_COMMON_SET_BUFFER_RVA = 0x4a5b8
PEN_COMMON_SEND_DATA_TO_GPU_RVA = 0x4a5c4
PEN_COMMON_RETURN_CALLBACK_CTOR_RVA = 0x503fc
PEN_COMMON_RETURN_CALLBACK_GET_BUFFER_RVA = 0x50640
PEN_COMMON_SET_PEN_DATA_RVA = 0x4a558
PENCIL2_SET_INVERSE_SCALE_RVA = 0x98a64
PEN_COMMON_SET_PEN_DATA_BYTES = bytes.fromhex(
    "210c040e08ffffd002d941fde86fa8522144a22e22e6006f211c144e2304144e"
    "211c224e6204286f41641c6e020d044e0800391e21d8216e083c00b921fc226e"
    "01c0823cc0035fd6")
PENCIL2_SET_INVERSE_SCALE_BYTES = struct.pack("<III",0xf9400028,0xf80fc008,0xd65f03c0)
BASE_DSO_MAPPING_SIZE = 0x200000
BASE_FILE_ACCESS_RVA = 0x96768
BASE_DIRECTORY_MKDIR_RVA = 0x945ac  # symbol start; mkdir@plt at +0x1c returns at +0x20
BASE_FILE_MODE_STRCHR_LR_RVAS = {0x96188: ord("w"), 0x96198: ord("a")}
BASE_STRCHR_PLT_RVA = 0xe58e0
RENDERER_READ_MODE_RVA = 0x2c282
RENDERER_WRITE_MODE_RVA = 0x29a24
STRCHR_MAX_INPUT_BYTES = 128
GET_BINDING_INTF_RVA = 0x5b2c4
STRLEN_CHK_CALLSITE_LRS = {0x5b404, 0x5b420, 0x5b4a0}
STRLEN_CHK_BL_RVAS = (0x5b400, 0x5b41c, 0x5b49c)
STRLEN_CHK_PLT_RVA = 0x64470
STRLEN_CHK_BOUND = 64
ACTIVE_UNIFORM_BUFFER_SIZE = 63
STRNCPY_CHK2_CALLSITE_LRS = {0x5b458, 0x5b4bc}
STRNCPY_CHK2_BL_RVAS = (0x5b454, 0x5b4b8)
STRNCPY_CHK2_PLT_RVA = 0x65620
STRNCPY_CHK2_DEST_SIZE = 128
STRNCPY_CHK2_SOURCE_SIZE = 64
EXPECTED_STRLEN_CHK_LR_RENDERER_RVAS = STRLEN_CHK_CALLSITE_LRS
EXPECTED_STRNCPY_CHK2_LR_RENDERER_RVAS = STRNCPY_CHK2_CALLSITE_LRS
GET_BINDING_INTF_SYMBOL = "SPen::GLES::OpenGLShaderProgram::GetBindingIntf(char const*)"
GET_BINDING_INTF_RVA = 0x5b2c4
STRCMP_CALLSITE_LR_RENDERER_RVA = 0x5b504
STRCMP_CALLSITE_BL_RENDERER_RVA = 0x5b500
STRCMP_PLT_RENDERER_RVA = 0x64240
STRCMP_OPERAND_BUFFER_SIZE = 128
VIRTUAL_FS_PREFIX = "/virtual/pencil2-renderer-cache"
SDK_CACHE_CONFIG_PATH = VIRTUAL_FS_PREFIX + "/sdk-path"
EXPECTED_SHADER_CACHE_DIR = VIRTUAL_FS_PREFIX + "/RendererCache"
EXPECTED_LIBCPP_ASSIGN_STRLEN_LR_RVA = 0xd7128
CRC32_MAX_BYTES = 1 << 24
EXPECTED_CRC32_SECOND_LR_RENDERER_RVA = 0x5b8bc
EXPECTED_VSNPRINTF_LR_RENDERER_RVA = 0x48780
EXPECTED_VSNPRINTF_BL_RENDERER_RVA = 0x4877c
EXPECTED_GETFILENAME_TO_FORMATTER_BL_RENDERER_RVA = 0x480d8
EXPECTED_VSNPRINTF_PLT_RENDERER_RVA = 0x644d0
EXPECTED_FORMAT_ADR_RENDERER_RVA = 0x4872c
EXPECTED_FORMAT_HELPER_ENTRY_RENDERER_RVA = 0x48708
EXPECTED_GETFILENAME_RETURN_RENDERER_RVA = 0x480dc
EXPECTED_VSNPRINTF_FORMAT_RVA = 0x2b444
EXPECTED_VSNPRINTF_FORMAT = b"/sh%0lu.dat"
EXPECTED_VSNPRINTF_CAPACITY = 128
EXPECTED_CRC32_DIRECT_CALLS = {
    0x47808: "SPen::ShaderProgramCache::GetShaderKey(char const*, char const*)",
    0x47a3c: "SPen::ShaderProgramCache::LoadFromFile(unsigned long)",
    0x47aac: "SPen::ShaderProgramCache::LoadFromFile(unsigned long)",
    0x47afc: "SPen::ShaderProgramCache::LoadFromFile(unsigned long)",
    0x48288: "SPen::ShaderProgramCache::SaveToFile(SPen::ShaderProgramCache::BinaryShader const*)",
    0x482b4: "SPen::ShaderProgramCache::SaveToFile(SPen::ShaderProgramCache::BinaryShader const*)",
    0x48340: "SPen::ShaderProgramCache::SaveToFile(SPen::ShaderProgramCache::BinaryShader const*)",
}
CREATE_GRAPHICS = ("SPen::RendererFactory::CreateGraphicsObject(unsigned int, SPen::PrimitiveType, "
                   "SPen::VertexDescriptor const*, unsigned int, unsigned int)")
CREATE_GRAPHICS_IMPL = ("SPen::GLES::RendererFactoryImpl::GreateGraphicsObject(unsigned int, SPen::PrimitiveType, "
                        "SPen::VertexDescriptor const*, unsigned int, unsigned int)")
CREATE_BLEND = "SPen::RendererFactory::CreateBlendStateObject(SPen::BlendStateDescriptor const&)"
CREATE_BLEND_IMPL = "SPen::GLES::RendererFactoryImpl::CreateBlendStateObject(SPen::BlendStateDescriptor const&)"
CREATE_SHADER_IMPL = "SPen::GLES::RendererFactoryImpl::CreateShaderProgram(char const*, char const*, char const*)"
REQUIRED_DYNSYMS = {
    "libSPenPencil2.so": {
        "_ZN4SPen25Pencil2StrokeDrawableRTV4C1EPNS_16PenGLDataManagerE",
        "_ZN4SPen25Pencil2StrokeDrawableRTV44InitEv",
        "_ZN4SPen25Pencil2StrokeDrawableRTV48AddPointEPNS_7Vector2IfEEfffiNS_7Vector3IfEE",
        "_ZN4SPen25Pencil2StrokeDrawableRTV46UpdateEb",
        "_ZN4SPen25Pencil2StrokeDrawableRTV44DrawEPNS_12ISPSubBitmapERNS_7Matrix4IfEE",
        "_ZN4SPen25Pencil2StrokeDrawableRTV415SetInverseScaleERKNS_7Vector2IfEE",
    },
    "libSPenGraphics.so": {"_ZN4SPen13SPSubBitmapRT21ActivateFrameBufferRTEb", "_ZN4SPen13SPSubBitmapRT17CreateFrameBufferEv", "_ZN4SPen13SPSubBitmapRT19CreateFrameBufferRTEb"},
    "libSPenPenCommon.so": {"_ZN4SPen16PenGLDataManager11SetMsgQueueEPNS_11IGLMsgQueueE", "_ZN4SPen16PenGLDataManager11GetMsgQueueEv",
                            "_ZN4SPen13PenDrawableRT10SetPenDataEfi",
                            "_ZN4SPen17PenReturnCallbackC1EPNS_13PenDrawableRTEPNS_12ISPPenCanvasE",
                            "_ZN4SPen17PenReturnCallback9GetBufferEv",
                            "_ZN4SPen13PenDrawableRT9SetBufferEPNSt6__ndk16vectorIfNS1_9allocatorIfEEEES6_",
                            "_ZN4SPen13PenDrawableRT13SendDataToGPUEPNSt6__ndk16vectorIfNS1_9allocatorIfEEEES6_"},
    "libSPenRenderer.so": {"_ZTIN4SPen11IGLMsgQueueE",
                            "_ZN4SPen18GetCurrentMsgQueueEv",
                            "_ZN4SPen13ManagedObject8RegisterEv",
                            "_ZN4SPen13ShaderManagerC1Ev", "_ZN4SPen13ShaderManager11GetInstanceEv",
                            "_ZN4SPen14OpenGLRenderer17getSupportSamplerEv","_Z22IsGLExtensionSupportedPKc",
                            "_ZN4SPen18ShaderProgramCache11GetFileNameEm",
                            "_ZN4SPen4GLES19OpenGLShaderProgram14GetBindingIntfEPKc"},
    "libSPenBase.so": {"_ZN4SPen15CriticalSectionC1Eb"},
    "libc++_shared.so": {LIBCPP_ASSIGN_CSTR_MANGLED},
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resolve_mapped_dso_base(symbol_address: int, symbol_rva: int, expected_base: int,
                            mapped_regions, label: str, mapping_size: int = 0x200000) -> int:
    """Join a pinned exported symbol to its loader base and mapped Unicorn range."""
    derived=symbol_address-symbol_rva
    if derived!=expected_base:
        raise RuntimeError(f"{label} exported-symbol base mismatch: derived={derived:#x} expected={expected_base:#x}")
    last=derived+mapping_size-1
    if not any(start<=derived and end>=last for start,end,_perms in mapped_regions):
        raise RuntimeError(f"{label} DSO range is not actually mapped: {derived:#x}..{last:#x}")
    return derived


def parse_nm_defined_rows(output: str) -> list[tuple[int,str,str]]:
    """Parse only address-bearing nm exports; undefined imports have no RVA."""
    parsed=[]
    for line in output.splitlines():
        fields=line.split(None,2)
        if len(fields)!=3:
            continue
        try:
            address=int(fields[0],16)
        except ValueError:
            continue
        if fields[1].upper()=="U":
            continue
        parsed.append((address,fields[1],fields[2]))
    return parsed


def nm_parser_fixture_tests() -> dict:
    sample=("0000000000012340 T SPen::Foo::method(int)\n"
            "                 U SPen::Missing::longImport(std::vector<int> const&)\n"
            "0000000000015000 W SPen::Foo::weakMethod()\n"
            "0000000000016000 V vtable for SPen::WorkerTask::Member0<SPen::Foo, void (SPen::Foo::*)()>\n"
            "0000000000017000 D typeinfo for SPen::Foo\n")
    parsed=parse_nm_defined_rows(sample)
    expected=[(0x12340,"T","SPen::Foo::method(int)"),
              (0x15000,"W","SPen::Foo::weakMethod()"),
              (0x16000,"V","vtable for SPen::WorkerTask::Member0<SPen::Foo, void (SPen::Foo::*)()>"),
              (0x17000,"D","typeinfo for SPen::Foo")]
    if parsed!=expected:
        raise RuntimeError(f"nm defined-row parser fixture mismatch: {parsed!r}")
    return {"status":"passed","defined_rows":len(parsed),"undefined_import_skipped":True,
            "demangled_long_names_preserved":True,"symbol_types":["T","W","V","D"]}


def defined_dynsyms(path: Path) -> set[str]:
    blob=path.read_bytes()
    shoff=struct.unpack_from("<Q",blob,40)[0]
    entsize,count,stridx=struct.unpack_from("<HHH",blob,58)
    sections=[struct.unpack_from("<IIQQQQIIQQ",blob,shoff+i*entsize) for i in range(count)]
    shstr=sections[stridx];names=blob[shstr[4]:shstr[4]+shstr[5]]
    section_names=[names[s[0]:names.find(b"\0",s[0])].decode() for s in sections]
    dynsym=sections[section_names.index(".dynsym")]
    dynstr=sections[dynsym[6]]
    strings=blob[dynstr[4]:dynstr[4]+dynstr[5]]
    output=set()
    for off in range(dynsym[4],dynsym[4]+dynsym[5],dynsym[9]):
        name,_info,_other,shndx,_value,_size=struct.unpack_from("<IBBHQQ",blob,off)
        if name and shndx:
            end=strings.find(b"\0",name)
            output.add(strings[name:end].decode())
    return output


def defined_dynsym_values(path: Path) -> dict[str, list[int]]:
    """Return source-level ELF dynamic symbol values for all defined symbols."""
    blob=path.read_bytes()
    shoff=struct.unpack_from("<Q",blob,40)[0]
    entsize,count,stridx=struct.unpack_from("<HHH",blob,58)
    sections=[struct.unpack_from("<IIQQQQIIQQ",blob,shoff+i*entsize) for i in range(count)]
    shstr=sections[stridx];names=blob[shstr[4]:shstr[4]+shstr[5]]
    section_names=[names[s[0]:names.find(b"\0",s[0])].decode() for s in sections]
    dynsym=sections[section_names.index(".dynsym")]
    dynstr=sections[dynsym[6]]
    strings=blob[dynstr[4]:dynstr[4]+dynstr[5]]
    output={}
    for off in range(dynsym[4],dynsym[4]+dynsym[5],dynsym[9]):
        name,_info,_other,shndx,value,_size=struct.unpack_from("<IBBHQQ",blob,off)
        if name and shndx:
            end=strings.find(b"\0",name)
            output.setdefault(strings[name:end].decode(),[]).append(value)
    return output


def undefined_dynsyms(path: Path) -> set[str]:
    blob=path.read_bytes()
    shoff=struct.unpack_from("<Q",blob,40)[0]
    entsize,count,stridx=struct.unpack_from("<HHH",blob,58)
    sections=[struct.unpack_from("<IIQQQQIIQQ",blob,shoff+i*entsize) for i in range(count)]
    shstr=sections[stridx];names=blob[shstr[4]:shstr[4]+shstr[5]]
    section_names=[names[s[0]:names.find(b"\0",s[0])].decode() for s in sections]
    dynsym=sections[section_names.index(".dynsym")]
    dynstr=sections[dynsym[6]]
    strings=blob[dynstr[4]:dynstr[4]+dynstr[5]]
    output=set()
    for off in range(dynsym[4],dynsym[4]+dynsym[5],dynsym[9]):
        name,_info,_other,shndx,_value,_size=struct.unpack_from("<IBBHQQ",blob,off)
        if name and not shndx:
            end=strings.find(b"\0",name)
            output.add(strings[name:end].decode())
    return output


def elf_jump_slot_relocations(path: Path) -> list[tuple[int,int,str]]:
    blob=path.read_bytes()
    shoff=struct.unpack_from("<Q",blob,40)[0]
    entsize,count,stridx=struct.unpack_from("<HHH",blob,58)
    sections=[struct.unpack_from("<IIQQQQIIQQ",blob,shoff+i*entsize) for i in range(count)]
    shstr=sections[stridx];shnames=blob[shstr[4]:shstr[4]+shstr[5]]
    section_names=[shnames[s[0]:shnames.find(b"\0",s[0])].decode() for s in sections]
    dynsym=sections[section_names.index(".dynsym")]
    dynstr=sections[dynsym[6]];strings=blob[dynstr[4]:dynstr[4]+dynstr[5]]
    symbols=[]
    for off in range(dynsym[4],dynsym[4]+dynsym[5],dynsym[9]):
        name=struct.unpack_from("<I",blob,off)[0]
        end=strings.find(b"\0",name) if name else name
        symbols.append(strings[name:end].decode() if name else "")
    result=[]
    for name,index in zip(section_names,range(len(sections))):
        if name!=".rela.plt":continue
        section=sections[index]
        for off in range(section[4],section[4]+section[5],section[9]):
            target,info,_addend=struct.unpack_from("<QQq",blob,off)
            symbol_index=info>>32;relocation_type=info&0xffffffff
            if symbol_index<len(symbols):result.append((target,relocation_type,symbols[symbol_index]))
    return result


def elf_aarch64_bl_callers(path: Path, target: int) -> list[int]:
    blob=path.read_bytes()
    phoff=struct.unpack_from("<Q",blob,32)[0]
    phent,phnum=struct.unpack_from("<HH",blob,54)
    callers=[]
    for i in range(phnum):
        kind,flags,offset,vaddr,_paddr,filesz,_memsz,_align=struct.unpack_from("<II6Q",blob,phoff+i*phent)
        if kind!=1 or not (flags&1):continue
        for delta in range(0,filesz-3,4):
            word=struct.unpack_from("<I",blob,offset+delta)[0]
            if word>>26==0b100101 and decode_aarch64_bl_target(vaddr+delta,word)==target:
                callers.append(vaddr+delta)
    return callers


def elf_vaddr_bytes(path: Path, address: int, length: int) -> bytes:
    blob=path.read_bytes()
    phoff=struct.unpack_from("<Q",blob,32)[0]
    phent,phnum=struct.unpack_from("<HH",blob,54)
    for i in range(phnum):
        kind,_flags,offset,vaddr,_paddr,filesz,_memsz,_align=struct.unpack_from("<II6Q",blob,phoff+i*phent)
        if kind==1 and vaddr<=address and address+length<=vaddr+filesz:
            start=offset+address-vaddr
            return blob[start:start+length]
    raise RuntimeError(f"ELF virtual range is not backed by a PT_LOAD: {path} {address:#x}+{length:#x}")

def decode_aarch64_bl_target(pc: int, instruction: int) -> int:
    if instruction >> 26 != 0b100101:
        raise ValueError(f"instruction at {pc:#x} is not AArch64 BL: {instruction:#x}")
    immediate=instruction & 0x03ffffff
    if immediate & 0x02000000:
        immediate-=0x04000000
    return pc+immediate*4

def decode_aarch64_b_target(pc: int, instruction: int) -> int:
    if instruction>>26!=0b000101:
        raise ValueError(f"instruction at {pc:#x} is not AArch64 B: {instruction:#x}")
    immediate=instruction&0x03ffffff
    if immediate&0x02000000:immediate-=0x04000000
    return pc+immediate*4

def decode_aarch64_adr_target(pc: int, instruction: int) -> int:
    if instruction & 0x9f000000 != 0x10000000:
        raise ValueError(f"instruction at {pc:#x} is not AArch64 ADR: {instruction:#x}")
    immlo=(instruction >> 29)&0x3
    immhi=(instruction >> 5)&0x7ffff
    immediate=(immhi << 2)|immlo
    if immediate & (1 << 20):
        immediate-=1 << 21
    return pc+immediate

def decode_aarch64_gp_u64(va_list_bytes: bytes, read_u64):
    if len(va_list_bytes)!=32:
        raise ValueError("AAPCS64 va_list must be exactly 32 bytes")
    stack,gr_top,vr_top,gr_offs,vr_offs=struct.unpack("<QQQii",va_list_bytes)
    if gr_offs!=-32 or vr_offs!=-128:
        raise ValueError(f"unexpected formatter va_list register offsets: gr={gr_offs}, vr={vr_offs}")
    if not stack or not gr_top or not vr_top:
        raise ValueError("AAPCS64 va_list contains a null area pointer")
    return {"stack":stack,"gr_top":gr_top,"vr_top":vr_top,"gr_offs":gr_offs,
            "vr_offs":vr_offs,"argument_address":gr_top+gr_offs,
            "argument_u64":read_u64(gr_top+gr_offs)}

def render_shader_cache_filename(format_bytes: bytes, value: int, capacity: int) -> bytes:
    if format_bytes!=EXPECTED_VSNPRINTF_FORMAT:
        raise ValueError(f"unsupported shader cache filename format: {format_bytes!r}")
    if not 0<=value<=0xffffffffffffffff:
        raise ValueError("shader cache key is outside uint64 range")
    if capacity!=EXPECTED_VSNPRINTF_CAPACITY:
        raise ValueError(f"unexpected cache filename destination capacity: {capacity}")
    rendered=f"/sh{value}.dat".encode("ascii")
    if len(rendered)>=capacity:
        raise ValueError("source-pinned shader cache filename would truncate")
    return rendered

def guest_strchr_result(raw: bytes, character: int, guest_pointer: int) -> int:
    if b"\0" in raw:
        raise ValueError("strchr fixture input must omit its terminating NUL")
    needle=character&0xff
    if needle==0:
        return guest_pointer+len(raw)
    offset=raw.find(bytes((needle,)))
    return guest_pointer+offset if offset>=0 else 0

def checked_strlen_bytes(raw: bytes, bound: int) -> int:
    if bound<=0 or len(raw)!=bound:
        raise ValueError("fortified strlen input must be exactly the positive object bound")
    length=raw.find(b"\0")
    if length<0:
        raise ValueError(f"__strlen_chk would abort: no NUL within {bound} bytes")
    return length

def fortified_strncpy_bytes(source: bytes, count: int, destination_size: int, source_size: int) -> bytes:
    if min(count,destination_size,source_size)<0 or count>destination_size or count>source_size:
        raise ValueError("fortified strncpy_chk2 size check failed")
    if len(source)<count:
        raise ValueError("fortified strncpy_chk2 source fixture shorter than requested copy")
    raw=source[:count]
    end=raw.find(b"\0")
    return raw if end<0 else raw[:end]+bytes(count-end)

def active_uniform_name_case(raw: bytes, cap: int) -> tuple[bytes,int]:
    if cap!=ACTIVE_UNIFORM_BUFFER_SIZE or len(raw)!=cap:
        raise ValueError("active-uniform output must match the pinned 63-byte GL buffer")
    length=raw.find(b"\0")
    if length<0:
        raise ValueError("Mesa active-uniform output lacks NUL in its declared buffer")
    return raw,length

def guest_strcmp_bytes(left: bytes, right: bytes) -> tuple[int,bytes,bytes]:
    """C strcmp result as first unsigned-byte difference, including NUL."""
    left_c=left+b"\0";right_c=right+b"\0"
    for index,(a,b) in enumerate(zip(left_c,right_c)):
        if a!=b:return a-b,left_c[:index+1],right_c[:index+1]
    if len(left_c)!=len(right_c):
        raise AssertionError("NUL-terminated strcmp operands must differ before the longer NUL")
    return 0,left_c,right_c

def little_endian_u32_from_hex_bytes(raw_hex: str) -> int:
    """Decode a JSON byte-order hex field as a little-endian uint32 bit pattern."""
    raw=bytes.fromhex(raw_hex)
    if len(raw)!=4:
        raise ValueError(f"expected exactly four serialized float32 bytes, got {len(raw)}")
    return int.from_bytes(raw,"little",signed=False)

def float32_bit_order_fixture_tests() -> dict:
    source_numeric_bits=0x3ecccccd
    source_little_endian_bytes=struct.pack("<I",source_numeric_bits)
    serialized_json_hex="cdcccc3e"
    decoded_bits=little_endian_u32_from_hex_bytes(serialized_json_hex)
    if decoded_bits!=source_numeric_bits or source_little_endian_bytes.hex()!=serialized_json_hex:
        raise RuntimeError("float32 JSON little-endian bytes were confused with numeric register-bit notation")
    return {"status":"passed","source_register_bits_u32_hex":hex(source_numeric_bits),
            "serialized_little_endian_bytes_hex":source_little_endian_bytes.hex(),
            "decoded_serialized_bits_u32_hex":hex(decoded_bits),
            "numeric_bits_equal_after_explicit_decode":decoded_bits==source_numeric_bits}

def aligned_guest_layout(heap: int, size: int, alignment: int) -> tuple[int, int, int]:
    """Return raw base, aligned pointer and next heap for one guest allocation."""
    if size < 0 or alignment < 8 or alignment & (alignment - 1):
        raise ValueError("invalid POSIX allocation size/alignment")
    raw=heap
    pointer=(raw+alignment-1)&~(alignment-1)
    extent=max(size,1)
    next_heap=(pointer+extent+15)&~15
    return raw,pointer,next_heap

def aligned_guest_layout_fixture_tests() -> dict:
    cases=((0x10000000,0x90,16),(0x10000010,0x90,64),(0x10000020,1,8))
    rows=[]
    for heap,size,alignment in cases:
        raw,pointer,next_heap=aligned_guest_layout(heap,size,alignment)
        if pointer%alignment or pointer<raw or next_heap<pointer+max(size,1):
            raise RuntimeError("aligned guest allocator fixture violated alignment or extent")
        rows.append({"heap":hex(heap),"size":size,"alignment":alignment,"raw":hex(raw),"pointer":hex(pointer),"next_heap":hex(next_heap)})
    for size,alignment in ((0,0),(1,4),(1,24)):
        try:aligned_guest_layout(0x10000000,size,alignment)
        except ValueError:continue
        raise RuntimeError("aligned guest allocator fixture accepted invalid POSIX alignment")
    return {"status":"passed","cases":rows,"rejects_subpointer_alignment_and_non_power_of_two":True}

def pop_texture_oracle_observer_return(observer_stack: list[dict], helper_pending_return: int | None) -> dict | None:
    """Match one observed helper-managed factory entry to the shared return trampoline."""
    if helper_pending_return is None:
        raise RuntimeError("TextureOracle trampoline reached without a helper pending-return address")
    if not observer_stack:
        return None
    row=observer_stack[-1]
    if int(row["caller_lr"],16)!=helper_pending_return:
        raise RuntimeError(f"TextureOracle helper return does not match the observed factory type: helper={helper_pending_return:#x}, observer={row!r}")
    return observer_stack.pop()

def texture_oracle_return_fixture_tests() -> dict:
    """Exercise interleaved helper types using the source-pinned shared trampoline contract."""
    observer_stack=[]
    helper_returns=[]
    for kind,caller_lr in (("CreateBitmap",0x1010),("CreateTextureObject",0x2020)):
        row={"kind":kind,"caller_lr":hex(caller_lr)}
        observer_stack.append(row)
        helper_returns.append(caller_lr)
    dispatched=[]
    for expected in ("CreateTextureObject","CreateBitmap"):
        row=pop_texture_oracle_observer_return(observer_stack,helper_returns.pop())
        if row is None or row["kind"]!=expected:
            raise RuntimeError("interleaved TextureOracle fixture misclassified a typed native return")
        dispatched.append(row["kind"])
    if observer_stack or helper_returns:
        raise RuntimeError("interleaved TextureOracle fixture left a typed return pending")
    # A helper return without a source-observed factory row is recorded as
    # unrelated instead of being asserted to be a TextureObject return.
    if pop_texture_oracle_observer_return([],0x3030) is not None:
        raise RuntimeError("unmatched shared-trampoline fixture was falsely typed as a texture factory")
    mismatch_stack=[{"kind":"CreateBitmap","caller_lr":hex(0x4040)}]
    try:pop_texture_oracle_observer_return(mismatch_stack,0x5050)
    except RuntimeError:pass
    else:raise RuntimeError("TextureOracle fixture accepted a mismatched helper LR/type row")
    return {"status":"passed","shared_return_trampoline":True,
            "interleaved_dispatch_order":dispatched,
            "unobserved_helper_return_classified_as":"unrelated",
            "helper_lr_mismatch_rejected":True}

def fake_vsnprintf_tests() -> dict:
    arg_address=0x5000
    fixture={arg_address:0x87b7bb8f}
    va=struct.pack("<QQQii",0x6070,0x5020,0x6080,-32,-128)
    decoded=decode_aarch64_gp_u64(va,lambda address:fixture[address])
    assert decoded["argument_address"]==arg_address and decoded["argument_u64"]==0x87b7bb8f
    assert render_shader_cache_filename(EXPECTED_VSNPRINTF_FORMAT,decoded["argument_u64"],128)==b"/sh2276965263.dat"
    assert guest_strchr_result(b"wb",ord("w"),0x5000)==0x5000
    assert guest_strchr_result(b"rb",ord("w"),0x5000)==0
    assert guest_strchr_result(b"wb",ord("a"),0x5000)==0
    assert guest_strchr_result(b"rb",0,0x5000)==0x5002
    assert guest_strchr_result(b"x\xffz",0x1ff,0x5000)==0x5001
    assert guest_strcmp_bytes(b"ProjectionMatrix",b"ProjectionMatrix")[0]==0
    assert guest_strcmp_bytes(b"ProjectionMatrix",b"ProjectionMatrix[0]")[0]<0
    result,left_read,right_read=guest_strcmp_bytes(b"x\xff",b"x\x01")
    assert result==254 and left_read==b"x\xff" and right_read==b"x\x01"
    result,left_read,right_read=guest_strcmp_bytes(b"short",b"shorter")
    assert result==0-ord("e") and left_read==b"short\0" and right_read==b"shorte"
    assert checked_strlen_bytes(b"ProjectionMatrix\0"+bytes(64-len(b"ProjectionMatrix\0")),64)==16
    assert checked_strlen_bytes(b"x"*63+b"\0",64)==63
    try:checked_strlen_bytes(b"x"*64,64)
    except ValueError:pass
    else:raise RuntimeError("fake __strlen_chk test accepted a missing terminator")
    name_buffer=b"ProjectionMatrix\0"+bytes(64-len(b"ProjectionMatrix\0"))
    assert fortified_strncpy_bytes(name_buffer,16,128,64)==b"ProjectionMatrix"
    assert fortified_strncpy_bytes(name_buffer,20,128,64)==b"ProjectionMatrix"+bytes(4)
    active,length=active_uniform_name_case(b"ProjectionMatrix\0"+bytes(63-len(b"ProjectionMatrix\0")),63)
    assert length==16 and active[:length]==b"ProjectionMatrix"
    try:fortified_strncpy_bytes(b"x"*8,9,128,64)
    except ValueError:pass
    else:raise RuntimeError("fake __strncpy_chk2 test accepted a source-bound overflow")
    for invalid in (struct.pack("<QQQii",0x6070,0x5020,0x6080,0,-128),
                    struct.pack("<QQQii",0x6070,0x5020,0x6080,-32,-64)):
        try:decode_aarch64_gp_u64(invalid,lambda address:fixture[address])
        except ValueError:pass
        else:raise RuntimeError("fake AAPCS64 test accepted an incompatible register-save state")
    return {"status":"passed","scope":"pure Python ABI/filename, bounded C string, and DSO address/mapping fixtures; no native imports or execution",
            "fake_argument_hex":hex(decoded["argument_u64"]),"rendered":b"/sh2276965263.dat".decode(),
            "strchr_cases":["found first byte","not found","include terminating NUL","unsigned char conversion"],
            "strcmp_cases":["equal strings including NUL","prefix comparison including terminating NUL","unsigned byte difference"],
            "fortified_string_cases":["strlen below bound","strlen at bound with valid terminator","strlen fail on missing NUL","strncpy_chk2 bounded copy","strncpy_chk2 rejects source overflow"],
            "mapped_dso_base_cases":mapped_dso_fixture_tests()}


def mapped_dso_fixture_tests() -> dict:
    initial_common=[(0x01000000,0x011fffff,7)]
    common=resolve_mapped_dso_base(0x01048650,0x48650,0x01000000,initial_common,"PenCommon fixture")
    if common!=0x01000000:raise RuntimeError("initial-library mapping fixture failed")
    try:
        resolve_mapped_dso_base(0x01048650,0x48650,0x01000000,[],"missing mapping fixture")
    except RuntimeError:
        pass
    else:
        raise RuntimeError("DSO range validator accepted an unmapped range")
    try:
        resolve_mapped_dso_base(0x02048650,0x48650,0x01000000,initial_common,"wrong symbol fixture")
    except RuntimeError:
        pass
    else:
        raise RuntimeError("DSO range validator accepted a mismatched export base")
    return {"status":"passed","initial_library_symbol_join":hex(common),
            "missing_mapping_rejected":True,"wrong_symbol_base_rejected":True}

def finish_native_framebuffer_call_observation(probe, receiver: int, expected_stop_pc: int) -> dict:
    """Record a native call result after NativeFountain.call stops at its sentinel."""
    pc=probe.u.reg_read(LAST_REGS.UC_ARM64_REG_PC)
    lr=probe.u.reg_read(LAST_REGS.UC_ARM64_REG_LR)
    if pc!=expected_stop_pc or lr!=expected_stop_pc:
        raise RuntimeError(f"native CreateFrameBuffer call did not stop at the pinned NativeFountain.call sentinel: pc={pc:#x}, lr={lr:#x}, expected={expected_stop_pc:#x}")
    pending=probe.pending_framebuffer_create
    if not isinstance(pending,dict):
        raise RuntimeError("native CreateFrameBuffer stop has no pending source observer row")
    if (pending.get("symbol")!=CREATE_SUBBITMAP_FRAMEBUFFER or
        int(pending.get("receiver","0"),16)!=receiver or
        int(pending.get("return_pc","0"),16)!=expected_stop_pc or
        int(pending.get("caller_lr","0"),16)!=expected_stop_pc):
        raise RuntimeError(f"native CreateFrameBuffer stop changed the observed receiver or caller/return PC: {pending!r}")
    field_80=probe.get(receiver+80,"Q")[0]
    field_88=probe.get(receiver+88,"Q")[0]
    offscreen=probe.get(field_88+16,"Q")[0] if field_88 else 0
    if field_80!=int(pending["receiver_field_80_before"],16):
        raise RuntimeError(f"native CreateFrameBuffer changed the already-created target texture pointer: before={pending['receiver_field_80_before']}, after={field_80:#x}")
    row=dict(pending)
    row.update({"returned_at":hex(pc),"call_stop_pc":hex(expected_stop_pc),
        "call_stop_lr":hex(lr),"receiver_field_80_after":hex(field_80),
        "receiver_field_88_after":hex(field_88),
        "native_framebuffer_offscreen_target":hex(offscreen) if offscreen else None,
        "framebuffer_object_vptr":hex(probe.get(field_88,"Q")[0]) if field_88 else None,
        "offscreen_target_vptr":hex(probe.get(offscreen,"Q")[0]) if offscreen else None,
        "observation_boundary":"post-return PC/LR verification after shipped NativeFountain.call stopped at its sentinel; native call body completed"})
    probe.framebuffer_create_calls.append(row)
    probe.pending_framebuffer_create=None
    return row


def preflight() -> dict:
    fake_test_receipt=fake_vsnprintf_tests()
    fake_test_receipt["nm_defined_row_parser"]=nm_parser_fixture_tests()
    fake_test_receipt["float32_bit_order"]=float32_bit_order_fixture_tests()
    fake_test_receipt["aligned_guest_allocator"]=aligned_guest_layout_fixture_tests()
    fake_test_receipt["texture_oracle_typed_return_dispatch"]=texture_oracle_return_fixture_tests()
    v30_failure=json.loads(V30_FAILURE.read_text())
    v30_diag=v30_failure.get("diagnostics",{})
    if (v30_failure.get("exception")!="RuntimeError('unhandled native import posix_memalign')" or
        v30_diag.get("pc")!="0x8132c98" or v30_diag.get("lr")!="0x80a0240" or
        v30_diag.get("registers_x0_x7",[])[:3]!=["0x200effb8","0x10","0x90"] or
        v30_diag.get("geometry_buffer_contract",{}).get("addpoint_comparison",{}).get("mismatch_byte_count")!=0 or
        v30_failure.get("pixel_claim") is not False):
        raise RuntimeError("pinned V30 failure no longer proves exact aligned-allocation ABI request after geometry equality")
    if not V32_FAILURE_SHA256 or sha(V32_FAILURE) != V32_FAILURE_SHA256:
        raise RuntimeError("V32 failure receipt pin is not finalized or does not match")
    if sha(V34_FAILURE)!=V34_FAILURE_SHA256:
        raise RuntimeError("V34 pending-frame observer receipt pin mismatch")
    if (sha(V35_FAILURE)!=V35_FAILURE_SHA256 or sha(V35_CANDIDATE)!=V35_CANDIDATE_SHA256 or
        sha(V35_MANIFEST)!=V35_MANIFEST_SHA256):
        raise RuntimeError("V35 observer failure/candidate/manifest pins do not match frozen inputs")
    v35_failure=json.loads(V35_FAILURE.read_text())
    if (v35_failure.get("exception")!="RuntimeError('TextureOracle return trampoline has no matching CreateTextureObject observer row')" or
        v35_failure.get("pixel_claim") is not False):
        raise RuntimeError("V35 receipt no longer proves a no-pixel TextureOracle return-observer classification failure")
    if (sha(V36_FAILURE)!=V36_FAILURE_SHA256 or sha(V36_CANDIDATE)!=V36_CANDIDATE_SHA256 or
        sha(V36_MANIFEST)!=V36_MANIFEST_SHA256):
        raise RuntimeError("V36 framebuffer-observer failure/candidate/manifest pins do not match")
    v36_failure=json.loads(V36_FAILURE.read_text())
    v36_pending=v36_failure.get("diagnostics",{}).get("pending_framebuffer_create") or {}
    if (v36_failure.get("exception")!="RuntimeError('native SPSubBitmapRT::CreateFrameBuffer did not complete its source-pinned lifecycle observation')" or
        v36_failure.get("pixel_claim") is not False or v36_pending.get("entry_pc")!="0x408ddd0" or
        v36_pending.get("caller_lr")!="0x200f1000" or v36_pending.get("receiver")!="0x1003cf20" or
        len(v36_failure.get("diagnostics",{}).get("texture_factory_calls",[]))<3):
        raise RuntimeError("V36 failure no longer proves the call reached its NativeFountain stop after the pinned texture callbacks")
    if (sha(V37_SUCCESS)!=V37_SUCCESS_SHA256 or sha(V37_RETROSPECTIVE)!=V37_RETROSPECTIVE_SHA256 or
        sha(V37_CANDIDATE)!=V37_CANDIDATE_SHA256 or sha(V37_MANIFEST)!=V37_MANIFEST_SHA256):
        raise RuntimeError("V37 native Draw receipt/retrospective/candidate/manifest pins do not match")
    v37_success=json.loads(V37_SUCCESS.read_text())
    v37_geometry=v37_success.get("native_geometry_buffer_contract",{}).get("addpoint_comparison",{})
    v37_mesa=v37_success.get("mesa",{})
    if (v37_geometry.get("mismatch_byte_count")!=0 or v37_geometry.get("actual_bytes")!=224 or
        v37_mesa.get("readback_sha256")!="f60b90981bdc11a031106a7dcf99e2ad731221ad8c2b5b62c45d388243bbec6e" or
        v37_mesa.get("draw_calls")!=[{"args":[5,0,4,4],"name":"glDrawArraysInstanced","result":None}] or
        v37_mesa.get("post_minus_pre_channel_receipt",{}).get("changed_channel_bytes")!=[0,0,0,2]):
        raise RuntimeError("V37 source receipt no longer proves four-row exact geometry and the pinned alpha-only Mesa control paint")
    fountain_text=(HELPERS/"fountain_native.py").read_text()
    if ("self.u.emu_start(self.syms[name], 0x200f1000, count=instruction_limit)" not in fountain_text or
        "if self.u.reg_read(R.UC_ARM64_REG_PC) != 0x200f1000:" not in fountain_text):
        raise RuntimeError("NativeFountain.call stop-sentinel contract changed")
    drawing_receipt=json.loads(DRAWPOINT_RECEIPT.read_text())
    full_rows=[row for row in drawing_receipt.get("addpoint_events",[]) if row.get("phase")=="draw_object_stroke"]
    full_stream=drawing_receipt.get("streams",{}).get("draw_object_stroke",{})
    full_stream_bytes=bytes.fromhex(full_stream.get("data_hex",""))
    if (len(full_rows)!=DRAWPOINT_FULL_STREAM_ROWS or full_stream.get("addpoint_calls")!=DRAWPOINT_FULL_STREAM_ROWS or
        full_stream.get("bytes")!=DRAWPOINT_FULL_STREAM_BYTES or full_stream.get("record_stride_bytes")!=56 or
        hashlib.sha256(full_stream_bytes).hexdigest()!=DRAWPOINT_FULL_STREAM_SHA256 or
        full_stream.get("sha256")!=DRAWPOINT_FULL_STREAM_SHA256 or
        b"".join(bytes.fromhex(row["delta_bytes"]) for row in full_rows)!=full_stream_bytes):
        raise RuntimeError("pinned V29 Drawing receipt does not have the audited complete 84-row/4704-byte draw_object_stroke stream")
    if (sha(V35_FAILURE)!=V35_FAILURE_SHA256 or sha(V35_CANDIDATE)!=V35_CANDIDATE_SHA256 or
        sha(V35_MANIFEST)!=V35_MANIFEST_SHA256):
        raise RuntimeError("V35 observer failure/candidate/manifest pins do not match frozen inputs")
    v35_failure=json.loads(V35_FAILURE.read_text())
    if (v35_failure.get("exception")!="RuntimeError('TextureOracle return trampoline has no matching CreateTextureObject observer row')" or
        v35_failure.get("pixel_claim") is not False):
        raise RuntimeError("V35 receipt no longer proves a no-pixel TextureOracle return-observer classification failure")
    v34_failure=json.loads(V34_FAILURE.read_text())
    v34_diag=v34_failure.get("diagnostics",{})
    v34_rt=v34_diag.get("texture_rt_calls",[])
    v34_factories=v34_diag.get("texture_factory_stack",[])
    if ("pending nested createTextureRT/factory frames" not in v34_failure.get("exception","") or
        len(v34_rt)!=3 or [row.get("receiver") for row in v34_rt]!=["0x100090a0","0x100094f0","0x1003cf20"] or
        [row.get("descriptor_u32_0_5",[])[:2] for row in v34_factories]!=[[150,150],[100,300],[192,192]] or
        v34_failure.get("pixel_claim") is not False):
        raise RuntimeError("pinned V34 receipt no longer proves sequential 150x150/100x300/target factory records and missed trampoline exits")
    if not V33_FAILURE_SHA256 or sha(V33_FAILURE) != V33_FAILURE_SHA256:
        raise RuntimeError("V33 observer failure receipt pin is not finalized or does not match")
    v33_failure=json.loads(V33_FAILURE.read_text())
    v33_diag=v33_failure.get("diagnostics",{})
    pending_factory=v33_diag.get("pending_texture_factory") or {}
    if (v33_failure.get("exception")!="RuntimeError('overlapping native target texture factory call')" or
        v33_failure.get("pixel_claim") is not False or
        pending_factory.get("descriptor_u32_0_5",[])[:2]!=[150,150] or
        pending_factory.get("descriptor_render_target_byte_24")!=0):
        raise RuntimeError("pinned V33 failure does not show unrelated nested RT-init texture factory entry")
    v32_failure=json.loads(V32_FAILURE.read_text())
    v32_diag=v32_failure.get("diagnostics",{})
    v32_activations=v32_diag.get("target_activation_calls",[])
    if (v32_failure.get("exception")!="RuntimeError('unhandled native import dl_iterate_phdr')" or
        v32_failure.get("pixel_claim") is not False or not v32_activations or
        v32_activations[0].get("receiver_field_88")!="0x0"):
        raise RuntimeError("pinned V32 failure no longer records null native framebuffer field+88")
    v31_failure=json.loads(V31_FAILURE.read_text())
    v31_diag=v31_failure.get("diagnostics",{})
    v31_calls=v31_diag.get("last_native_calls",[])
    throw_index=next((i for i,row in enumerate(v31_calls) if row.get("symbol")=="__cxa_throw"),None)
    unwind_index=next((i for i,row in enumerate(v31_calls) if row.get("symbol")=="dl_iterate_phdr"),None)
    frame_error=next((row for row in v31_diag.get("native_libcpp",{}).get("strlen_calls",[])
                      if row.get("input_text")=="FrameBuffer is nullptr!"),None)
    posix_calls=v31_diag.get("native_libcpp",{}).get("posix_memalign_calls",[])
    activations=v31_diag.get("target_activation_calls",[])
    if (v31_failure.get("exception")!="RuntimeError('unhandled native import dl_iterate_phdr')" or
        throw_index is None or unwind_index is None or throw_index>=unwind_index or frame_error is None or
        frame_error.get("caller_symbol")!="std::logic_error::logic_error(char const*)" or
        len(posix_calls)!=1 or posix_calls[0].get("return_code")!=0 or posix_calls[0].get("alignment")!=16 or posix_calls[0].get("size")!=144 or
        len(activations)!=1 or activations[0].get("receiver_field_88")!="0x0" or
        v31_failure.get("pixel_claim") is not False):
        raise RuntimeError("pinned V31 failure does not prove the original source logic_error after successful aligned allocation")
    renderer=LIB/"libSPenRenderer.so"
    if elf_vaddr_bytes(renderer,EXPECTED_VSNPRINTF_FORMAT_RVA,len(EXPECTED_VSNPRINTF_FORMAT)+1)!=EXPECTED_VSNPRINTF_FORMAT+b"\0":
        raise RuntimeError("pinned Renderer cache filename format bytes changed")
    if not any("GetBindingIntf" in name for name in REQUIRED_DYNSYMS["libSPenRenderer.so"]):
        raise RuntimeError("pinned Renderer GetBindingIntf export missing")
    pen_common=LIB/"libSPenPenCommon.so"
    set_buffer_bytes=struct.pack("<III",0xf9002801,0xf9003402,0xd65f03c0)
    send_buffer_bytes=struct.pack("<III",0xf9002c01,0xf9003802,0xd65f03c0)
    if (elf_vaddr_bytes(pen_common,PEN_COMMON_SET_BUFFER_RVA,len(set_buffer_bytes))!=set_buffer_bytes or
        elf_vaddr_bytes(pen_common,PEN_COMMON_SEND_DATA_TO_GPU_RVA,len(send_buffer_bytes))!=send_buffer_bytes):
        raise RuntimeError("pinned PenDrawableRT SetBuffer/SendDataToGPU pointer-offset semantics changed")
    if elf_vaddr_bytes(pen_common,PEN_COMMON_SET_PEN_DATA_RVA,len(PEN_COMMON_SET_PEN_DATA_BYTES))!=PEN_COMMON_SET_PEN_DATA_BYTES:
        raise RuntimeError("pinned PenDrawableRT::SetPenData ARGB-to-RGBA/size field writes changed")
    if elf_vaddr_bytes(LIB/"libSPenPencil2.so",PENCIL2_SET_INVERSE_SCALE_RVA,len(PENCIL2_SET_INVERSE_SCALE_BYTES))!=PENCIL2_SET_INVERSE_SCALE_BYTES:
        raise RuntimeError("pinned Pencil2 RTV4 SetInverseScale no longer copies Vector2 to RT+252")
    color_layout_doc=COLOR_LAYOUT_DOC.read_bytes()
    if hashlib.sha256(color_layout_doc).hexdigest()!=COLOR_LAYOUT_DOC_SHA256:
        raise RuntimeError("pinned native TextureMemoryLayout/TextureTargetLayout evidence changed")
    if (b"TextureMemoryLayout=6, TextureTargetLayout=2" not in color_layout_doc or
        b"GL_RGBA8" not in color_layout_doc or b"GL_UNSIGNED_BYTE" not in color_layout_doc):
        raise RuntimeError("pinned source receipt no longer documents the (6,2) RGBA8 target pair")
    callback_ctor_prefix=struct.pack("<II",0xf9000802,0x91004108)
    if elf_vaddr_bytes(pen_common,PEN_COMMON_RETURN_CALLBACK_CTOR_RVA+12,len(callback_ctor_prefix))!=callback_ctor_prefix:
        raise RuntimeError("pinned PenReturnCallback constructor arguments/owned-buffer initialization changed")
    get_buffer_prefix=struct.pack("<IIIIII",0xf9401400,0xb50000c0,0x52800300,0x9400832d,0xa900fc1f,0xf900001f)
    if elf_vaddr_bytes(pen_common,PEN_COMMON_RETURN_CALLBACK_GET_BUFFER_RVA+16,len(get_buffer_prefix))!=get_buffer_prefix:
        raise RuntimeError("pinned PenReturnCallback::GetBuffer no longer creates a zeroed native 24-byte vector")
    graphics=LIB/"libSPenGraphics.so"
    create_texture_rt_entry_bl=struct.unpack("<I",elf_vaddr_bytes(graphics,0x8d974,4))[0]
    create_texture_factory_bl=struct.unpack("<I",elf_vaddr_bytes(graphics,0x8da64,4))[0]
    if (decode_aarch64_bl_target(0x8d974,create_texture_rt_entry_bl)!=0xc9020 or
        decode_aarch64_bl_target(0x8da64,create_texture_factory_bl)!=0xc9000):
        raise RuntimeError("pinned Graphics SPSubBitmapRT constructor/createTextureRT/CreateTextureObject call chain changed")
    subbitmap_bool_arg=struct.unpack("<I",elf_vaddr_bytes(graphics,0x8d8c4,4))[0]
    subbitmap_bool_forward=struct.unpack("<I",elf_vaddr_bytes(graphics,0x8d968,4))[0]
    texture_rt_mask=struct.unpack("<I",elf_vaddr_bytes(graphics,0x8da34,4))[0]
    texture_desc_store=struct.unpack("<I",elf_vaddr_bytes(graphics,0x8da54,4))[0]
    if (subbitmap_bool_arg!=0x394183ba or subbitmap_bool_forward!=0x2a1a03e6 or
        texture_rt_mask!=0x12000308 or texture_desc_store!=0x3900c3e8):
        raise RuntimeError("SPSubBitmapRT bool-to-TextureDescriptor render-target source contract changed")
    create_framebuffer_wrapper=struct.unpack("<IIII",elf_vaddr_bytes(graphics,0x8ddd0,16))
    create_framebuffer_impl=struct.unpack("<IIIIIIIIIIIIIIIIIIIIIIIIIIII",elf_vaddr_bytes(graphics,0x8de00,112))
    framebuffer_ctor=struct.unpack("<IIIIIIIIIIII",elf_vaddr_bytes(graphics,0x81d2c,48))
    if create_framebuffer_wrapper!=(0xf9400008,0x2a1f03e1,0xf9404902,0xd61f0040):
        raise RuntimeError("SPSubBitmapRT::CreateFrameBuffer wrapper no longer dispatches the native vtable slot +144")
    if (create_framebuffer_impl[0]!=0xf9402808 or create_framebuffer_impl[1]!=0xaa0003f3 or
        create_framebuffer_impl[2]!=0x2a0103f4 or create_framebuffer_impl[3]!=0xb4000088 or
        decode_aarch64_bl_target(0x8de64,create_framebuffer_impl[25])!=0xc8580 or
        create_framebuffer_impl[26]!=0xf9002e75):
        raise RuntimeError("SPSubBitmapRT::CreateFrameBufferRT no longer creates SPFrameBuffer and stores it at +88")
    if (framebuffer_ctor[0]!=0xaa0303f4 or framebuffer_ctor[1]!=0xaa0003f3 or
        decode_aarch64_bl_target(0x81d34,framebuffer_ctor[2])!=0xc85a0 or
        decode_aarch64_bl_target(0x81d4c,framebuffer_ctor[8])!=0xc85b0 or
        framebuffer_ctor[9]!=0xf9000a60):
        raise RuntimeError("SPFrameBuffer constructor no longer builds the Renderer offscreen target from texture+80")
    activate_prefix=struct.unpack("<III",elf_vaddr_bytes(graphics,0x8dfd0,12))
    activate_null_path=struct.unpack("<IIIII",elf_vaddr_bytes(graphics,0x8e010,20))
    exception_calls=struct.unpack("<IIII",elf_vaddr_bytes(graphics,0x8e050,16))
    if (activate_prefix!=(0xf9402c08,0xaa0003f3,0xb40001c8) or
        activate_null_path!=(0xf9402a60,0xf9400008,0xf9400d08,0xd63f0100,0xf100001f) or
        decode_aarch64_bl_target(0x8e054,exception_calls[1])!=0xc8750 or
        decode_aarch64_bl_target(0x8e064,struct.unpack("<I",elf_vaddr_bytes(graphics,0x8e064,4))[0])!=0xc8b30 or
        decode_aarch64_bl_target(0x8e07c,struct.unpack("<I",elf_vaddr_bytes(graphics,0x8e07c,4))[0])!=0xc8760):
        raise RuntimeError("SPSubBitmapRT ActivateFrameBufferRT null-FBO logic_error source path changed")
    for bl_rva,lr_rva in zip(STRLEN_CHK_BL_RVAS,sorted(STRLEN_CHK_CALLSITE_LRS)):
        instruction=struct.unpack("<I",elf_vaddr_bytes(renderer,bl_rva,4))[0]
        mov_bound=struct.unpack("<I",elf_vaddr_bytes(renderer,bl_rva-4,4))[0]
        if decode_aarch64_bl_target(bl_rva,instruction)!=STRLEN_CHK_PLT_RVA or lr_rva!=bl_rva+4 or mov_bound!=0x52800801:
            raise RuntimeError("pinned GetBindingIntf __strlen_chk callsite or 64-byte bound changed")
    for bl_rva,lr_rva in zip(STRNCPY_CHK2_BL_RVAS,sorted(STRNCPY_CHK2_CALLSITE_LRS)):
        instruction=struct.unpack("<I",elf_vaddr_bytes(renderer,bl_rva,4))[0]
        size_constants=struct.unpack("<II",elf_vaddr_bytes(renderer,bl_rva-8,8))
        if decode_aarch64_bl_target(bl_rva,instruction)!=STRNCPY_CHK2_PLT_RVA or lr_rva!=bl_rva+4 or size_constants!=(0x52801003,0x52800804):
            raise RuntimeError("pinned GetBindingIntf __strncpy_chk2 callsite or object bounds changed")
    native_strncpy_bl=0x5b380
    native_strncpy_instruction=struct.unpack("<I",elf_vaddr_bytes(renderer,native_strncpy_bl,4))[0]
    native_strncpy_setup=struct.unpack("<IIIII",elf_vaddr_bytes(renderer,native_strncpy_bl-20,20))
    if decode_aarch64_bl_target(native_strncpy_bl,native_strncpy_instruction)!=0x65610 or native_strncpy_setup!=(0x910383e0,0xaa1403e1,0xaa1503e2,0x52801003,0x910383f6):
        raise RuntimeError("pinned GetBindingIntf initial __strncpy_chk source copy changed")
    for strlen_call in (0x5b314,0x5b338,0x5b45c):
        strlen_instruction=struct.unpack("<I",elf_vaddr_bytes(renderer,strlen_call,4))[0]
        if decode_aarch64_bl_target(strlen_call,strlen_instruction)!=0x64060:
            raise RuntimeError("pinned GetBindingIntf strlen import callsite changed")
    active_uniform_bl=0x5b3d0
    active_uniform_instruction=struct.unpack("<I",elf_vaddr_bytes(renderer,active_uniform_bl,4))[0]
    active_uniform_cap=struct.unpack("<I",elf_vaddr_bytes(renderer,active_uniform_bl-4,4))[0]
    active_uniform_name_ptr=struct.unpack("<I",elf_vaddr_bytes(renderer,0x5b3c4,4))[0]
    if decode_aarch64_bl_target(active_uniform_bl,active_uniform_instruction)!=0x654f0 or active_uniform_cap!=0x528007e2 or active_uniform_name_ptr!=0xd10163a6:
        raise RuntimeError("pinned GetBindingIntf active-uniform query buffer contract changed")
    strcmp_instruction=struct.unpack("<I",elf_vaddr_bytes(renderer,STRCMP_CALLSITE_BL_RENDERER_RVA,4))[0]
    strcmp_operands=struct.unpack("<II",elf_vaddr_bytes(renderer,STRCMP_CALLSITE_BL_RENDERER_RVA-8,8))
    if decode_aarch64_bl_target(STRCMP_CALLSITE_BL_RENDERER_RVA,strcmp_instruction)!=STRCMP_PLT_RENDERER_RVA or STRCMP_CALLSITE_LR_RENDERER_RVA!=STRCMP_CALLSITE_BL_RENDERER_RVA+4 or strcmp_operands!=(0x910183e0,0x910383e1):
        raise RuntimeError("pinned GetBindingIntf strcmp caller/operand locals changed")
    getfile_bl=struct.unpack("<I",elf_vaddr_bytes(renderer,EXPECTED_GETFILENAME_TO_FORMATTER_BL_RENDERER_RVA,4))[0]
    format_bl=struct.unpack("<I",elf_vaddr_bytes(renderer,EXPECTED_VSNPRINTF_BL_RENDERER_RVA,4))[0]
    format_adr=struct.unpack("<I",elf_vaddr_bytes(renderer,EXPECTED_FORMAT_ADR_RENDERER_RVA,4))[0]
    if decode_aarch64_bl_target(EXPECTED_GETFILENAME_TO_FORMATTER_BL_RENDERER_RVA,getfile_bl)!=EXPECTED_FORMAT_HELPER_ENTRY_RENDERER_RVA:
        raise RuntimeError("GetFileName no longer branches to the pinned variadic formatter helper")
    if decode_aarch64_bl_target(EXPECTED_VSNPRINTF_BL_RENDERER_RVA,format_bl)!=EXPECTED_VSNPRINTF_PLT_RENDERER_RVA:
        raise RuntimeError("pinned formatter helper no longer calls the Renderer vsnprintf PLT")
    if decode_aarch64_adr_target(EXPECTED_FORMAT_ADR_RENDERER_RVA,format_adr)!=EXPECTED_VSNPRINTF_FORMAT_RVA:
        raise RuntimeError("pinned formatter helper ADR no longer targets the cache filename format")
    if elf_vaddr_bytes(renderer,RENDERER_READ_MODE_RVA,3)!=b"rb\0" or elf_vaddr_bytes(renderer,RENDERER_WRITE_MODE_RVA,3)!=b"wb\0":
        raise RuntimeError("pinned Renderer cache read/write mode strings changed")
    drawpoint_receipt_hash=sha(DRAWPOINT_RECEIPT)
    if drawpoint_receipt_hash!=DRAWPOINT_RECEIPT_SHA256:
        raise RuntimeError(f"native Drawing full-SmPoint receipt pin mismatch: {drawpoint_receipt_hash}")
    if sha(DRAWPOINT_CAPTURE_CANDIDATE)!=DRAWPOINT_CAPTURE_CANDIDATE_SHA256 or sha(DRAWPOINT_CAPTURE_MANIFEST)!=DRAWPOINT_CAPTURE_MANIFEST_SHA256:
        raise RuntimeError("native Drawing full-SmPoint producer candidate/manifest pin mismatch")
    drawpoint_receipt=json.loads(DRAWPOINT_RECEIPT.read_text())
    if (drawpoint_receipt.get("candidate_source")!="tmp/vector-parity-plan/pen-family-audit/pencil2-v14-mesa-draw-v29/source_capture_candidate.py" or
        drawpoint_receipt.get("route",{}).get("selected_drawable_version")!="v14" or
        drawpoint_receipt.get("native_source_basis",{}).get("glv14_draw_point_addpoint_return_lr")!="0x74754"):
        raise RuntimeError("native Drawing receipt does not prove the pinned V14 DrawPoint AddPoint source route")
    drawpoint_rows=drawpoint_receipt.get("addpoint_events",[])[:4]
    if len(drawpoint_rows)!=4:raise RuntimeError("native Drawing receipt lacks four full-SmPoint AddPoint inputs")
    for index,row in enumerate(drawpoint_rows):
        point16=bytes.fromhex(row.get("vector2_plus_tangent_bytes_16",""))
        point8=bytes.fromhex(row.get("vector2_bytes",""))
        delta=bytes.fromhex(row.get("delta_bytes",""))
        if (len(point16)!=16 or point16[:8]!=point8 or int(row.get("return_pc","0"),16)!=0x5074754 or
            len(delta)!=56 or point16[8:16]!=delta[28:36]):
            raise RuntimeError(f"native Drawing row {index} does not preserve the actual SmPoint input consumed by AddPoint: {row!r}")
    base_dso=LIB/"libSPenBase.so"
    for bl_rva,lr_rva,char_code in ((0x96184,0x96188,ord("w")),(0x96194,0x96198,ord("a"))):
        bl=struct.unpack("<I",elf_vaddr_bytes(base_dso,bl_rva,4))[0]
        if decode_aarch64_bl_target(bl_rva,bl)!=BASE_STRCHR_PLT_RVA:
            raise RuntimeError("pinned File::Construct mode scan no longer calls the Base strchr PLT")
        mov_w1=struct.unpack("<I",elf_vaddr_bytes(base_dso,bl_rva-4,4))[0]
        expected_mov=0x52800ee1 if char_code==ord("w") else 0x52800c21
        if mov_w1!=expected_mov or lr_rva!=bl_rva+4:
            raise RuntimeError("pinned File::Construct strchr mode-byte callsite changed")
    source = HERE / "capture_candidate.py"
    source_text=source.read_text()
    tree = ast.parse(source_text)
    if not any(isinstance(node,ast.Import) and any(alias.name=="math" for alias in node.names) for node in tree.body):
        raise RuntimeError("capture requires the explicitly imported math module used by the finite-size guard")
    cap = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "capture"), None)
    if cap is None:
        raise RuntimeError("capture function missing")
    calls = [n for n in ast.walk(cap) if isinstance(n, ast.Call)]
    replay_src = ast.get_source_segment(source_text, cap) or ""
    replay_begin = replay_src.find("# Replay all 84 actual draw_object_stroke AddPoint register rows")
    replay_end = replay_src.find("vector_begin,vector_end,vector_capacity=p.get(vector,\"3Q\")", replay_begin)
    if replay_begin < 0 or replay_end < 0:
        raise RuntimeError("capture must contain a bounded native geometry replay block")
    replay_block = replay_src[replay_begin:replay_end]
    if ("row[\"vector2_plus_tangent_bytes_16\"]" not in replay_block or
        "len(point16)!=16" not in replay_block or
        "vec=p.alloc(16)" not in replay_block or
        "p.u.mem_write(vec,point16)" not in replay_block or
        "int(row.get(\"return_pc\",\"0\"),16)!=0x5074754" not in replay_block):
        raise RuntimeError("V30 must replay the pinned full 16-byte SmPoint at the source-proven AddPoint caller")
    if ("len(rows)!=DRAWPOINT_FULL_STREAM_ROWS" not in replay_src or
        "len(expected_geometry)!=DRAWPOINT_FULL_STREAM_BYTES" not in replay_src or
        "actual_geometry!=expected_geometry or len(actual_geometry)!=DRAWPOINT_FULL_STREAM_BYTES" not in replay_src or
        "geometry[\"streams\"][\"draw_object_stroke\"]" not in replay_src):
        raise RuntimeError("Pencil2 replay must retain strict native equality against the complete pinned 84-row/4704-byte Drawing stream")
    names = {a.id for n in calls for a in n.args if isinstance(a, ast.Name)}
    if not {"RT_CTOR", "RT_INIT", "RT_ADD", "RT_UPDATE", "RT_DRAW", "RT_SET_INVERSE_SCALE", "PEN_RETURN_CALLBACK_CTOR", "PEN_RETURN_CALLBACK_GET_BUFFER", "PEN_DRAWABLE_SET_BUFFER", "PEN_DRAWABLE_SET_PEN_DATA", "PEN_DRAWABLE_SEND_DATA_TO_GPU"}.issubset(names):
        raise RuntimeError("capture must invoke the Pencil2 RTV4 lifecycle and native callback/buffer APIs")
    segment=ast.get_source_segment(source_text,cap) or ""
    ordered_calls=("p.call(PEN_RETURN_CALLBACK_CTOR,[callback,rt,0])",
                   "p.call(PEN_RETURN_CALLBACK_GET_BUFFER,[callback])",
                   "p.call(PEN_DRAWABLE_SET_BUFFER,[rt,vector,0])",
                   "p.call(PEN_DRAWABLE_SET_PEN_DATA,[rt,source_argb],[source_size])",
                   "p.call(RT_ADD,[rt,vec,row[\"int_arg_w2\"]],fs,instruction_limit=5_000_000)",
                   "p.call(PEN_DRAWABLE_SEND_DATA_TO_GPU,[rt,vector,0])",
                   "p.call(RT_UPDATE,[rt,0],instruction_limit=5_000_000)")
    positions=[segment.find(text) for text in ordered_calls]
    if any(pos<0 for pos in positions) or positions!=sorted(positions):
        raise RuntimeError(f"native callback/vector/add/publish/update order changed: {positions!r}")
    if "p.u.mem_write(rt+80" in segment or "p.u.mem_write(rt+88" in segment or "p.u.mem_write(rt+96" in segment or "p.u.mem_write(rt+44" in segment or "p.u.mem_write(rt+60" in segment:
        raise RuntimeError("capture must not write native RT vector or style fields directly")
    if not (segment.find('p.call(RT_INIT,[rt]')>=0 and
            segment.find('p.call(RT_INIT,[rt]')<segment.find('if len(p.cache_path_calls)!=1')):
        raise RuntimeError("cache-path pair assertion must follow the natural Pencil2 RT Init call")
    if "draw_target_fbo" not in {n.id for n in ast.walk(cap) if isinstance(n, ast.Name)} or "readback_framebuffer" not in segment:
        raise RuntimeError("readback must target the native SPSubBitmapRT framebuffer observed during Draw")
    if "glReadPixels" not in segment or "target_attachments" not in segment or "pre_raw" not in segment or "channel_changes" not in segment or "rgba8_target_rows" not in segment:
        raise RuntimeError("native target FBO, RGBA8 attachment, and pre/post per-channel evidence must gate readback")
    if "math.isfinite(source_size)" not in segment or "p.call(PEN_DRAWABLE_SET_PEN_DATA,[rt,source_argb],[source_size])" not in segment:
        raise RuntimeError("captured native Drawing SetPenData style must be finite and applied through the native setter")
    if "bitmap_name,0,1,6,2" not in segment:
        raise RuntimeError("native SPSubBitmapRT constructor must receive the source-proven render-target flag and (6,2) color layout pair")
    for required in ("target_activation[\"arg_bool\"]!=0","event[\"args\"][0]==0x8d40",
                     "row[1]==0x8ce0","row[3] in p.texture_ids","if not draw_calls:",
                     "\"glDrawElements\"","draw_calls[0].get(\"args\")!=[5,0,4,DRAWPOINT_FULL_STREAM_ROWS]"):
        if required not in segment:
            raise RuntimeError(f"strict native draw-target validation missing: {required}")
    for required in ('self.callbacks["strncmp"] = self.strncmp_guest',
                     'if limit>65536:', 'self.u.mem_read(left+i,1)',
                     'module_path.parent!=HELPERS.resolve()',
                     'sha(module_path)!=SOURCE_PINS[filename]',
                     '"runtime_helpers":p.helper_receipt'):
        if required not in segment:
            raise RuntimeError(f"native host-bridge/helper provenance guard missing: {required}")
    for required in ('self.callbacks["strtof"] = self.strtof_guest',
                     'host_strtof.restype=C.c_float',
                     'host_strtof.argtypes=[C.c_void_p,C.POINTER(C.c_void_p)]',
                     'self.f(0,value)', 'EXPECTED_STRTOF_LR_RENDERER_RVA',
                     '"strtof_calls":p.strtof_calls'):
        if required not in segment:
            raise RuntimeError(f"strtof ABI/source guard missing: {required}")
    for required in ('self.callbacks["strstr"] = self.strstr_guest',
                     'self.gl_strings_by_pointer[ptr]',
                     'GL_EXTENSIONS_MAX_BYTES', 'GL_EXTENSIONS_ENUM',
                     'expected+b"\\0"', 'EXPECTED_EXTENSIONS_STRTSTR_LR_RENDERER_RVA',
                     '"strstr_calls":p.strstr_calls'):
        if required not in segment:
            raise RuntimeError(f"GL_EXTENSIONS strstr provenance/bounds guard missing: {required}")
    for required in ('self.callbacks["crc32"] = self.crc32_guest',
                     'length>CRC32_MAX_BYTES', 'self.u.mem_read(pointer,length)',
                     'zlib.crc32(raw,seed&0xffffffff)', 'if pointer==0 and length==0',
                     'EXPECTED_CRC32_SECOND_LR_RENDERER_RVA',
                     'EXPECTED_CRC32_DIRECT_CALLS',
                     '"crc32_calls":p.crc32_calls'):
        if required not in segment:
            raise RuntimeError(f"CRC32 input/API/provenance guard missing: {required}")
    for required in ('self.callbacks["vsnprintf"] = self.vsnprintf_guest',
                     'EXPECTED_VSNPRINTF_LR_RENDERER_RVA', 'EXPECTED_VSNPRINTF_BL_RENDERER_RVA',
                     'EXPECTED_GETFILENAME_TO_FORMATTER_BL_RENDERER_RVA', 'EXPECTED_VSNPRINTF_PLT_RENDERER_RVA',
                     'EXPECTED_FORMAT_ADR_RENDERER_RVA', 'EXPECTED_FORMAT_HELPER_ENTRY_RENDERER_RVA',
                     'EXPECTED_GETFILENAME_RETURN_RENDERER_RVA', 'EXPECTED_VSNPRINTF_FORMAT_RVA',
                     'EXPECTED_VSNPRINTF_FORMAT', 'decode_aarch64_gp_u64',
                     'render_shader_cache_filename', 'self.pending_format_helper',
                     'self.vsnprintf_calls.append(row)', 'self.crc32_calls[-1]["result_u32"]'):
        if required not in source.read_text():
            raise RuntimeError(f"source-scoped AArch64 vsnprintf guard missing: {required}")
    for required in ('self.map_libcpp()', 'self.load_libcpp_relocs()',
                     'LIBCPP_SHA256', 'LIBCPP_ASSIGN_CSTR',
                     'EXPECTED_CACHE_PATH_ASSIGN_LR_RENDERER_RVA',
                     'EXPECTED_CACHE_PATH_GETTER_LR_RENDERER_RVA',
                     'SYSTEM_GET_CACHE_PATH', 'self.pending_libcpp_assign',
                     'self.cache_path_calls', 'elfplt.resolve(path)',
                     'raw_plt.get(0x132cf8)!="strlen"',
                     'EXPECTED_LIBCPP_ASSIGN_STRLEN_LR_RVA',
                     'self.callbacks["strlen"] = self.libcpp_strlen_guest',
                     'self.u.hook_add(UC_HOOK_MEM_INVALID,self.mem_invalid)',
                     'self.libcpp_strlen_calls.append(row)',
                     'self.invalid_memory_events.append',
                     '"strlen_calls":p.libcpp_strlen_calls',
                     '"invalid_memory_events":p.invalid_memory_events',
                     '"native_libcpp":{**p.libcpp_receipt'):
        if required not in segment:
            raise RuntimeError(f"native libc++ mapping/provenance guard missing: {required}")
    if 'if native_symbol in self.callbacks:' not in segment or 'self.callbacks.pop(SYSTEM_GET_CACHE_PATH' in segment or 'self.callbacks.pop(LIBCPP_ASSIGN_CSTR' in segment:
        raise RuntimeError("cache-path getter and libc++ assign must execute through pinned native symbols, not callbacks")
    if '"pending_string_assign":getattr(p,"pending_libcpp_assign",None)' not in source.read_text():
        raise RuntimeError("failure receipt must retain in-flight native string-assignment arguments")
    for required in ('self.callbacks["access"] = self.virtual_access',
                     'self.callbacks["mkdir"] = self.virtual_mkdir',
                     'self.callbacks["__errno"] = self.virtual_errno_address',
                     'VIRTUAL_FS_PREFIX = "/virtual/pencil2-renderer-cache"',
                     'SDK_CACHE_CONFIG_PATH = VIRTUAL_FS_PREFIX + "/sdk-path"',
                     'EXPECTED_SHADER_CACHE_DIR = VIRTUAL_FS_PREFIX + "/RendererCache"',
                     'EXPECTED_CACHE_ACCESS_LR_RENDERER_RVA', 'EXPECTED_CACHE_MKDIR_LR_BASE_RVA',
                     'EXPECTED_CACHE_PARENT_ACCESS_LR_BASE_RVA',
                     'BASE_DSO_BASE = 0x02000000', 'BASE_DSO_MAPPING_SIZE = 0x200000',
                     'BASE_FILE_ACCESS_RVA = 0x96768', 'BASE_DIRECTORY_MKDIR_RVA = 0x945ac  # symbol start; mkdir@plt at +0x1c returns at +0x20',
                     'self.syms["SPen::File::IsAccessible(char const*, int)"]-BASE_FILE_ACCESS_RVA',
                     'self.syms["SPen::Directory::MakeDirectory(char const*)"]-BASE_DIRECTORY_MKDIR_RVA',
                     'path in self.virtual_dirs or path in self.virtual_files',
                     'parent in self.virtual_dirs', 'self._set_virtual_errno(2)',
                     'self.virtual_dirs.add(path)', 'self.cache_path_calls[0]',
                     'path.startswith(EXPECTED_SHADER_CACHE_DIR+"/")',
                     'if name=="SPen::File::IsAccessible(char const*, int)"',
                     'if name=="SPen::Directory::MakeDirectory(char const*)"',
                     'self.filesystem_native_calls.append(row)',
                     'self.filesystem_native_calls = []',
                     'self.callbacks["strchr"] = self.strchr_guest',
                     'BASE_FILE_MODE_STRCHR_LR_RVAS', 'RENDERER_READ_MODE_RVA', 'RENDERER_WRITE_MODE_RVA',
                     'def strchr_guest(self):', 'guest_strchr_result', 'self.strchr_calls.append(row)',
                     '"virtual_fs_events":getattr(p,"virtual_fs_events",[])'):
        if required not in source.read_text():
            raise RuntimeError(f"bounded virtual shader-cache filesystem guard missing: {required}")
    for required in ('self.callbacks["__strlen_chk"] = self.strlen_chk_guest',
                     'self.callbacks["__strncpy_chk2"] = self.strncpy_chk2_guest',
                     'EXPECTED_STRLEN_CHK_LR_RENDERER_RVAS',
                     'EXPECTED_STRNCPY_CHK2_LR_RENDERER_RVAS',
                     'self.active_uniform_outputs', 'self.strlen_chk_calls',
                     'self.strncpy_chk2_calls', 'active_uniform_name_case',
                     'STRLEN_CHK_BOUND', 'STRNCPY_CHK2_DEST_SIZE',
                     'STRNCPY_CHK2_SOURCE_SIZE', 'row["guest_bytes_hex"]',
                     'row["active_uniform_output"]'):
        if required not in source.read_text():
            raise RuntimeError(f"source-pinned fortified active-uniform string bridge missing: {required}")
    for required in ('self.callbacks["strcmp"] = self.strcmp_guest',
                     'STRCMP_CALLSITE_LR_RENDERER_RVA', 'STRCMP_CALLSITE_BL_RENDERER_RVA',
                     'STRCMP_PLT_RENDERER_RVA', 'GET_BINDING_INTF_SYMBOL',
                     'GET_BINDING_INTF_RVA', 'self.binding_name_inputs', 'self.active_uniform_outputs',
                     'self.strncpy_chk2_calls', 'guest_strcmp_bytes',
                     'row["mesa_uniform_join"]', 'row["request_name_input"]'):
        if required not in source.read_text():
            raise RuntimeError(f"source-pinned active-uniform strcmp bridge missing: {required}")
    for required in ('def install_typed_queue_adapter(self):',
                     'name=="_ZTIN4SPen11IGLMsgQueueE"',
                     'if len(ti)!=1 or ti[0]!=renderer+0x6b3f0:',
                     'self.queue_task_vtables', 'self.queue_setup_tasks', 'queue_dso_mappings',
                     'self.u.mem_regions()', 'resolve_mapped_dso_base',
                     'native WorkerTask virtual entry +16', 'native_Run_executed_by_setup_queue',
                     'self.queue_code_hook',
                     'self.callbacks["operator new(unsigned long)"] = self.native_operator_new',
                     'p.call("SPen::PenGLDataManager::SetMsgQueue(SPen::IGLMsgQueue*)",[manager_gl,p.setup_queue])',
                     'native_current_queue_before_RT_init',
                     'p.call("SPen::SPSubBitmapRT::SPSubBitmapRT',
                     'pending_draw_tasks',
                     '[subbitmap,p.setup_queue,0,rect,width,height,bitmap_name,0,1,6,2]',
                     'queue_adapter_boundary', 'queue_setup_tasks', 'queue_retained_tasks',
                     'queue_get_calls', 'queue_registration_calls', '"queue_adapter":', 'native_allocations[-64:]'):
        if required not in source.read_text():
            raise RuntimeError(f"source-pinned native IGLMsgQueue adapter guard missing: {required}")
    if "chinesebrush-paint-scale-work/conformance" in segment:
        raise RuntimeError("runtime import path must not shadow the pinned helper directory")
    fountain_layout=(HELPERS/"fountain_native.py").read_text()
    texture_layout=(HELPERS/"airbrush_texture_native.py").read_text()
    if "names = ('FountainPen', 'PenCommon', 'Base', *additional_libraries)" not in fountain_layout or "base = index * 0x1000000" not in fountain_layout:
        raise RuntimeError("pinned initial-library loader source no longer proves PenCommon's base index")
    if "self.map_extra('Graphics', 4)" not in texture_layout or "self.map_extra('Renderer', 5)" not in texture_layout:
        raise RuntimeError("pinned texture helper no longer proves Graphics/Renderer extra mapping indices")
    if "resolve_mapped_dso_base" not in source.read_text() or "self.u.mem_regions()" not in source.read_text():
        raise RuntimeError("queue DSO bases must join pinned symbol RVAs to actual mapped memory regions")
    if "parse_nm_defined_rows(output)" not in source.read_text() or "nm_parser_fixture_tests()" not in source.read_text():
        raise RuntimeError("native symbol reader must ignore undefined nm imports and pass defined-row fixtures")
    classes={n.name:n for n in ast.walk(tree) if isinstance(n,ast.ClassDef)}
    mesa=classes.get("MesaPencil2")
    mesa_init=next((n for n in ast.walk(mesa) if isinstance(n,ast.FunctionDef) and n.name=="__init__"),None) if mesa else None
    aligned_method=next((n for n in ast.walk(mesa) if isinstance(n,ast.FunctionDef) and n.name=="posix_memalign_guest"),None) if mesa else None
    aligned_source=ast.get_source_segment(source_text,aligned_method) if aligned_method else ""
    init_source=ast.get_source_segment(source_text,mesa_init) if mesa_init else ""
    if (mesa_init is None or aligned_method is None or 'self.callbacks["posix_memalign"] = self.posix_memalign_guest' not in init_source or
        'call_rva=caller_rva-4' not in aligned_source or
        'LIBCPP_POSIX_MEMALIGN_CALLS.get(call_rva)' not in aligned_source or
        'aligned_guest_layout(self.heap,size,alignment)' not in aligned_source or
        'self.u.mem_write(output,struct.pack("<Q",aligned))' not in aligned_source or
        'self.posix_memalign_calls.append(row)' not in aligned_source or
        'host_libc' in aligned_source or 'C.CDLL' in aligned_source):
        raise RuntimeError("posix_memalign bridge must be source-site-gated, ABI-aligned in guest memory, and recorded without host-pointer substitution")
    free_method=next((n for n in ast.walk(mesa) if isinstance(n,ast.FunctionDef) and n.name=="free_guest"),None) if mesa else None
    free_source=ast.get_source_segment(source_text,free_method) if free_method else ""
    if (free_method is None or 'self.callbacks["free"] = self.free_guest' not in init_source or
        'self.native_aligned_allocations' not in free_source or 'allocation.get("freed",False)' not in free_source or
        'bump heap remains mapped' not in free_source or 'host_libc' in free_source or 'C.CDLL' in free_source):
        raise RuntimeError("aligned allocation free path must be limited to tracked live guest pointers and must retain lifecycle evidence")
    if "posix_memalign_calls" not in source_text or "native_aligned_allocations" not in source_text:
        raise RuntimeError("aligned guest allocation ABI/input/output receipts must be retained")
    setter_calls=[n for n in calls if isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name)
                  and n.func.value.id=="p" and n.func.attr=="call" and n.args
                  and isinstance(n.args[0],ast.Constant)
                  and n.args[0].value=="SPen::PenGLDataManager::SetMsgQueue(SPen::IGLMsgQueue*)"]
    if len(setter_calls)!=1:
        raise RuntimeError(f"native PenGLDataManager queue identity must be assigned exactly once, found {len(setter_calls)}")
    if "p.attach_native_renderthread_current_queue()" in segment or "RENDER_THREAD_FACTORY" in segment:
        raise RuntimeError("capture must not construct a RenderThreadGLImpl that loads unsupported Android system-property APIs")
    if "p.call(GET_CURRENT_MSG_QUEUE,[])" not in segment or "native_current_queue_before_RT_init" not in segment:
        raise RuntimeError("capture must record the real native current IGLMsgQueue before Pencil2 Init")
    if "self.callbacks[\"dlopen\"]" in segment or "self.callbacks[\"dlsym\"]" in segment:
        raise RuntimeError("candidate must not stub Android dynamic loader/property calls")
    if "native_managed_registrations" not in source.read_text():
        raise RuntimeError("actual ManagedObject::Register entry/return evidence must be retained")
    queue_hook=next((n for n in ast.walk(mesa) if isinstance(n,ast.FunctionDef) and n.name=="queue_code_hook"),None) if mesa else None
    queue_hook_segment=ast.get_source_segment(source.read_text(),queue_hook) if queue_hook else ""
    if "if address!=0x20001100:return" not in queue_hook_segment or 'self.queue_active_phase in ("pencil2_rt_init","subbitmap_native_constructor","subbitmap_framebuffer_create")' not in queue_hook_segment:
        raise RuntimeError("single host IGLMsgQueue PostTask trampoline must choose native Run only in bounded setup phases")
    if "p.call(\"SPen::PenGLDataManager::SetMsgQueue(SPen::IGLMsgQueue*)\",[manager_gl,p.queue])" in segment:
        raise RuntimeError("candidate must not replace the manager's nonnull native IGLMsgQueue")
    queue_method=next((n for n in ast.walk(mesa) if isinstance(n,ast.FunctionDef) and n.name=="install_typed_queue_adapter"),None) if mesa else None
    queue_method_source=ast.get_source_segment(source.read_text(),queue_method) if queue_method else ""
    if not queue_method_source or queue_method_source.index("def rows(")>queue_method_source.index("def dso_base("):
        raise RuntimeError("native symbol reader must be defined before symbol-derived DSO base resolution")
    init=next((n for n in mesa.body if isinstance(n,ast.FunctionDef) and n.name=="__init__"),None) if mesa else None
    if init is None:raise RuntimeError("MesaPencil2 mapping initializer missing")
    init_calls=[n for n in ast.walk(init) if isinstance(n,ast.Call)]
    init_assignments={}
    for node in ast.walk(init):
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Attribute) and isinstance(target.value,ast.Name) and target.value.id=="self":
                    init_assignments[target.attr]=min(init_assignments.get(target.attr,node.lineno),node.lineno)
    install_gl=next((n.lineno for n in init_calls if isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=="self" and n.func.attr=="_install_gl"),None)
    required_vfs_state={"virtual_errno","errno_ptr","virtual_files","virtual_file_events","virtual_dirs","virtual_fs_events","filesystem_native_calls",
                        "active_uniform_outputs","strlen_chk_calls","strncpy_chk2_calls","binding_name_inputs","strcmp_calls"}
    missing_vfs=sorted(name for name in required_vfs_state if name not in init_assignments or install_gl is None or init_assignments[name]>=install_gl)
    if missing_vfs:raise RuntimeError(f"VFS callback state must be initialized in MesaPencil2.__init__ before hook-capable GL setup: {missing_vfs}")
    map_p2=next((n for n in init_calls if isinstance(n.func,ast.Attribute) and n.func.attr=="map_extra" and len(n.args)==2 and isinstance(n.args[0],ast.Constant) and n.args[0].value=="Pencil2" and isinstance(n.args[1],ast.Constant) and n.args[1].value==6),None)
    map_cpp=next((n for n in init_calls if isinstance(n.func,ast.Attribute) and n.func.attr=="map_libcpp"),None)
    relocs=next((n for n in init_calls if isinstance(n.func,ast.Attribute) and n.func.attr=="load_extra_relocs"),None)
    cpp_relocs=next((n for n in init_calls if isinstance(n.func,ast.Attribute) and n.func.attr=="load_libcpp_relocs"),None)
    if map_p2 is None or map_cpp is None or relocs is None or cpp_relocs is None or not (map_p2.lineno<map_cpp.lineno<relocs.lineno<cpp_relocs.lineno):
        raise RuntimeError("Pencil2 and pinned libc++ must be mapped before DSO relocations, then libc++ relocations applied")
    if any(isinstance(n,ast.Compare) and any(isinstance(c,ast.Call) and isinstance(c.func,ast.Attribute) and c.func.attr=="call" for c in ast.walk(n)) for n in ast.walk(cap)):
        raise RuntimeError("NativeFountain.call has no return value; inspect x0 after calling GetInstance")
    constructor_calls=[n for n in ast.walk(cap) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="_invoke" and n.args and isinstance(n.args[0],ast.Constant) and "SPSubBitmapRT::SPSubBitmapRT" in str(n.args[0].value)]
    if len(constructor_calls)!=1 or not isinstance(constructor_calls[0].args[1],ast.List) or len(constructor_calls[0].args[1].elts)!=11:
        raise RuntimeError("SPSubBitmapRT constructor must pass this plus all ten native arguments")
    subbitmap_args=constructor_calls[0].args[1].elts
    if not (isinstance(subbitmap_args[8],ast.Constant) and subbitmap_args[8].value==1):
        raise RuntimeError("SPSubBitmapRT host target must set the source-mapped render-target descriptor flag")
    cap_func=next((n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="capture"),None)
    cap_segment=ast.get_source_segment(source.read_text(),cap_func) if cap_func else ""
    lifecycle_calls=[n for n in ast.walk(cap_func) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="call" and n.args and isinstance(n.args[0],ast.Name) and n.args[0].id=="CREATE_SUBBITMAP_FRAMEBUFFER"] if cap_func else []
    activation_calls=[n for n in ast.walk(cap_func) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="call" and n.args and isinstance(n.args[0],ast.Name) and n.args[0].id=="ACTIVATE_SUBBITMAP_RT"] if cap_func else []
    if len(lifecycle_calls)!=1 or len(activation_calls)<1 or lifecycle_calls[0].lineno>=activation_calls[0].lineno:
        raise RuntimeError("candidate must call the native exported CreateFrameBuffer lifecycle before activating the target")
    if "descriptor_render_target_byte_24" not in cap_segment or "native_framebuffer_offscreen_target" not in cap_segment:
        raise RuntimeError("candidate must record the real descriptor byte and native +88 offscreen target result")
    hook_source=source.read_text()
    if ("finish_native_framebuffer_call_observation(p,subbitmap,FRAMEBUFFER_CALL_STOP)" not in cap_segment or
        "pc!=expected_stop_pc or lr!=expected_stop_pc" not in hook_source or
        "int(pending.get(\"receiver\",\"0\"),16)!=receiver" not in hook_source or
        "probe.get(receiver+80,\"Q\")" not in hook_source or "probe.get(receiver+88,\"Q\")" not in hook_source):
        raise RuntimeError("native framebuffer lifecycle result must be read only after verified NativeFountain.call stop and unchanged target receiver")
    if ("address==self.return_tramp" not in hook_source or "pop_texture_oracle_observer_return(self.pending_texture_oracle_returns,helper_pending_return)" not in hook_source or
        "int(row[\"caller_lr\"],16)!=helper_pending_return" not in hook_source or
        'if name==texture.CREATE_BITMAP:' not in hook_source or
        'if row["kind"]=="CreateBitmap":' not in hook_source or
        'elif row["kind"]=="CreateTextureObject":' not in hook_source or
        "self.last_texture_rt_call_index=row[\"index\"]" not in hook_source or
        "is_requested_target_receiver" not in cap_segment or "receiver_rect_xyxy" not in cap_segment):
        raise RuntimeError("TextureOracle return observation must dispatch both helper-managed native factory types and preserve exact target receiver/Rect evidence")
    texture_helper_text=(HELPERS/"airbrush_texture_native.py").read_text()
    if not all(fragment in texture_helper_text for fragment in ("self.callbacks.pop(CREATE_TEXTURE, None)","self.callbacks.pop(CREATE_BITMAP, None)","self.pending_returns.append(u.reg_read(R.UC_ARM64_REG_LR))","u.reg_write(R.UC_ARM64_REG_LR, self.return_tramp)","u.reg_write(R.UC_ARM64_REG_PC, self.syms[CREATE_TEXTURE_IMPL])","self.plt[address] == CREATE_BITMAP","if address == self.return_tramp:")):
        raise RuntimeError("pinned TextureOracle CreateTextureObject bridge no longer has the audited native-return trampoline contract")
    if 'name=="SPen::RendererFactory::CreateTextureObject(SPen::TextureDescriptor const&, char const*, void const*, unsigned int const*, unsigned int, SPen::TextureBufferInfo const*)"' not in source.read_text():
        raise RuntimeError("candidate must observe native CreateTextureObject arguments at the source-pinned RT constructor callsite")
    if 'channel_changes["changed_channel_bytes"][3]<=0' not in cap_segment or 'channel_changes["post_nonzero"][3]<=0' not in cap_segment:
        raise RuntimeError("candidate must require actual Mesa alpha delta and nonzero alpha after the captured shader discards row zero")
    if "p.put(subbitmap+80" in cap_segment or "p.put(subbitmap+88" in cap_segment:
        raise RuntimeError("candidate must never directly rewrite native texture/framebuffer fields")
    fake_unwind_callbacks=[]
    for node in ast.walk(tree):
        if not isinstance(node,ast.Assign):continue
        for target in node.targets:
            if (isinstance(target,ast.Subscript) and isinstance(target.value,ast.Attribute) and
                isinstance(target.value.value,ast.Name) and target.value.value.id=="self" and
                target.value.attr=="callbacks" and isinstance(target.slice,ast.Constant) and
                target.slice.value in ("dl_iterate_phdr","__cxa_throw")):
                fake_unwind_callbacks.append(target.slice.value)
    if fake_unwind_callbacks:
        raise RuntimeError("candidate must preserve native exception/unwind behavior and must not fake loader enumeration")
    invoke=next((n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="_invoke"),None)
    invoke_segment=ast.get_source_segment(source.read_text(),invoke) if invoke else ""
    if not invoke_segment or "args[8:]" not in invoke_segment or 'self.put(sp+8*index,"Q",value)' not in invoke_segment:
        raise RuntimeError("native AArch64 constructor wrapper must place every argument beyond x0-x7 on the guest stack")
    if 'p.call("SPen::ShaderManager::GetInstance()",[])' not in segment or 'if p.x(0)!=manager:' not in segment:
        raise RuntimeError("GetInstance result must be checked from native x0; NativeFountain.call returns None")
    if any("TextureOracle.create_graphics" in (n.func.attr if isinstance(n.func, ast.Attribute) else "") for n in calls):
        raise RuntimeError("synthetic TextureOracle graphics object is forbidden")
    pins = {}
    for name, expected in DSO_PINS.items():
        actual = sha(LIB / name)
        if actual != expected:
            raise RuntimeError(f"DSO pin mismatch {name}: {actual}")
        pins[name] = actual
    symbol_receipt={}
    for name,required in REQUIRED_DYNSYMS.items():
        actual_names=defined_dynsyms(LIB/name)
        missing=sorted(required-actual_names)
        if missing:raise RuntimeError(f"required native export missing in {name}: {missing}")
        symbol_receipt[name]=sorted(required)
    renderer_values=defined_dynsym_values(LIB/"libSPenRenderer.so")
    expected_renderer_rvas={
        "_ZN4SPen18GetCurrentMsgQueueEv":GET_CURRENT_MSG_QUEUE_RVA,
        "_ZN4SPen13ManagedObject8RegisterEv":MANAGED_OBJECT_REGISTER_RVA,
    }
    for symbol,expected_rva in expected_renderer_rvas.items():
        actual=renderer_values.get(symbol,[])
        if actual!=[expected_rva]:
            raise RuntimeError(f"pinned Renderer symbol RVA mismatch for {symbol}: {actual!r}, expected {expected_rva:#x}")
    base_dso=LIB/"libSPenBase.so"
    if elf_vaddr_bytes(base_dso,0x32716,8)!=b"libc.so\0":
        raise RuntimeError("pinned Base System::GetAndroidSystemProperty dlopen module string changed")
    if elf_vaddr_bytes(base_dso,0x2dbbf,len(b"__system_property_get\0"))!=b"__system_property_get\0":
        raise RuntimeError("pinned Base System::GetAndroidSystemProperty dlsym name changed")
    dlopen_call=struct.unpack("<I",elf_vaddr_bytes(base_dso,0xc762c,4))[0]
    dlsym_call=struct.unpack("<I",elf_vaddr_bytes(base_dso,0xc7640,4))[0]
    dlclose_call=struct.unpack("<I",elf_vaddr_bytes(base_dso,0xc764c,4))[0]
    if (decode_aarch64_bl_target(0xc762c,dlopen_call)!=0xe6f20 or
        decode_aarch64_bl_target(0xc7640,dlsym_call)!=0xe6f40 or
        decode_aarch64_bl_target(0xc764c,dlclose_call)!=0xe6f50 or
        struct.unpack("<I",elf_vaddr_bytes(base_dso,0xc7628,4))[0]!=0x52800021):
        raise RuntimeError("pinned Base Android property dlopen/dlsym/dlclose call sequence or RTLD_LAZY argument changed")
    managed_tls_call=struct.unpack("<I",elf_vaddr_bytes(LIB/"libSPenRenderer.so",0x45570,4))[0]
    managed_tls_load=struct.unpack("<I",elf_vaddr_bytes(LIB/"libSPenRenderer.so",0x45574,4))[0]
    managed_tls_null_branch=struct.unpack("<I",elf_vaddr_bytes(LIB/"libSPenRenderer.so",0x45578,4))[0]
    if (decode_aarch64_bl_target(0x45570,managed_tls_call)!=0x65ae0 or
        managed_tls_load!=0xf9400000 or managed_tls_null_branch!=0xb4000340):
        raise RuntimeError("ManagedObject::Register no longer uses native emutls and returns on a null current queue")
    for library in ("libSPenPenCommon.so","libSPenGraphics.so"):
        task_vtables=[name for name in defined_dynsyms(LIB/library) if name.startswith("_ZTVN4SPen10WorkerTask")]
        if not task_vtables:
            raise RuntimeError(f"pinned {library} has no exported native WorkerTask vtables for the queue adapter")
    base_imports=undefined_dynsyms(LIB/"libSPenBase.so")
    if not {"access","mkdir","__errno","strchr"}.issubset(base_imports):
        raise RuntimeError("pinned Base DSO lacks expected cache access/mkdir/errno/strchr imports")
    if BASE_DIRECTORY_MKDIR_RVA!=0x945ac or EXPECTED_CACHE_MKDIR_LR_BASE_RVA!=BASE_DIRECTORY_MKDIR_RVA+0x20:
        raise RuntimeError("native Base MakeDirectory(char const*) mkdir@plt return-address pins changed")
    fountain_source=(HELPERS/"fountain_native.py").read_text()
    if "names = ('FountainPen', 'PenCommon', 'Base', *additional_libraries)" not in fountain_source or "base = index * 0x1000000" not in fountain_source or "self.u.mem_map(base, 0x200000)" not in fountain_source:
        raise RuntimeError("pinned NativeFountain loader no longer proves Base DSO mapped at library index 2 with 0x200000-byte mapping")
    base_exports=defined_dynsyms(LIB/"libSPenBase.so")
    required_base_methods={"_ZN4SPen4File12IsAccessibleEPKci","_ZN4SPen9Directory13MakeDirectoryEPKc"}
    if not required_base_methods.issubset(base_exports):
        raise RuntimeError("pinned Base DSO lacks native File::IsAccessible/Directory::MakeDirectory")
    cpp_exports=defined_dynsyms(LIB/"libc++_shared.so")
    missing_cpp=sorted(REQUIRED_DYNSYMS["libc++_shared.so"]-cpp_exports)
    if missing_cpp:raise RuntimeError(f"pinned libc++ method export missing: {missing_cpp}")
    cpp=LIB/"libc++_shared.so"
    if "posix_memalign" not in undefined_dynsyms(cpp):
        raise RuntimeError("pinned libc++ does not import posix_memalign")
    posix_relocs=[row for row in elf_jump_slot_relocations(cpp) if row[2]=="posix_memalign"]
    if posix_relocs!=[(0x142178,0x402,"posix_memalign")]:
        raise RuntimeError(f"pinned libc++ posix_memalign JUMP_SLOT relocation changed: {posix_relocs!r}")
    free_relocs=[row for row in elf_jump_slot_relocations(cpp) if row[2]=="free"]
    if free_relocs!=[(0x142000,0x402,"free")]:
        raise RuntimeError(f"pinned libc++ free JUMP_SLOT relocation changed: {free_relocs!r}")
    if "aligned_alloc" in undefined_dynsyms(cpp):
        raise RuntimeError("pinned libc++ unexpectedly imports aligned_alloc; allocator closure must be re-audited")
    aligned_delete_words=struct.unpack("<II",elf_vaddr_bytes(cpp,0xba8f0,8))
    if (aligned_delete_words[0]!=0xd503245f or decode_aarch64_b_target(0xba8f4,aligned_delete_words[1])!=0x132830):
        raise RuntimeError("pinned aligned operator delete no longer branches to the audited libc++ free import trampoline")
    free_plt=struct.pack("<IIII",0x90000090,0xf9400211,0x91000210,0xd61f0220)
    if elf_vaddr_bytes(cpp,0x132830,len(free_plt))!=free_plt:
        raise RuntimeError("pinned libc++ aligned delete free trampoline changed")
    posix_plt=struct.pack("<IIII",0x90000090,0xf940be11,0x9105e210,0xd61f0220)
    if elf_vaddr_bytes(cpp,LIBCPP_POSIX_MEMALIGN_PLT_RVA,len(posix_plt))!=posix_plt:
        raise RuntimeError("pinned libc++ aligned allocator PLT entry no longer resolves the source-observed import slot")
    callsite_setups={
        0xa023c:(0xf100041f,0x52800201,0xf9000fbf,0x9a9f8413,0x910063a0,0xaa1303e2),
        0xba81c:(0xf100041f,0x52800108,0x9a9f8413,0xf100203f,0x9a888034,0xf90007ff,0x910023e0,0xaa1403e1,0xaa1303e2),
    }
    for call_rva,setup_words in callsite_setups.items():
        setup_start=call_rva-4*len(setup_words)
        raw=elf_vaddr_bytes(cpp,setup_start,4*(len(setup_words)+1))
        words=struct.unpack("<"+"I"*(len(setup_words)+1),raw)
        if (words[:-1]!=setup_words or decode_aarch64_bl_target(call_rva,words[-1])!=LIBCPP_POSIX_MEMALIGN_PLT_RVA or
            LIBCPP_POSIX_MEMALIGN_CALLS[call_rva]["return_rva"]!=call_rva+4):
            raise RuntimeError(f"pinned libc++ posix_memalign caller ABI/source setup changed at {call_rva:#x}: {words!r}")
    if len(callsite_setups)!=len(LIBCPP_POSIX_MEMALIGN_CALLS):
        raise RuntimeError("libc++ posix_memalign import callsite audit is incomplete")
    actual_posix_callers=elf_aarch64_bl_callers(cpp,LIBCPP_POSIX_MEMALIGN_PLT_RVA)
    if actual_posix_callers!=sorted(callsite_setups):
        raise RuntimeError(f"pinned libc++ posix_memalign executable BL closure changed: {actual_posix_callers!r}")
    required_renderer_imports={"strtof","strstr","crc32","vsnprintf","__strlen_chk","__strncpy_chk","__strncpy_chk2","strcmp"}
    missing_imports=sorted(required_renderer_imports-undefined_dynsyms(LIB/"libSPenRenderer.so"))
    if missing_imports:raise RuntimeError(f"Renderer string imports missing from pinned dynamic symbol table: {missing_imports}")
    if LIBCPP_ASSIGN_CSTR_MANGLED not in undefined_dynsyms(LIB/"libSPenRenderer.so"):
        raise RuntimeError("Renderer does not import the expected libc++ assign(const char*) method")
    for name, expected in SOURCE_PINS.items():
        actual = sha(HELPERS / name)
        if actual != expected:
            raise RuntimeError(f"helper pin mismatch {name}: {actual}")
        pins[name] = actual
    for path, expected, label in ((V37_SUCCESS, V37_SUCCESS_SHA256, "V37 controlled four-point native Mesa Draw receipt"),
                                  (V37_RETROSPECTIVE, V37_RETROSPECTIVE_SHA256, "V37 compact independent pipeline audit"),
                                  (V37_CANDIDATE, V37_CANDIDATE_SHA256, "V37 Mesa candidate"),
                                  (V37_MANIFEST, V37_MANIFEST_SHA256, "V37 handoff manifest"),
                                  (V36_FAILURE, V36_FAILURE_SHA256, "V36 native framebuffer stop-observer failure receipt"),
                                  (V36_CANDIDATE, V36_CANDIDATE_SHA256, "V36 Mesa candidate"),
                                  (V36_MANIFEST, V36_MANIFEST_SHA256, "V36 handoff manifest"),
                                  (V35_FAILURE, V35_FAILURE_SHA256, "V35 shared TextureOracle return-observer failure receipt"),
                                  (V35_CANDIDATE, V35_CANDIDATE_SHA256, "V35 Mesa candidate"),
                                  (V35_MANIFEST, V35_MANIFEST_SHA256, "V35 handoff manifest"),
                                  (V34_FAILURE, V34_FAILURE_SHA256, "V34 missing TextureOracle return-trampoline observer failure receipt"),
                                  (V34_CANDIDATE, V34_CANDIDATE_SHA256, "V34 Mesa candidate"),
                                  (V34_MANIFEST, V34_MANIFEST_SHA256, "V34 handoff manifest"),
                                  (V33_FAILURE, V33_FAILURE_SHA256, "V33 nested texture factory observer failure receipt"),
                                  (V33_CANDIDATE, V33_CANDIDATE_SHA256, "V33 Mesa candidate"),
                                  (V33_MANIFEST, V33_MANIFEST_SHA256, "V33 handoff manifest"),
                                  (V32_FAILURE, V32_FAILURE_SHA256, "V32 native null-framebuffer exception receipt"),
                                  (V32_CANDIDATE, V32_CANDIDATE_SHA256, "V32 Mesa candidate"),
                                  (V32_MANIFEST, V32_MANIFEST_SHA256, "V32 handoff manifest"),
                                  (V31_FAILURE, V31_FAILURE_SHA256, "V31 native null-framebuffer exception receipt"),
                                  (V31_CANDIDATE, V31_CANDIDATE_SHA256, "V31 Mesa candidate"),
                                  (V31_MANIFEST, V31_MANIFEST_SHA256, "V31 handoff manifest"),
                                  (V30_FAILURE, V30_FAILURE_SHA256, "V30 native posix_memalign failure receipt"),
                                  (V30_CANDIDATE, V30_CANDIDATE_SHA256, "V30 Mesa candidate"),
                                  (V30_MANIFEST, V30_MANIFEST_SHA256, "V30 handoff manifest"),
                                  (DRAWPOINT_RECEIPT, DRAWPOINT_RECEIPT_SHA256, "native Drawing full-SmPoint receipt"),
                                  (DRAWPOINT_CAPTURE_CANDIDATE, DRAWPOINT_CAPTURE_CANDIDATE_SHA256, "native Drawing full-SmPoint producer"),
                                  (DRAWPOINT_CAPTURE_MANIFEST, DRAWPOINT_CAPTURE_MANIFEST_SHA256, "native Drawing full-SmPoint manifest"),
                                  (TEXTURE_V3, TEXTURE_V3_SHA256, "Pencil2 texture receipt")):
        actual = sha(path)
        if actual != expected:
            raise RuntimeError(f"{label} pin mismatch: {actual}")
        pins[label] = actual
    pins["V29 full native Drawing draw_object_stroke 84-row stream"] = DRAWPOINT_FULL_STREAM_SHA256
    pins["V37 compact retrospective pipeline audit"] = V37_RETROSPECTIVE_SHA256
    actual_color_doc=sha(COLOR_LAYOUT_DOC)
    if actual_color_doc!=COLOR_LAYOUT_DOC_SHA256:
        raise RuntimeError(f"native RGBA target layout evidence pin mismatch: {actual_color_doc}")
    pins["native RGBA8 target layout documentation"] = actual_color_doc
    pins["PenDrawableRT::SetPenData source bytes"] = hashlib.sha256(PEN_COMMON_SET_PEN_DATA_BYTES).hexdigest()
    pins["Pencil2 RTV4::SetInverseScale source bytes"] = hashlib.sha256(PENCIL2_SET_INVERSE_SCALE_BYTES).hexdigest()
    pins["native Drawing full-SmPoint producer candidate"] = sha(DRAWPOINT_CAPTURE_CANDIDATE)
    pins["native Drawing full-SmPoint producer manifest"] = sha(DRAWPOINT_CAPTURE_MANIFEST)
    pins["V30 candidate"] = sha(V30_CANDIDATE)
    pins["V30 manifest"] = sha(V30_MANIFEST)
    pins["V30 native posix_memalign failure receipt"] = sha(V30_FAILURE)
    pins["V31 candidate"] = sha(V31_CANDIDATE)
    pins["V31 manifest"] = sha(V31_MANIFEST)
    pins["V31 native null-framebuffer exception receipt"] = sha(V31_FAILURE)
    pins["capture_candidate.py"] = sha(source)
    return {"status": "passed", "mode": "AST/hash/ELF-byte + pure Python fixture only; no native imports or execution", "pins": pins,"defined_export_symbols":symbol_receipt,"required_renderer_imports":sorted(required_renderer_imports),"fake_vsnprintf_tests":fake_test_receipt}


def capture(output: Path) -> dict:
    global LAST_PROBE, LAST_REGS
    import ctypes as C
    import os
    import subprocess
    import sys
    import zlib
    sys.path.insert(0, str(HELPERS))
    import airbrush_texture_native as texture
    import inkpen_paint_native as ip
    import elf_plt as elfplt
    host_libc=C.CDLL(None)
    host_strtof=getattr(host_libc,"strtof")
    host_strtof.restype=C.c_float
    host_strtof.argtypes=[C.c_void_p,C.POINTER(C.c_void_p)]
    helper_modules={
        "airbrush_texture_native.py":texture,
        "airbrush_saved_native.py":sys.modules.get("airbrush_saved_native"),
        "fountain_native.py":sys.modules.get("fountain_native"),
        "inkpen_paint_native.py":ip,
        "elf_plt.py":elfplt,
    }
    helper_receipt={}
    for filename,module in helper_modules.items():
        if module is None or not getattr(module,"__file__",None):
            raise RuntimeError(f"pinned runtime helper was not imported: {filename}")
        module_path=Path(module.__file__).resolve()
        if module_path.parent!=HELPERS.resolve() or sha(module_path)!=SOURCE_PINS[filename]:
            raise RuntimeError(f"runtime helper path/hash mismatch: {filename} {module_path}")
        helper_receipt[filename]={"path":str(module_path),"sha256":sha(module_path)}
    from unicorn import arm64_const as R
    from unicorn import UC_HOOK_MEM_INVALID
    LAST_REGS=R

    class MesaPencil2(texture.TextureOracle):
        def __init__(self):
            self.mesa = ip.GLES()
            super().__init__()
            self.base_dso_base=self.syms["SPen::File::IsAccessible(char const*, int)"]-BASE_FILE_ACCESS_RVA
            if self.base_dso_base!=BASE_DSO_BASE or self.syms["SPen::Directory::MakeDirectory(char const*)"]!=self.base_dso_base+BASE_DIRECTORY_MKDIR_RVA:
                raise RuntimeError("Base symbol addresses do not match the inherited NativeFountain mapping")
            self.base_dso_end=self.base_dso_base+BASE_DSO_MAPPING_SIZE
            self.virtual_errno = 0
            self.errno_ptr = self.alloc(4)
            self.put(self.errno_ptr, "i", 0)
            self.gl_events = []
            self.texture_ids = []
            self.buffer_ids = []
            self.shader_sources = []
            self.programs = []
            self.native_graphics_returns = []
            self.native_blend_returns = []
            self.native_calls = []
            self.sampler_ids = []
            self.renderbuffer_ids = []
            self.framebuffer_ids = []
            self.vertex_array_ids = []
            self.virtual_files = {}
            self.virtual_file_events = []
            # The configured SDK cache parent is an explicitly provisioned
            # in-memory directory; native RendererCache creation remains real.
            self.virtual_dirs = {"/virtual", VIRTUAL_FS_PREFIX}
            self.virtual_fs_events = []
            self.filesystem_native_calls = []
            self.strchr_calls = []
            self.rtv_entries = []
            self.uploads = []
            self.shader_compile = []
            self.fbo = 0
            self.fbo_texture = 0
            self.readback = None
            self.manager = 0
            self.queue = 0
            self.setup_queue = 0
            self.managed_queue = 0
            self.queue_typeinfo = 0
            self.queue_task_vtables = {}
            self.queue_task_sources = {}
            self.queue_setup_tasks = []
            self.queue_retained_tasks = []
            self.queue_get_calls = []
            self.queue_registration_calls = []
            self.queue_active_phase = "disabled"
            self.queue_return_stack = []
            self.native_thread_setup = {"attempted":False,"reason":"RenderThreadGLImpl construction depends on Base::GetAndroidSystemProperty dlopen(\"libc.so\", RTLD_LAZY) and dlsym(\"__system_property_get\"); this capture does not stub Android loader/property APIs"}
            self.native_managed_registrations = []
            self.pending_native_managed_registrations = []
            self.queue_trampolines = {}
            self.native_allocations = []
            self.native_aligned_allocations = []
            self.posix_memalign_calls = []
            self.native_free_calls = []
            self.rt = 0
            self.subbitmap = 0
            self.uniform_locations = {}
            self.target_activation_calls=[]
            self.current_target_activation=None
            self.texture_factory_calls=[]
            self.pending_texture_factory_callbacks=[]
            self.pending_texture_oracle_returns=[]
            self.bitmap_factory_calls=[]
            self.unclassified_texture_oracle_returns=[]
            self.texture_rt_calls=[]
            self.last_texture_rt_call_index=None
            self.framebuffer_create_calls=[]
            self.pending_framebuffer_create=None
            self.constructor_input=None
            self.pixel_diagnostic=None
            self.strncmp_calls=[]
            self.strtof_calls=[]
            self.strstr_calls=[]
            self.crc32_calls=[]
            self.vsnprintf_calls=[]
            self.pending_format_helper=None
            self.format_helper_calls=[]
            self.libcpp_assign_calls=[]
            self.pending_libcpp_assign=None
            self.cache_path_calls=[]
            self.pending_cache_path_getter=None
            self.libcpp_strlen_calls=[]
            self.active_uniform_outputs=[]
            self.strlen_chk_calls=[]
            self.strncpy_chk2_calls=[]
            self.binding_name_inputs=[]
            self.strcmp_calls=[]
            self.invalid_memory_events=[]
            self.gl_strings_by_pointer={}
            self.helper_receipt=helper_receipt
            self.callbacks["operator new(unsigned long)"] = self.native_operator_new
            self.callbacks["operator new[](unsigned long)"] = self.native_operator_new
            self.callbacks["operator new(unsigned long, std::nothrow_t const&)"] = self.native_operator_new
            self.callbacks["operator new[](unsigned long, std::nothrow_t const&)"] = self.native_operator_new
            self._install_gl()
            self.callbacks.pop(CREATE_GRAPHICS, None)
            self.callbacks.pop(CREATE_BLEND, None)
            # Let RendererFactory's real wrapper/lazy singleton own caps too.
            self.callbacks.pop("SPen::RendererFactory::GetRendererDeviceCaps()", None)
            self.callbacks.pop("SPen::PenGLDataManager::GetMsgQueue()", None)
            self.callbacks["__cxa_guard_acquire"] = self.guard_acquire
            self.callbacks["__cxa_guard_release"] = self.guard_release
            self.callbacks["__cxa_guard_abort"] = self.guard_abort
            for name in ("pthread_mutex_init","pthread_mutex_destroy","pthread_mutex_lock","pthread_mutex_unlock",
                         "pthread_mutexattr_init","pthread_mutexattr_destroy","pthread_mutexattr_settype",
                         "pthread_rwlock_rdlock","pthread_rwlock_wrlock","pthread_rwlock_unlock",
                         "pthread_cond_broadcast","pthread_cond_signal","pthread_cond_init","pthread_cond_destroy"):
                self.callbacks[name] = lambda: self.x(0,0)
            self.callbacks["eglGetCurrentContext"] = self.egl_current_context
            self.callbacks["eglGetCurrentDisplay"] = self.egl_current_display
            self.callbacks["strncmp"] = self.strncmp_guest
            self.callbacks["strtof"] = self.strtof_guest
            self.callbacks["strstr"] = self.strstr_guest
            self.callbacks["crc32"] = self.crc32_guest
            self.callbacks["vsnprintf"] = self.vsnprintf_guest
            self.callbacks["strlen"] = self.libcpp_strlen_guest
            self.callbacks["access"] = self.virtual_access
            self.callbacks["mkdir"] = self.virtual_mkdir
            self.callbacks["strchr"] = self.strchr_guest
            self.callbacks["__strlen_chk"] = self.strlen_chk_guest
            self.callbacks["__strncpy_chk2"] = self.strncpy_chk2_guest
            self.callbacks["strcmp"] = self.strcmp_guest
            self.callbacks["posix_memalign"] = self.posix_memalign_guest
            self.callbacks["free"] = self.free_guest
            self.callbacks["__errno"] = self.virtual_errno_address
            self.callbacks.update({"fopen":self.fopen,"fopen64":self.fopen,"fclose":self.fclose,
                                   "fread":self.fread,"fwrite":self.fwrite,"fseek":self.fseek,
                                   "fseek64":self.fseek,"ftell":self.ftell,"ftell64":self.ftell,
                                   "fflush":self.fflush,"ferror":lambda:self.x(0,0),
                                   "feof":lambda:self.x(0,0),"setbuf":lambda:None,
                                   "setvbuf":self.setvbuf,"fileno":self.fileno,"fsync":self.fsync,
                                   "fdatasync":self.fsync})

            # Pencil2 is an additional dependent DSO after the existing helper
            # layout: FountainPen=0, PenCommon=1, Base=2, Graphics=4,
            # Renderer=5, Pencil2=6. Load its own relocations before calling
            # any RTV4 symbol.
            self.map_extra("Pencil2",6)
            self.map_libcpp()
            self.load_extra_relocs()
            self.load_libcpp_relocs()
            self.u.hook_add(UC_HOOK_MEM_INVALID,self.mem_invalid)
            for native_symbol in (LIBCPP_ASSIGN_CSTR,SYSTEM_GET_CACHE_PATH):
                if native_symbol not in self.syms:
                    raise RuntimeError(f"required shipped native method is not mapped: {native_symbol}")
                if native_symbol in self.callbacks:
                    raise RuntimeError(f"required shipped native method was replaced by a callback: {native_symbol}")
            self.symbol_by_address={address:name for name,address in self.syms.items()}
            required=(RT_CTOR,RT_INIT,RT_ADD,RT_UPDATE,RT_DRAW,RT_SET_INVERSE_SCALE,ACTIVATE_SUBBITMAP_RT)
            missing=[name for name in required if name not in self.syms]
            if missing:raise RuntimeError(f"Pencil2/Graphics native target exports not mapped: {missing}")

        def map_libcpp(self):
            path=LIB/"libc++_shared.so"
            blob=path.read_bytes()
            actual=hashlib.sha256(blob).hexdigest()
            if actual!=LIBCPP_SHA256:
                raise RuntimeError(f"pinned libc++ DSO hash mismatch: {actual}")
            phoff=struct.unpack_from("<Q",blob,32)[0]
            phent,phnum=struct.unpack_from("<HH",blob,54)
            headers=[struct.unpack_from("<II6Q",blob,phoff+i*phent) for i in range(phnum)]
            extent=max((h[3]+h[6] for h in headers if h[0]==1),default=0)
            if not extent:raise RuntimeError("pinned libc++ has no loadable segments")
            self.u.mem_map(LIBCPP_BASE,(extent+0xfff)&~0xfff)
            for h in headers:
                if h[0]==1 and h[6]:
                    self.u.mem_write(LIBCPP_BASE+h[3],blob[h[2]:h[2]+h[5]])
                    if h[6]>h[5]:self.u.mem_write(LIBCPP_BASE+h[3]+h[5],bytes(h[6]-h[5]))
            env={**os.environ,"LD_LIBRARY_PATH":str(ROOT/"scratch/apk-analysis-runtime/binutils-aarch64/usr/lib/x86_64-linux-gnu")}
            nm=ROOT/"scratch/apk-analysis-runtime/binutils-aarch64/usr/bin/aarch64-linux-gnu-nm"
            obj=ROOT/"scratch/apk-analysis-runtime/binutils-aarch64/usr/bin/aarch64-linux-gnu-objdump"
            nmout=subprocess.run([str(nm),"-D","-C",str(path)],check=True,capture_output=True,text=True,env=env).stdout
            exports=[]
            for line in nmout.splitlines():
                fields=line.strip().split(" ",2)
                if len(fields)==3 and fields[1] in ("T","W","V","D","B","R"):
                    self.syms[fields[2]]=LIBCPP_BASE+int(fields[0],16)
                    if fields[2]==LIBCPP_ASSIGN_CSTR:exports.append(fields[2])
            if exports!=[LIBCPP_ASSIGN_CSTR]:
                raise RuntimeError(f"pinned libc++ assign(const char*) export missing/ambiguous: {exports!r}")
            if self.syms[LIBCPP_ASSIGN_CSTR]!=LIBCPP_BASE+0xd7100:
                raise RuntimeError(f"pinned libc++ assign(const char*) address mismatch: {self.syms[LIBCPP_ASSIGN_CSTR]:#x}")
            raw_plt=elfplt.resolve(path)
            if raw_plt.get(0x132cf8)!="strlen":
                raise RuntimeError(f"pinned libc++ PLT decode mismatch for the assign(char const*) strlen call: {raw_plt.get(0x132cf8)!r}")
            for address,raw_symbol in raw_plt.items():
                if raw_symbol.startswith("_Z"):
                    symbol=subprocess.run([str(ROOT/"scratch/apk-analysis-runtime/binutils-aarch64/usr/bin/aarch64-linux-gnu-c++filt"),"-n",raw_symbol],check=True,capture_output=True,text=True,env=env).stdout.strip()
                else:symbol=raw_symbol
                self.plt[LIBCPP_BASE+address]=symbol
            self.libcpp_blob=blob
            self.libcpp_receipt={"path":str(path),"sha256":actual,"base":hex(LIBCPP_BASE),
                                 "extent":hex(extent),"mapped_load_segments":sum(h[0]==1 for h in headers),
                                 "export":LIBCPP_ASSIGN_CSTR,
                                 "export_address":hex(self.syms[LIBCPP_ASSIGN_CSTR]),
                                 "source_dso":"libc++_shared.so",
                                 "plt_mapping":"pinned elf_plt byte decoder joins .rela.plt JUMP_SLOT targets to AArch64 PLT veneer PCs",
                                 "plt_instruction_entries":len(raw_plt),"assign_strlen_plt_rva":"0x132cf8",
                                 "assign_strlen_plt_symbol":raw_plt[0x132cf8]}

        def load_libcpp_relocs(self):
            blob=self.libcpp_blob
            shoff=struct.unpack_from("<Q",blob,40)[0]
            shent,shnum,shstrndx=struct.unpack_from("<HHH",blob,58)
            sections=[struct.unpack_from("<IIQQQQIIQQ",blob,shoff+i*shent) for i in range(shnum)]
            namesec=sections[shstrndx]
            names=blob[namesec[4]:namesec[4]+namesec[5]]
            by_name={names[s[0]:names.find(b"\0",s[0])].decode():s for s in sections}
            dynsym,dynstr=by_name[".dynsym"],by_name[".dynstr"]
            strings=blob[dynstr[4]:dynstr[4]+dynstr[5]]
            symbols=[]
            for off in range(dynsym[4],dynsym[4]+dynsym[5],dynsym[9]):
                no,_info,_other,shndx,value,_size=struct.unpack_from("<IBBHQQ",blob,off)
                end=strings.find(b"\0",no)
                symbols.append((strings[no:end].decode() if no else "",shndx,value))
            relocs=by_name.get(".rela.dyn")
            if relocs is None:raise RuntimeError("pinned libc++ lacks .rela.dyn")
            counts={"relative":0,"glob_dat":0,"abs64":0}
            for off in range(relocs[4],relocs[4]+relocs[5],relocs[9]):
                where,info,addend=struct.unpack_from("<QQq",blob,off)
                kind,index=info&0xffffffff,info>>32
                name,shndx,value=symbols[index]
                if kind==0x403:
                    target=LIBCPP_BASE+addend;counts["relative"]+=1
                elif kind==0x401:
                    target=LIBCPP_BASE+value if shndx else self.resolve_symbol(name)
                    counts["glob_dat"]+=1
                elif kind==0x101:
                    target=LIBCPP_BASE+value+addend if shndx else self.resolve_symbol(name)+addend
                    counts["abs64"]+=1
                else:
                    raise RuntimeError(f"unsupported pinned libc++ dynamic relocation type {kind:#x}")
                self.put(LIBCPP_BASE+where,"Q",target)
            expected={"relative":1587,"glob_dat":189,"abs64":2012}
            if counts!=expected:raise RuntimeError(f"pinned libc++ relocation census mismatch: {counts!r}")
            self.libcpp_receipt["rela_dyn_counts"]=counts

        def _cfunc(self, name, ret, args):
            return ip.cfunc(self.mesa.gl, name, ret, args)

        def strncmp_guest(self):
            left,right,limit=self.x(0),self.x(1),self.x(2)
            if limit>65536:raise RuntimeError(f"strncmp bound exceeds 65536 bytes: {limit}")
            left_bytes=bytearray();right_bytes=bytearray();result=0
            for i in range(limit):
                a=self.u.mem_read(left+i,1)[0]
                b=self.u.mem_read(right+i,1)[0]
                left_bytes.append(a);right_bytes.append(b)
                if a!=b:
                    result=a-b;break
                if a==0:break
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base if renderer_base<=lr<renderer_base+0x200000 else None
            caller_symbol=None;caller_rva=None
            if lr_rva is not None:
                candidates=[(address,name) for address,name in self.symbol_by_address.items()
                            if renderer_base<=address<=lr and address<renderer_base+0x200000]
                if candidates:
                    caller_address,caller_symbol=max(candidates)
                    caller_rva=hex(caller_address-renderer_base)
            row={"symbol":"strncmp","plt_pc":hex(self.u.reg_read(R.UC_ARM64_REG_PC)),
                 "lr":hex(lr),"left":hex(left),"right":hex(right),"limit":limit,
                 "left_compared_hex":bytes(left_bytes).hex(),"right_compared_hex":bytes(right_bytes).hex(),
                 "result":result,"abi":"int strncmp(const char*, const char*, size_t)",
                 "source_dso":"libSPenRenderer.so" if lr_rva is not None else None,
                 "lr_rva":hex(lr_rva) if lr_rva is not None else None,
                 "caller_symbol":caller_symbol,"caller_symbol_rva":caller_rva,
                 "caller_offset":hex(lr_rva-int(caller_rva,16)) if lr_rva is not None and caller_rva else None}
            self.strncmp_calls.append(row)
            self.x(0,result & 0xffffffff)

        def strtof_guest(self):
            source,endptr_guest=self.x(0),self.x(1)
            raw=bytearray()
            for i in range(65536):
                byte=self.u.mem_read(source+i,1)[0]
                if byte==0:break
                raw.append(byte)
            else:raise RuntimeError("strtof input lacks NUL within 65536 guest bytes")
            buf=C.create_string_buffer(bytes(raw)+b"\0")
            host_start=C.addressof(buf)
            host_end=C.c_void_p()
            value=float(host_strtof(C.cast(buf,C.c_void_p),C.byref(host_end)))
            if host_end.value is None:raise RuntimeError("host libc strtof returned a null end pointer")
            offset=int(host_end.value)-host_start
            if not 0<=offset<=len(raw):raise RuntimeError(f"host libc strtof end pointer outside copied guest string: {offset}/{len(raw)}")
            if endptr_guest:self.put(endptr_guest,"Q",source+offset)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base if renderer_base<=lr<renderer_base+0x200000 else None
            candidates=[(address,name) for address,name in self.symbol_by_address.items()
                        if renderer_base<=address<=lr and address<renderer_base+0x200000] if lr_rva is not None else []
            caller_address,caller_symbol=max(candidates) if candidates else (None,None)
            if lr_rva!=EXPECTED_STRTOF_LR_RENDERER_RVA or caller_symbol!="SPen::OpenGLRenderer::getSupportSampler()":
                raise RuntimeError(f"strtof called from unexpected Renderer source: lr={lr_rva!r} caller={caller_symbol!r}")
            bits=struct.pack("<f",value)
            row={"symbol":"strtof","abi":"float strtof(const char*, char**) -> S0",
                 "host_semantics":"host process libc strtof applied to a bounded NUL-terminated copy of the actual guest bytes",
                 "plt_pc":hex(self.u.reg_read(R.UC_ARM64_REG_PC)),"lr":hex(lr),"lr_rva":hex(lr_rva),
                 "caller_symbol":caller_symbol,"caller_symbol_rva":hex(caller_address-renderer_base),
                 "caller_offset":hex(lr_rva-(caller_address-renderer_base)),"guest_string":hex(source),
                 "guest_bytes_hex":bytes(raw).hex(),"guest_text":bytes(raw).decode(errors="replace"),
                 "endptr_guest":hex(endptr_guest) if endptr_guest else None,
                 "end_offset":offset,"endptr_value":hex(source+offset),"result_float32":value,
                 "result_s0_bits":bits.hex()}
            self.strtof_calls.append(row)
            self.f(0,value)

        def _read_guest_cstr(self,pointer,limit):
            if not pointer:raise RuntimeError("null pointer passed as C string")
            raw=bytearray()
            for i in range(limit):
                byte=self.u.mem_read(pointer+i,1)[0]
                if byte==0:return bytes(raw)
                raw.append(byte)
            raise RuntimeError(f"guest C string lacks NUL within API-specific {limit}-byte bound")

        def strstr_guest(self):
            hay_ptr,needle_ptr=self.x(0),self.x(1)
            known=self.gl_strings_by_pointer.get(hay_ptr)
            if known is not None:
                enum,expected=known
                cap=GL_EXTENSIONS_MAX_BYTES if enum==GL_EXTENSIONS_ENUM else 4096
                if len(expected)>cap:raise RuntimeError(f"glGetString enum {enum:#x} payload exceeds source-specific cap {cap}")
                guest=bytes(self.u.mem_read(hay_ptr,len(expected)+1))
                if guest!=expected+b"\0":raise RuntimeError("guest glGetString bytes/terminator differ from the actual Mesa response")
                haystack=expected
                source={"kind":"Mesa glGetString response","enum":enum,"payload_bytes":len(expected),"sha256":hashlib.sha256(expected).hexdigest()}
            else:
                haystack=self._read_guest_cstr(hay_ptr,4096)
                source={"kind":"guest C string","bound_bytes":4096}
            needle=self._read_guest_cstr(needle_ptr,4096)
            index=haystack.find(needle)
            result=hay_ptr+index if index>=0 else 0
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base if renderer_base<=lr<renderer_base+0x200000 else None
            candidates=[(address,name) for address,name in self.symbol_by_address.items()
                        if renderer_base<=address<=lr and address<renderer_base+0x200000] if lr_rva is not None else []
            caller_address,caller_symbol=max(candidates) if candidates else (None,None)
            if known is not None and known[0]==GL_EXTENSIONS_ENUM:
                if lr_rva!=EXPECTED_EXTENSIONS_STRTSTR_LR_RENDERER_RVA or caller_symbol!="IsGLExtensionSupported(char const*)":
                    raise RuntimeError(f"GL_EXTENSIONS strstr called from unexpected native source: {lr_rva!r} {caller_symbol!r}")
            row={"symbol":"strstr","abi":"char* strstr(const char*,const char*)",
                 "plt_pc":hex(self.u.reg_read(R.UC_ARM64_REG_PC)),"lr":hex(lr),
                 "lr_rva":hex(lr_rva) if lr_rva is not None else None,
                 "caller_symbol":caller_symbol,"caller_symbol_rva":hex(caller_address-renderer_base) if caller_address is not None else None,
                 "caller_offset":hex(lr_rva-(caller_address-renderer_base)) if lr_rva is not None and caller_address is not None else None,
                 "haystack":hex(hay_ptr),"needle":hex(needle_ptr),"haystack_source":source,
                 "haystack_bytes":len(haystack),"haystack_sha256":hashlib.sha256(haystack).hexdigest(),
                 "needle_bytes_hex":needle.hex(),"match_offset":index if index>=0 else None,
                 "result":hex(result) if result else None}
            self.strstr_calls.append(row)
            self.x(0,result)

        def crc32_guest(self):
            # zlib's AArch64 ABI is uLong crc32(uLong crc, Bytef const *buf,
            # uInt len): X0 seed, X1 guest byte pointer, X2 byte count, X0
            # zero-extended CRC result. The native shader cache hashes the
            # exact strlen-bounded shader strings; never synthesize a key.
            seed,pointer,length=self.x(0),self.x(1),self.x(2)
            if length>CRC32_MAX_BYTES:
                raise RuntimeError(f"crc32 length exceeds bounded capture limit: {length}")
            if pointer==0 and length!=0:
                raise RuntimeError(f"crc32 received null input with nonzero length: {length}")
            if pointer==0 and length==0:
                # zlib crc32(crc, Z_NULL, 0) resets/returns zero.
                raw=b""
                result=0
            else:
                raw=bytes(self.u.mem_read(pointer,length))
                result=zlib.crc32(raw,seed&0xffffffff)&0xffffffff
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base if renderer_base<=lr<renderer_base+0x200000 else None
            candidates=[(address,name) for address,name in self.symbol_by_address.items()
                        if renderer_base<=address<=lr and address<renderer_base+0x200000] if lr_rva is not None else []
            caller_address,caller_symbol=max(candidates) if candidates else (None,None)
            expected_symbol=EXPECTED_CRC32_DIRECT_CALLS.get(lr_rva)
            direct_match=expected_symbol is not None and caller_symbol==expected_symbol
            # GetShaderKey's second checksum is a tail branch with LR preserved
            # at the verified createShader call at RVA 0x5b8bc. Append's
            # checksum is likewise a tail branch; its caller must remain in
            # the shipped ShaderProgramCache implementation.
            tail_match=(lr_rva==EXPECTED_CRC32_SECOND_LR_RENDERER_RVA and
                        caller_symbol=="SPen::GLES::OpenGLShaderProgram::createShader()")
            append_tail=(caller_symbol is not None and
                         caller_symbol.startswith("SPen::ShaderProgramCache::") and
                         lr_rva not in EXPECTED_CRC32_DIRECT_CALLS)
            if not (direct_match or tail_match or append_tail):
                raise RuntimeError(f"crc32 called from unexpected Renderer source: lr_rva={lr_rva!r} caller={caller_symbol!r}")
            row={"symbol":"crc32","abi":"uLong crc32(uLong, Bytef const*, uInt) -> X0",
                 "implementation":"Python zlib.crc32 over the exact bounded bytes read from guest memory",
                 "source_dso":"libSPenRenderer.so","caller_symbol":caller_symbol,
                 "caller_symbol_rva":hex(caller_address-renderer_base) if caller_address is not None else None,
                 "caller_offset":hex(lr_rva-(caller_address-renderer_base)) if caller_address is not None else None,
                 "plt_pc":hex(self.u.reg_read(R.UC_ARM64_REG_PC)),"lr":hex(lr),"lr_rva":hex(lr_rva),
                 "seed_u32":seed&0xffffffff,"guest_buffer":hex(pointer) if pointer else None,
                 "length_bytes":length,"input_sha256":hashlib.sha256(raw).hexdigest(),
                 "input_prefix_hex":raw[:64].hex(),"input_suffix_hex":raw[-32:].hex(),
                 "null_zero_semantics":"result 0 for (buf=NULL,len=0); nonnull len=0 returns seed" if pointer==0 else None,
                 "result_u32":result,"result_x0":hex(result)}
            self.crc32_calls.append(row)
            self.x(0,result)

        def strchr_guest(self):
            pointer,character=self.x(0),self.x(1)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            base=self.base_dso_base
            expected=BASE_FILE_MODE_STRCHR_LR_RVAS.get(lr-base)
            if expected is None:
                raise RuntimeError(f"strchr called from unexpected Base source: {lr:#x}")
            if (character&0xff)!=expected:
                raise RuntimeError(f"File::Construct strchr byte differs from its native callsite: {character&0xff:#x} != {expected:#x}")
            renderer_base=self.extra_bases["Renderer"]
            allowed_pointers={renderer_base+RENDERER_READ_MODE_RVA,renderer_base+RENDERER_WRITE_MODE_RVA}
            if pointer not in allowed_pointers:
                raise RuntimeError(f"File::Construct mode pointer differs from pinned Renderer rb/wb literals: {pointer:#x}")
            raw=self._read_guest_cstr(pointer,STRCHR_MAX_INPUT_BYTES)
            if raw not in (b"rb",b"wb"):
                raise RuntimeError(f"File::Construct mode bytes differ from pinned rb/wb literals: {raw!r}")
            expected_mode_pointer=(renderer_base+RENDERER_READ_MODE_RVA if raw==b"rb" else renderer_base+RENDERER_WRITE_MODE_RVA)
            if pointer!=expected_mode_pointer:
                raise RuntimeError("File::Construct mode literal pointer does not match its actual bytes")
            result=guest_strchr_result(raw,character,pointer)
            row={"symbol":"strchr","abi":"char *strchr(const char*, int) -> X0; int converted to unsigned char",
                 "implementation":"bounded search over actual guest C-string bytes; NUL terminator is searchable",
                 "source_dso":"libSPenBase.so","caller":"SPen::File::Construct(SPen::String const*, char const*, bool)",
                 "lr":hex(lr),"base_lr_rva":hex(lr-base),"guest_pointer":hex(pointer),
                 "input_bytes_hex":raw.hex(),"input_text":raw.decode("ascii"),"input_bytes":len(raw),
                 "character_argument":character,"character_unsigned_byte":character&0xff,
                 "result":hex(result) if result else None,"result_offset":result-pointer if result else None}
            self.strchr_calls.append(row)
            self.x(0,result)

        def strlen_chk_guest(self):
            pointer,bound=self.x(0),self.x(1)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base
            if lr_rva not in EXPECTED_STRLEN_CHK_LR_RENDERER_RVAS or bound!=STRLEN_CHK_BOUND:
                raise RuntimeError(f"__strlen_chk outside pinned GetBindingIntf callsites/bound: LR={lr:#x}, bound={bound}")
            frame_pointer=self.u.reg_read(R.UC_ARM64_REG_X29)
            expected_pointer=frame_pointer-0x58
            if pointer!=expected_pointer:
                raise RuntimeError(f"__strlen_chk pointer differs from pinned x29-0x58 local: {pointer:#x} != {expected_pointer:#x}")
            output=next((row for row in reversed(self.active_uniform_outputs)
                         if row["guest_name_pointer"]==pointer),None)
            if output is None:
                raise RuntimeError("__strlen_chk input is not a recorded glGetActiveUniform name buffer")
            raw=bytes(self.u.mem_read(pointer,bound))
            length=checked_strlen_bytes(raw,bound)
            if length!=output["reported_length"] or raw[:ACTIVE_UNIFORM_BUFFER_SIZE]!=bytes.fromhex(output["buffer_bytes_hex"]):
                raise RuntimeError("__strlen_chk bytes/length differ from the joined Mesa active-uniform output")
            row={"symbol":"__strlen_chk","abi":"size_t __strlen_chk(const char*, size_t) -> X0",
                 "implementation":"bounded search of exact guest object; fail closed if NUL is absent before the object bound",
                 "source_dso":"libSPenRenderer.so","caller":"SPen::GLES::OpenGLShaderProgram::GetBindingIntf(char const*)",
                 "lr":hex(lr),"lr_rva":hex(lr_rva),"guest_pointer":hex(pointer),
                 "bound_bytes":bound,"guest_bytes_hex":raw.hex(),"length":length,
                 "active_uniform_output":output}
            self.strlen_chk_calls.append(row)
            self.x(0,length)

        def strncpy_chk2_guest(self):
            destination,source,count,destination_size,source_size=[self.x(i) for i in range(5)]
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base
            if lr_rva not in EXPECTED_STRNCPY_CHK2_LR_RENDERER_RVAS:
                raise RuntimeError(f"__strncpy_chk2 outside pinned GetBindingIntf callsites: LR={lr:#x}")
            sp=self.u.reg_read(R.UC_ARM64_REG_SP)
            fp=self.u.reg_read(R.UC_ARM64_REG_X29)
            if destination!=sp+0x60 or source!=fp-0x58:
                raise RuntimeError("__strncpy_chk2 pointers differ from the pinned destination/source locals")
            if destination_size!=STRNCPY_CHK2_DEST_SIZE or source_size!=STRNCPY_CHK2_SOURCE_SIZE:
                raise RuntimeError("__strncpy_chk2 object sizes differ from the pinned AArch64 callsite")
            prior_strlen=next((row for row in reversed(self.strlen_chk_calls)
                               if row["guest_pointer"]==hex(source)),None)
            if prior_strlen is None or count>prior_strlen["length"]:
                raise RuntimeError("__strncpy_chk2 count exceeds the preceding checked active-uniform string length")
            if lr_rva==0x5b4bc and count!=prior_strlen["length"]:
                raise RuntimeError("full-name __strncpy_chk2 count differs from the preceding checked string length")
            if lr_rva==0x5b458 and count>=prior_strlen["length"]:
                raise RuntimeError("array-base __strncpy_chk2 count is not shorter than the checked bracketed name")
            source_bytes=bytes(self.u.mem_read(source,source_size))
            copied=fortified_strncpy_bytes(source_bytes,count,destination_size,source_size)
            self.u.mem_write(destination,copied)
            output=prior_strlen["active_uniform_output"]
            row={"symbol":"__strncpy_chk2","abi":"char *__strncpy_chk2(char*, const char*, size_t, size_t, size_t) -> X0",
                 "implementation":"bounded fortified strncpy semantics on exact guest bytes; zero-pad after an early NUL",
                 "source_dso":"libSPenRenderer.so","caller":"SPen::GLES::OpenGLShaderProgram::GetBindingIntf(char const*)",
                 "lr":hex(lr),"lr_rva":hex(lr_rva),"destination":hex(destination),"source":hex(source),
                 "count":count,"destination_size":destination_size,"source_size":source_size,
                 "source_bytes_hex":source_bytes.hex(),"copied_bytes_hex":copied.hex(),
                 "active_uniform_output":output}
            self.strncpy_chk2_calls.append(row)
            self.x(0,destination)

        def strcmp_guest(self):
            left_pointer,right_pointer=self.x(0),self.x(1)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            lr_rva=lr-renderer_base
            sp=self.u.reg_read(R.UC_ARM64_REG_SP)
            if lr_rva!=STRCMP_CALLSITE_LR_RENDERER_RVA:
                raise RuntimeError(f"strcmp called outside pinned GetBindingIntf caller: LR={lr:#x}")
            if (left_pointer,right_pointer)!=(sp+0x60,sp+0xe0):
                raise RuntimeError("strcmp operands differ from GetBindingIntf's active-uniform/request-name locals")
            if not self.binding_name_inputs:
                raise RuntimeError("strcmp has no captured GetBindingIntf entry argument")
            request_input=self.binding_name_inputs[-1]
            right_bytes=self._read_guest_cstr(right_pointer,STRCMP_OPERAND_BUFFER_SIZE)
            if right_bytes!=bytes.fromhex(request_input["request_name_bytes_hex"]):
                raise RuntimeError("strcmp request operand differs from the actual GetBindingIntf entry name")
            if not self.strncpy_chk2_calls:
                raise RuntimeError("strcmp has no preceding native bounded copy of a Mesa uniform name")
            copied=self.strncpy_chk2_calls[-1]
            if copied["destination"]!=hex(left_pointer):
                raise RuntimeError("strcmp left operand is not the immediately preceding GetBindingIntf uniform-name copy")
            left_bytes=self._read_guest_cstr(left_pointer,STRCMP_OPERAND_BUFFER_SIZE)
            mesa_uniform=copied["active_uniform_output"]
            mesa_name=mesa_uniform["name_text"].encode()
            copy_bytes=bytes.fromhex(copied["copied_bytes_hex"])
            if not left_bytes.startswith(copy_bytes) or not mesa_name.startswith(left_bytes):
                raise RuntimeError("strcmp left operand does not join to the actual Mesa uniform name copied by GetBindingIntf")
            result,left_compared,right_compared=guest_strcmp_bytes(left_bytes,right_bytes)
            relation="exact" if left_bytes==mesa_name else "prefix"
            row={"symbol":"strcmp","abi":"int strcmp(const char*, const char*) -> W0/X0",
                 "implementation":"bounded C-string comparison over guest bytes; returns the first unsigned-byte difference, including the terminating NUL",
                 "source_dso":"libSPenRenderer.so","caller":GET_BINDING_INTF_SYMBOL,
                 "plt_pc":hex(self.u.reg_read(R.UC_ARM64_REG_PC)),"lr":hex(lr),"lr_rva":hex(lr_rva),
                 "left_pointer":hex(left_pointer),"left_bytes_hex":left_bytes.hex(),
                 "right_pointer":hex(right_pointer),"right_bytes_hex":right_bytes.hex(),
                 "compared_left_hex":left_compared.hex(),"compared_right_hex":right_compared.hex(),
                 "result_signed":result,"result_w0":hex(result&0xffffffff),
                 "request_name_input":request_input,"mesa_uniform_join":{"active_uniform_output":mesa_uniform,
                    "copy_record":copied,"compared_left_relation":relation}}
            self.strcmp_calls.append(row)
            self.x(0,result&0xffffffff)


        def vsnprintf_guest(self):
            destination,capacity,format_pointer,va_pointer=[self.x(i) for i in range(4)]
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            renderer_base=self.extra_bases["Renderer"]
            expected_lr=renderer_base+EXPECTED_VSNPRINTF_LR_RENDERER_RVA
            if lr!=expected_lr:raise RuntimeError(f"vsnprintf called from unexpected Renderer address: {lr:#x} != {expected_lr:#x}")
            pending=self.pending_format_helper
            if pending is None:
                raise RuntimeError("vsnprintf did not follow the pinned GetFileName variadic-helper entry")
            if pending["caller_lr"]!=renderer_base+EXPECTED_GETFILENAME_RETURN_RENDERER_RVA:
                raise RuntimeError("format helper did not originate at the pinned GetFileName BL return")
            if destination!=pending["destination"] or capacity!=EXPECTED_VSNPRINTF_CAPACITY:
                raise RuntimeError("vsnprintf destination or capacity differs from the native helper contract")
            if format_pointer!=renderer_base+EXPECTED_VSNPRINTF_FORMAT_RVA:
                raise RuntimeError("vsnprintf format pointer differs from pinned Renderer rodata")
            format_bytes=self._read_guest_cstr(format_pointer,64)
            if format_bytes!=EXPECTED_VSNPRINTF_FORMAT:
                raise RuntimeError(f"vsnprintf native format bytes differ from the pinned cache filename format: {format_bytes!r}")
            ap_bytes=bytes(self.u.mem_read(va_pointer,32))
            decoded=decode_aarch64_gp_u64(ap_bytes,lambda address:struct.unpack("<Q",bytes(self.u.mem_read(address,8)))[0])
            if decoded["gr_top"]!=va_pointer or decoded["argument_address"]!=va_pointer-32 or decoded["stack"]!=va_pointer+0x70:
                raise RuntimeError(f"AArch64 va_list does not match the pinned helper register-save layout: {decoded!r}")
            if decoded["argument_u64"]!=pending["key_u64"]:
                raise RuntimeError("vsnprintf key argument differs from the value passed into the native GetFileName helper")
            if not self.crc32_calls or decoded["argument_u64"]!=self.crc32_calls[-1]["result_u32"]:
                raise RuntimeError("shader filename key is not the immediately preceding native shader-cache CRC32 result")
            rendered=render_shader_cache_filename(format_bytes,decoded["argument_u64"],capacity)
            self.u.mem_write(destination,rendered+b"\0")
            row={"symbol":"vsnprintf","abi":"int vsnprintf(char*,size_t,const char*,va_list) -> W0",
                 "implementation":"source-scoped exact /sh%0lu.dat formatting from AAPCS64 va_list; no host formatter",
                 "source_dso":"libSPenRenderer.so","lr":hex(lr),"lr_rva":hex(lr-renderer_base),
                 "caller":"SPen::ShaderProgramCache::GetFileName -> internal variadic formatter",
                 "caller_helper_entry":hex(pending["entry_pc"]),"caller_helper_return_lr":hex(pending["caller_lr"]),
                 "destination":hex(destination),"capacity":capacity,"format_pointer":hex(format_pointer),
                 "format_bytes":format_bytes.decode("ascii"),"va_list_pointer":hex(va_pointer),
                 "va_list_bytes_hex":ap_bytes.hex(),
                 "va_list_fields":{k:hex(v) if k in ("stack","gr_top","vr_top","argument_address") else v for k,v in decoded.items()},
                 "key_u64":decoded["argument_u64"],"preceding_crc32_result_u32":self.crc32_calls[-1]["result_u32"],
                 "output_bytes_hex":rendered.hex(),"output_text":rendered.decode("ascii"),"returned_chars":len(rendered)}
            self.vsnprintf_calls.append(row)
            pending["vsnprintf_row_index"]=len(self.vsnprintf_calls)-1
            self.x(0,len(rendered))

        def libcpp_strlen_guest(self):
            pointer=self.x(0)
            raw=bytearray()
            for i in range(65536):
                value=self.u.mem_read(pointer+i,1)[0]
                if value==0:break
                raw.append(value)
            else:raise RuntimeError("native libc++ strlen input lacks NUL within 65536 bytes")
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            in_cpp=LIBCPP_BASE<=lr<LIBCPP_BASE+0x200000
            candidates=[(address,name) for address,name in self.symbol_by_address.items()
                        if LIBCPP_BASE<=address<=lr and address<LIBCPP_BASE+0x200000] if in_cpp else []
            caller_address,caller_symbol=max(candidates) if candidates else (None,None)
            if lr==LIBCPP_BASE+EXPECTED_LIBCPP_ASSIGN_STRLEN_LR_RVA and caller_symbol!=LIBCPP_ASSIGN_CSTR:
                raise RuntimeError(f"libc++ assign strlen caller mismatch: {caller_symbol!r}")
            row={"symbol":"strlen","implementation":"bounded byte scan of actual guest C string",
                 "guest_pointer":hex(pointer),"input_bytes":len(raw),"input_sha256":hashlib.sha256(raw).hexdigest(),
                 "input_prefix_hex":bytes(raw[:128]).hex(),"input_text":bytes(raw).decode(errors="replace") if len(raw)<=4096 else None,
                 "plt_pc":hex(self.u.reg_read(R.UC_ARM64_REG_PC)),"lr":hex(lr),
                 "caller_symbol":caller_symbol,"caller_symbol_address":hex(caller_address) if caller_address is not None else None,
                 "caller_symbol_rva":hex(caller_address-LIBCPP_BASE) if caller_address is not None else None,
                 "result_x0":len(raw)}
            self.libcpp_strlen_calls.append(row)
            self.x(0,len(raw))

        def mem_invalid(self,u,access,address,size,value,_data):
            self.invalid_memory_events.append({"access":access,"address":hex(address),"size":size,
                "value":hex(value),"pc":hex(u.reg_read(R.UC_ARM64_REG_PC)),
                "lr":hex(u.reg_read(R.UC_ARM64_REG_LR)),
                "registers_x0_x7":[hex(self.x(i)) for i in range(8)]})
            return False

        def _gl(self, name, argc, argtypes=None, restype=None):
            values = [self.x(i) for i in range(argc)]
            if argtypes is None:
                argtypes = [C.c_uint] * argc
            fn = self._cfunc(name, restype, argtypes)
            result = fn(*values)
            event={"name": name, "args": values,"result": int(result) if result is not None else None}
            if name=="glBindFramebuffer" and self.current_target_activation is not None:
                event["activation_call_index"]=self.current_target_activation["index"]
                event["activation_receiver"]=self.current_target_activation["receiver"]
                event["activation_lr"]=self.current_target_activation["lr"]
            self.gl_events.append(event)
            if name == "glGenTextures": self.texture_ids.extend(self._last_ids)
            if name == "glGenBuffers": self.buffer_ids.extend(self._last_ids)
            if name == "glGenTextures": self._last_ids = []
            if name == "glGenBuffers": self._last_ids = []
            if result is not None: self.x(0, int(result))

        def _gen(self, name):
            count, out = self.x(0), self.x(1)
            if not 0 < count <= 32: raise RuntimeError(f"{name} count outside bound: {count}")
            ids = (C.c_uint * count)()
            self._cfunc(name, None, [C.c_int, C.POINTER(C.c_uint)])(count, ids)
            self.put(out, "I" * count, *list(ids))
            self._last_ids = list(ids)
            self.gl_events.append({"name": name, "count": count, "ids": list(ids)})
            if name == "glGenTextures": self.texture_ids.extend(ids)
            if name == "glGenBuffers": self.buffer_ids.extend(ids)
            if name == "glGenSamplers": self.sampler_ids.extend(ids)
            if name == "glGenFramebuffers": self.framebuffer_ids.extend(ids)
            if name == "glGenRenderbuffers": self.renderbuffer_ids.extend(ids)
            if name == "glGenVertexArrays": self.vertex_array_ids.extend(ids)

        def egl_current_context(self):
            fn=ip.cfunc(self.mesa.egl,"eglGetCurrentContext",C.c_void_p,[])
            self.x(0,fn() or 0)

        def egl_current_display(self):
            fn=ip.cfunc(self.mesa.egl,"eglGetCurrentDisplay",C.c_void_p,[])
            self.x(0,fn() or 0)

        def fopen(self):
            path=self.cstr(self.x(0));mode=self.cstr(self.x(1))
            if not path.startswith(EXPECTED_SHADER_CACHE_DIR+"/"):
                raise RuntimeError(f"native shader-cache file escaped the explicit virtual RendererCache directory: {path!r}")
            if mode in ("rb","r","r+b") and path not in self.virtual_files:
                self._set_virtual_errno(2)
                self.virtual_file_events.append({"op":"open-miss","path":path,"mode":mode,"errno":2});self.x(0,0);return
            if mode not in ("rb","r","r+b","wb","w","w+b","ab","a"):
                raise RuntimeError(f"unsupported native cache file mode {mode!r}")
            token=self.alloc(8)
            prior=self.virtual_files.get(path,{"data":bytearray(),"offset":0})
            if mode.startswith("w"):prior={"data":bytearray(),"offset":0}
            if mode.startswith("a"):prior["offset"]=len(prior["data"])
            row={"path":path,"mode":mode,"data":prior["data"],"offset":prior["offset"]}
            self.virtual_files[path]=row;self.virtual_files[token]=row
            self.virtual_file_events.append({"op":"open","path":path,"mode":mode,"handle":hex(token)})
            self.x(0,token)

        def fclose(self):
            token=self.x(0);row=self.virtual_files.get(token)
            if row is None:raise RuntimeError(f"native cache fclose on unknown handle {token:#x}")
            self.virtual_file_events.append({"op":"close","path":row["path"],"bytes":len(row["data"])})
            self.x(0,0)

        def fread(self):
            ptr,size,count,token=[self.x(i) for i in range(4)];row=self.virtual_files.get(token)
            if row is None or size*count>16*1024*1024:raise RuntimeError("invalid or unbounded native cache fread")
            n=min(size*count,len(row["data"])-row["offset"]);n=max(0,n)
            if n:self.u.mem_write(ptr,bytes(row["data"][row["offset"]:row["offset"]+n]))
            row["offset"]+=n;self.virtual_file_events.append({"op":"read","path":row["path"],"bytes":n})
            self.x(0,n//size if size else 0)

        def fwrite(self):
            ptr,size,count,token=[self.x(i) for i in range(4)];row=self.virtual_files.get(token);n=size*count
            if row is None or n>16*1024*1024:raise RuntimeError("invalid or unbounded native cache fwrite")
            raw=bytes(self.u.mem_read(ptr,n)) if ptr and n else b"";end=row["offset"]+n
            if len(row["data"])<end:row["data"].extend(bytes(end-len(row["data"])))
            row["data"][row["offset"]:end]=raw;row["offset"]=end
            self.virtual_file_events.append({"op":"write","path":row["path"],"bytes":n,"sha256":hashlib.sha256(raw).hexdigest()})
            self.x(0,count)

        def fseek(self):
            token,offset,whence=[self.x(i) for i in range(3)];row=self.virtual_files.get(token)
            if row is None:raise RuntimeError("native cache fseek on unknown handle")
            offset=struct.unpack("<q",struct.pack("<Q",offset))[0]
            new=offset if whence==0 else row["offset"]+offset if whence==1 else len(row["data"])+offset if whence==2 else -1
            if new<0:raise RuntimeError(f"invalid cache seek offset {new}")
            row["offset"]=new;self.virtual_file_events.append({"op":"seek","path":row["path"],"offset":new});self.x(0,0)

        def ftell(self):
            row=self.virtual_files.get(self.x(0))
            if row is None:raise RuntimeError("native cache ftell on unknown handle")
            self.x(0,row["offset"])

        def fflush(self):
            token=self.x(0)
            if token and token not in self.virtual_files:raise RuntimeError("native cache fflush on unknown handle")
            self.x(0,0)

        def setvbuf(self):
            token=self.x(0)
            if token not in self.virtual_files:raise RuntimeError("native cache setvbuf on unknown handle")
            self.x(0,0)

        def fileno(self):
            if self.x(0) not in self.virtual_files:raise RuntimeError("native cache fileno on unknown handle")
            self.x(0,3)

        def fsync(self): self.x(0,0)

        def _invoke(self, name, args, floats=(), limit=5_000_000):
            """Call a pinned native function with AArch64 stack arguments."""
            sp=0x200f0000
            for index,value in enumerate(args[8:]): self.put(sp+8*index,"Q",value)
            return self.call(name,list(args[:8]),list(floats),instruction_limit=limit)

        def _install_gl(self):
            self.callbacks.update({
                "glGenTextures": lambda: self._gen("glGenTextures"),
                "glGenBuffers": lambda: self._gen("glGenBuffers"),
                "glGenSamplers": lambda: self._gen("glGenSamplers"),
                "glGenVertexArrays": lambda: self._gen("glGenVertexArrays"),
                "glGenFramebuffers": lambda: self._gen("glGenFramebuffers"),
                "glGenRenderbuffers": lambda: self._gen("glGenRenderbuffers"),
                "glGenVertexArrays": lambda: self._gen("glGenVertexArrays"),
                "glBindTexture": lambda: self._gl("glBindTexture", 2),
                "glBindSampler": lambda: self._gl("glBindSampler", 2),
                "glSamplerParameteri": lambda: self._gl("glSamplerParameteri", 3),
                "glBindVertexArray": lambda: self._gl("glBindVertexArray", 1),
                "glBindFramebuffer": lambda: self._gl("glBindFramebuffer", 2),
                "glFramebufferTexture2D": lambda: self._gl("glFramebufferTexture2D", 5,
                    [C.c_uint,C.c_uint,C.c_uint,C.c_uint,C.c_int]),
                "glFramebufferRenderbuffer": lambda: self._gl("glFramebufferRenderbuffer", 4,
                    [C.c_uint,C.c_uint,C.c_uint,C.c_uint]),
                "glCheckFramebufferStatus": self._check_framebuffer,
                "glBindRenderbuffer": lambda: self._gl("glBindRenderbuffer",2),
                "glRenderbufferStorage": lambda: self._gl("glRenderbufferStorage",4,
                    [C.c_uint,C.c_uint,C.c_int,C.c_int]),
                "glDeleteRenderbuffers": lambda: self._delete_ids("glDeleteRenderbuffers"),
                "glDeleteFramebuffers": lambda: self._delete_ids("glDeleteFramebuffers"),
                "glViewport": lambda: self._gl("glViewport", 4, [C.c_int,C.c_int,C.c_int,C.c_int]),
                "glClearColor": lambda: self._uniform_float(4, "glClearColor"),
                "glClear": lambda: self._gl("glClear", 1),
                "glClearDepthf": lambda: self._uniform_float(1,"glClearDepthf"),
                "glClearStencil": lambda: self._gl("glClearStencil",1,[C.c_int]),
                "glColorMask": self._color_mask,
                "glActiveTexture": lambda: self._gl("glActiveTexture", 1),
                "glTexParameteri": lambda: self._gl("glTexParameteri", 3),
                "glPixelStorei": lambda: self._gl("glPixelStorei", 2),
                "glBindBuffer": lambda: self._gl("glBindBuffer", 2),
                "glEnableVertexAttribArray": lambda: self._gl("glEnableVertexAttribArray", 1),
                "glDisableVertexAttribArray": lambda: self._gl("glDisableVertexAttribArray", 1),
                "glVertexAttribDivisor": lambda: self._gl("glVertexAttribDivisor", 2),
                "glDrawArraysInstanced": lambda: self._gl("glDrawArraysInstanced", 4,
                    [C.c_uint, C.c_int, C.c_int, C.c_int]),
                "glDrawElements": lambda: self._gl("glDrawElements",4,
                    [C.c_uint,C.c_int,C.c_uint,C.c_void_p]),
                "glEnable": lambda: self._gl("glEnable", 1),
                "glDisable": lambda: self._gl("glDisable", 1),
                "glBlendEquationSeparate": lambda: self._gl("glBlendEquationSeparate", 2),
                "glBlendFuncSeparate": lambda: self._gl("glBlendFuncSeparate", 4),
                "glBlendFunc": lambda: self._gl("glBlendFunc",2),
                "glUseProgram": lambda: self._gl("glUseProgram", 1),
                "glUniform1i": lambda: self._gl("glUniform1i", 2, [C.c_int, C.c_int]),
                "glUniform1f": lambda: self._uniform_float(1),
                "glUniform2f": lambda: self._uniform_float(2),
                "glUniform4f": lambda: self._uniform_float(4),
                "glUniform2fv": lambda: self._uniform_vector(2),
                "glUniform3fv": lambda: self._uniform_vector(3),
                "glUniform4fv": lambda: self._uniform_vector(4),
                "glUniformMatrix4fv": self._uniform_matrix,
                "glDrawArrays": lambda: self._gl("glDrawArrays", 3, [C.c_uint,C.c_int,C.c_int]),
                "glGetError": lambda: self.x(0, self.mesa.f["glGetError"]()),
                "glGetString": self._get_string,
                "glGetIntegerv": self._get_integer,
                "glBufferData": self._buffer_data,
                "glBufferSubData": self._buffer_sub_data,
                "glVertexAttribPointer": self._vertex_attrib_pointer,
                "glTexImage2D": self._tex_image,
                "glTexSubImage2D": self._tex_sub_image,
                "glCreateShader": self._create_shader,
                "glShaderSource": self._shader_source,
                "glCompileShader": lambda: self._gl("glCompileShader", 1),
                "glGetShaderiv": self._shader_iv,
                "glGetShaderInfoLog": self._shader_log,
                "glCreateProgram": self._create_program,
                "glAttachShader": lambda: self._gl("glAttachShader", 2),
                "glBindAttribLocation": self._bind_attrib,
                "glLinkProgram": lambda: self._gl("glLinkProgram", 1),
                "glGetProgramiv": self._program_iv,
                "glGetProgramInfoLog": self._program_log,
                "glGetActiveUniform": self._active_uniform,
                "glGetBooleanv": self._get_boolean,
                "glGetProgramBinary": self._get_program_binary,
                "glProgramBinary": self._program_binary,
                "glDetachShader": lambda: self._gl("glDetachShader",2),
                "glDeleteShader": lambda: self._gl("glDeleteShader",1),
                "glDeleteProgram": lambda: self._gl("glDeleteProgram",1),
                "glDeleteBuffers": lambda: self._delete_ids("glDeleteBuffers"),
                "glDeleteTextures": lambda: self._delete_ids("glDeleteTextures"),
                "glDeleteSamplers": lambda: self._delete_ids("glDeleteSamplers"),
                "glDeleteVertexArrays": lambda: self._delete_ids("glDeleteVertexArrays"),
                "glGetUniformLocation": self._get_uniform_location,
                "glGetAttribLocation": self._get_attrib_location,
                "glGetUniformBlockIndex": self._get_uniform_block_index,
                "glUniformBlockBinding": lambda: self._gl("glUniformBlockBinding",3),
                "glBindBufferBase": lambda: self._gl("glBindBufferBase",3),
                "glScissor": lambda: self._gl("glScissor",4,[C.c_int]*4),
                "glInvalidateFramebuffer": self._invalidate_framebuffer,
                "glDepthFunc": lambda: self._gl("glDepthFunc",1),
                "glDepthMask": lambda: self._gl("glDepthMask",1,[C.c_ubyte]),
                "glCullFace": lambda: self._gl("glCullFace",1),
                "glStencilFunc": lambda: self._gl("glStencilFunc",3),
                "glStencilFuncSeparate": lambda: self._gl("glStencilFuncSeparate",4),
                "glStencilMask": lambda: self._gl("glStencilMask",1),
                "glStencilMaskSeparate": lambda: self._gl("glStencilMaskSeparate",2),
                "glStencilOpSeparate": lambda: self._gl("glStencilOpSeparate",4),
                "glFlush": lambda: self._gl("glFlush",0),
                "glFinish": lambda: self._gl("glFinish",0),
                "glFenceSync": self._fence_sync,
                "glClientWaitSync": self._client_wait_sync,
                "glWaitSync": self._wait_sync,
                "glGetSynciv": self._get_sync_iv,
                "glDeleteSync": self._delete_sync,
                "glIsSampler": lambda: self._gl_return("glIsSampler",[C.c_uint]),
                "glIsTexture": lambda: self._gl_return("glIsTexture",[C.c_uint]),
            })

        def _delete_ids(self,name):
            count,out=self.x(0),self.x(1)
            if not 0<=count<=64:raise RuntimeError(f"{name} count outside bound: {count}")
            ids=tuple(self.get(out,"I"*count)) if count else ()
            self._cfunc(name,None,[C.c_int,C.POINTER(C.c_uint)])(count,(C.c_uint*count)(*ids))
            self.gl_events.append({"name":name,"ids":ids})

        def _uniform_vector(self,n):
            loc,count,ptr=self.x(0),self.x(1),self.x(2)
            if not 0<count<=256:raise RuntimeError(f"glUniform{n}fv count outside bound: {count}")
            vals=self.get(ptr,"f"*(n*count)); arr=(C.c_float*len(vals))(*vals)
            self._cfunc("glUniform"+str(n)+"fv",None,[C.c_int,C.c_int,C.POINTER(C.c_float)])(loc,count,arr)
            self.gl_events.append({"name":"glUniform"+str(n)+"fv","location":loc,"count":count,"values":vals})

        def _active_uniform(self):
            program,index,cap,lengthp,sizep,typep,namep=[self.x(i) for i in range(7)]
            if not 0<cap<=65536:raise RuntimeError(f"glGetActiveUniform buffer outside bound: {cap}")
            length,size,kind=C.c_int(),C.c_int(),C.c_uint()
            name=C.create_string_buffer(cap)
            self._cfunc("glGetActiveUniform",None,[C.c_uint,C.c_uint,C.c_int,C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_uint),C.c_char_p])(
                program,index,cap,C.byref(length) if lengthp else None,C.byref(size) if sizep else None,C.byref(kind) if typep else None,name)
            if lengthp:self.put(lengthp,"i",length.value)
            if sizep:self.put(sizep,"i",size.value)
            if typep:self.put(typep,"I",kind.value)
            if namep:self.u.mem_write(namep,name.raw[:cap])
            if namep and cap==ACTIVE_UNIFORM_BUFFER_SIZE:
                active_bytes=bytes(name.raw[:cap])
                _bounded_bytes,bounded_length=active_uniform_name_case(active_bytes,cap)
                if length.value!=bounded_length or not 0<=length.value<cap:
                    raise RuntimeError("Mesa glGetActiveUniform length differs from its bounded name output")
                output_row={"program":program,"index":index,"guest_name_pointer":namep,
                            "buffer_capacity":cap,"reported_length":length.value,
                            "buffer_bytes_hex":active_bytes.hex(),"name_text":active_bytes[:length.value].decode(errors="replace"),
                            "size":size.value,"type":kind.value}
                self.active_uniform_outputs.append(output_row)
            self.gl_events.append({"name":"glGetActiveUniform","program":program,"index":index,"name":name.value.decode(errors="replace"),"size":size.value,"type":kind.value})

        def _get_boolean(self):
            enum,out=self.x(0),self.x(1); count=4 if enum in (0x0c22,0x0c23) else 1
            vals=(C.c_ubyte*count)(); self._cfunc("glGetBooleanv",None,[C.c_uint,C.POINTER(C.c_ubyte)])(enum,vals)
            self.u.mem_write(out,bytes(vals)); self.gl_events.append({"name":"glGetBooleanv","enum":enum,"values":list(vals)})

        def _get_program_binary(self):
            program,cap,lengthp,formatp,out=[self.x(i) for i in range(5)]
            if not 0<=cap<=16*1024*1024:raise RuntimeError(f"glGetProgramBinary cap outside bound: {cap}")
            length,fmt=C.c_int(),C.c_uint(); raw=C.create_string_buffer(max(cap,1))
            self._cfunc("glGetProgramBinary",None,[C.c_uint,C.c_int,C.POINTER(C.c_int),C.POINTER(C.c_uint),C.c_void_p])(
                program,cap,C.byref(length) if lengthp else None,C.byref(fmt) if formatp else None,C.cast(raw,C.c_void_p) if cap else None)
            data=raw.raw[:max(0,min(length.value,cap))]
            if lengthp:self.put(lengthp,"i",length.value)
            if formatp:self.put(formatp,"I",fmt.value)
            if out and data:self.u.mem_write(out,data)
            self.gl_events.append({"name":"glGetProgramBinary","program":program,"length":length.value,"format":fmt.value,"sha256":hashlib.sha256(data).hexdigest()})

        def _program_binary(self):
            program,fmt,pointer,length=[self.x(i) for i in range(4)]
            if not 0<=length<=16*1024*1024:raise RuntimeError(f"glProgramBinary length outside bound: {length}")
            raw=bytes(self.u.mem_read(pointer,length)) if pointer and length else b""
            buf=C.create_string_buffer(raw) if raw else None
            self._cfunc("glProgramBinary",None,[C.c_uint,C.c_uint,C.c_void_p,C.c_int])(program,fmt,C.cast(buf,C.c_void_p) if buf else None,length)
            self.gl_events.append({"name":"glProgramBinary","program":program,"format":fmt,"length":length,"sha256":hashlib.sha256(raw).hexdigest()})

        def _get_attrib_location(self):
            program,name=self.x(0),self.x(1); raw=self._cstring(name)
            loc=self._cfunc("glGetAttribLocation",C.c_int,[C.c_uint,C.c_char_p])(program,raw)
            self.x(0,loc);self.gl_events.append({"name":"glGetAttribLocation","program":program,"attribute":raw.decode(errors="replace"),"location":loc})

        def _get_uniform_block_index(self):
            program,name=self.x(0),self.x(1);raw=self._cstring(name)
            idx=self._cfunc("glGetUniformBlockIndex",C.c_uint,[C.c_uint,C.c_char_p])(program,raw)
            self.x(0,int(idx));self.gl_events.append({"name":"glGetUniformBlockIndex","program":program,"block":raw.decode(errors="replace"),"index":int(idx)})

        def _invalidate_framebuffer(self):
            target,count,ptr=self.x(0),self.x(1),self.x(2)
            if not 0<=count<=16:raise RuntimeError(f"glInvalidateFramebuffer count outside bound: {count}")
            enums=self.get(ptr,"I"*count) if count else ()
            self._cfunc("glInvalidateFramebuffer",None,[C.c_uint,C.c_int,C.POINTER(C.c_uint)])(target,count,(C.c_uint*count)(*enums))
            self.gl_events.append({"name":"glInvalidateFramebuffer","target":target,"attachments":enums})

        def _gl_return(self,name,argtypes):
            vals=[self.x(i) for i in range(len(argtypes))]
            result=self._cfunc(name,C.c_ubyte,argtypes)(*vals)
            self.x(0,int(result));self.gl_events.append({"name":name,"args":vals,"result":int(result)})

        def _fence_sync(self):
            condition,flags=self.x(0),self.x(1)
            token=self._cfunc("glFenceSync",C.c_void_p,[C.c_uint,C.c_uint])(condition,flags) or 0
            self.x(0,int(token));self.gl_events.append({"name":"glFenceSync","condition":condition,"flags":flags,"sync":hex(int(token))})

        def _client_wait_sync(self):
            sync,flags,timeout=self.x(0),self.x(1),self.x(2)
            result=self._cfunc("glClientWaitSync",C.c_uint,[C.c_void_p,C.c_uint,C.c_uint64])(C.c_void_p(sync),flags,timeout)
            self.x(0,int(result));self.gl_events.append({"name":"glClientWaitSync","sync":hex(sync),"flags":flags,"timeout":timeout,"result":int(result)})

        def _wait_sync(self):
            sync,flags,timeout=self.x(0),self.x(1),self.x(2)
            self._cfunc("glWaitSync",None,[C.c_void_p,C.c_uint,C.c_uint64])(C.c_void_p(sync),flags,timeout)
            self.gl_events.append({"name":"glWaitSync","sync":hex(sync),"flags":flags,"timeout":timeout})

        def _get_sync_iv(self):
            sync,pname,cap,lengthp,valuesp=[self.x(i) for i in range(5)]
            if not 0<cap<=32:raise RuntimeError(f"glGetSynciv buffer outside bound: {cap}")
            length=C.c_int();values=(C.c_int*cap)()
            self._cfunc("glGetSynciv",None,[C.c_void_p,C.c_uint,C.c_int,C.POINTER(C.c_int),C.POINTER(C.c_int)])(
                C.c_void_p(sync),pname,cap,C.byref(length) if lengthp else None,values)
            if lengthp:self.put(lengthp,"i",length.value)
            if valuesp:self.put(valuesp,"i"*min(max(length.value,0),cap),*list(values)[:cap])
            self.gl_events.append({"name":"glGetSynciv","sync":hex(sync),"pname":pname,"length":length.value,"values":list(values)[:max(0,min(length.value,cap))]})

        def _delete_sync(self):
            sync=self.x(0);self._cfunc("glDeleteSync",None,[C.c_void_p])(C.c_void_p(sync))
            self.gl_events.append({"name":"glDeleteSync","sync":hex(sync)})

        def _uniform_float(self, n, name=None):
            loc = self.x(0); vals = [self.f(i) for i in range(n)]
            if name:
                self._cfunc(name, None, [C.c_float] * n)(*vals)
                self.gl_events.append({"name": name, "values": vals})
            else:
                fn = self._cfunc("glUniform" + str(n) + "f", None, [C.c_int] + [C.c_float] * n)
                fn(loc, *vals)
                self.gl_events.append({"name": "glUniform" + str(n) + "f", "location": loc, "values": vals})

        def _check_framebuffer(self):
            target=self.x(0); value=self._cfunc("glCheckFramebufferStatus",C.c_uint,[C.c_uint])(target)
            self.x(0,value); self.gl_events.append({"name":"glCheckFramebufferStatus","target":target,"status":value})

        def _color_mask(self):
            vals=[bool(self.x(i)) for i in range(4)]
            self._cfunc("glColorMask",None,[C.c_ubyte]*4)(*[int(v) for v in vals])
            self.gl_events.append({"name":"glColorMask","values":[int(v) for v in vals]})

        def _uniform_matrix(self):
            loc,count,transpose,ptr=[self.x(i) for i in range(4)]
            if not 0<count<=64: raise RuntimeError(f"uniform matrix count outside bound: {count}")
            vals=self.get(ptr,"f"*(16*count)); arr=(C.c_float*len(vals))(*vals)
            self._cfunc("glUniformMatrix4fv",None,[C.c_int,C.c_int,C.c_ubyte,C.POINTER(C.c_float)])(
                loc,count,transpose,arr)
            self.gl_events.append({"name":"glUniformMatrix4fv","location":loc,"count":count,"values":vals})

        def _get_string(self):
            enum = self.x(0); raw = self.mesa.gl_string(enum) or b""
            if enum==GL_EXTENSIONS_ENUM and len(raw)>GL_EXTENSIONS_MAX_BYTES:
                raise RuntimeError(f"actual Mesa GL_EXTENSIONS payload exceeds API-specific cap: {len(raw)}")
            if b"\0" in raw:raise RuntimeError("Mesa glGetString payload contains an embedded NUL")
            ptr = self.alloc(len(raw) + 1); self.u.mem_write(ptr, raw + b"\0"); self.x(0, ptr)
            self.gl_strings_by_pointer[ptr]=(enum,raw)
            self.gl_events.append({"name": "glGetString", "enum": enum, "value": raw.decode(errors="replace")})

        def _get_integer(self):
            enum, out = self.x(0), self.x(1)
            count = 2 if enum == 0x0d3a else 1
            values = (C.c_int * count)()
            self._cfunc("glGetIntegerv", None, [C.c_uint, C.POINTER(C.c_int)])(enum, values)
            self.put(out, "i" * count, *list(values))
            self.gl_events.append({"name": "glGetIntegerv", "enum": enum, "values": list(values)})

        def _buffer_data(self):
            target, size, ptr, usage = [self.x(i) for i in range(4)]
            if size > 32 * 1024 * 1024: raise RuntimeError(f"glBufferData size outside cap: {size}")
            raw = bytes(self.u.mem_read(ptr, size)) if ptr and size else b""
            buf = C.create_string_buffer(raw) if raw else None
            self._cfunc("glBufferData", None, [C.c_uint, C.c_ssize_t, C.c_void_p, C.c_uint])(
                target, size, C.cast(buf, C.c_void_p) if buf else None, usage)
            self.gl_events.append({"name": "glBufferData", "target": target, "size": size,
                                   "usage": usage, "sha256": hashlib.sha256(raw).hexdigest()})

        def _buffer_sub_data(self):
            target, offset, size, ptr = [self.x(i) for i in range(4)]
            if size > 32 * 1024 * 1024: raise RuntimeError(f"glBufferSubData size outside cap: {size}")
            raw = bytes(self.u.mem_read(ptr, size)) if ptr and size else b""
            buf = C.create_string_buffer(raw) if raw else None
            self._cfunc("glBufferSubData", None, [C.c_uint, C.c_ssize_t, C.c_ssize_t, C.c_void_p])(
                target, offset, size, C.cast(buf, C.c_void_p) if buf else None)
            self.gl_events.append({"name": "glBufferSubData", "target": target, "offset": offset,
                                   "size": size, "sha256": hashlib.sha256(raw).hexdigest()})

        def _vertex_attrib_pointer(self):
            args = [self.x(i) for i in range(6)]
            self._cfunc("glVertexAttribPointer", None, [C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(
                args[0],args[1],args[2],args[3],args[4],C.c_void_p(args[5]))
            self.gl_events.append({"name":"glVertexAttribPointer","args":args})

        def _tex_image(self):
            args=[self.x(i) for i in range(8)]; ptr=self.get(self.u.reg_read(R.UC_ARM64_REG_SP),"Q")[0]
            n=args[3]*args[4]*({0x1903:1,0x1906:1,0x1907:3,0x1908:4,0x80e1:4}.get(args[6],4))*({0x1401:1,0x1403:2,0x1406:4}.get(args[7],1))
            if n>64*1024*1024: raise RuntimeError(f"texture allocation outside cap: {n}")
            raw=bytes(self.u.mem_read(ptr,n)) if ptr and n else b""; buf=C.create_string_buffer(raw) if raw else None
            active=C.c_int();binding=C.c_int();self._cfunc("glGetIntegerv",None,[C.c_uint,C.POINTER(C.c_int)])(0x84e0,C.byref(active));self._cfunc("glGetIntegerv",None,[C.c_uint,C.POINTER(C.c_int)])(0x8069,C.byref(binding))
            self._cfunc("glTexImage2D",None,[C.c_uint,C.c_int,C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(
                *args,C.cast(buf,C.c_void_p) if buf else None)
            self.gl_events.append({"name":"glTexImage2D","args":args,"texture":binding.value,"active_texture":active.value,"byte_length":len(raw),"sha256":hashlib.sha256(raw).hexdigest() if raw else None})

        def _tex_sub_image(self):
            args=[self.x(i) for i in range(8)]; ptr=self.get(self.u.reg_read(R.UC_ARM64_REG_SP),"Q")[0]
            n=args[4]*args[5]*({0x1903:1,0x1906:1,0x1907:3,0x1908:4,0x80e1:4}.get(args[6],4))*({0x1401:1,0x1403:2,0x1406:4}.get(args[7],1))
            if n>64*1024*1024: raise RuntimeError(f"texture upload outside cap: {n}")
            raw=bytes(self.u.mem_read(ptr,n)) if ptr and n else b""; buf=C.create_string_buffer(raw) if raw else None
            self._cfunc("glTexSubImage2D",None,[C.c_uint,C.c_int,C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(
                *args,C.cast(buf,C.c_void_p) if buf else None)
            row={"name":"glTexSubImage2D","args":args,"byte_length":len(raw),"sha256":hashlib.sha256(raw).hexdigest() if raw else None}
            self.uploads.append(row); self.gl_events.append(row)

        def _create_shader(self):
            kind=self.x(0); value=self._cfunc("glCreateShader",C.c_uint,[C.c_uint])(kind); self.x(0,value)
            self.gl_events.append({"name":"glCreateShader","kind":kind,"id":value})

        def _shader_source(self):
            sh,count,arr,lens=[self.x(i) for i in range(4)]
            if not 0<count<=16: raise RuntimeError(f"shader source count outside bound {count}")
            ptrs=struct.unpack("<"+"Q"*count,self.u.mem_read(arr,count*8)); raws=[]; bufs=[]
            for i,ptr in enumerate(ptrs):
                raw=bytes(self.u.mem_read(ptr,0x10000)).split(b"\0",1)[0]
                if lens:
                    n=self.get(lens+4*i,"i")[0]
                    if n>=0: raw=raw[:n]
                raws.append(raw); bufs.append(C.c_char_p(raw))
            array=(C.c_char_p*count)(*bufs); lengths=(C.c_int*count)(*(self.get(lens,"i"*count) if lens else [-1]*count))
            self._cfunc("glShaderSource",None,[C.c_uint,C.c_int,C.POINTER(C.c_char_p),C.POINTER(C.c_int)])(sh,count,array,lengths if lens else None)
            row={"name":"glShaderSource","shader":sh,"source_sha256":[hashlib.sha256(x).hexdigest() for x in raws],"source_utf8":[x.decode(errors="replace") for x in raws]}
            self.shader_sources.extend(row["source_utf8"]); self.gl_events.append(row)

        def _shader_iv(self):
            sh,pname,out=self.x(0),self.x(1),self.x(2); val=C.c_int()
            self._cfunc("glGetShaderiv",None,[C.c_uint,C.c_uint,C.POINTER(C.c_int)])(sh,pname,C.byref(val)); self.put(out,"i",val.value)
            self.gl_events.append({"name":"glGetShaderiv","shader":sh,"pname":pname,"value":val.value})

        def _shader_log(self):
            sh,cap,lengthp,out=[self.x(i) for i in range(4)]
            buf=C.create_string_buffer(min(max(cap,1),65536)); length=C.c_int()
            self._cfunc("glGetShaderInfoLog",None,[C.c_uint,C.c_int,C.POINTER(C.c_int),C.c_char_p])(sh,len(buf),C.byref(length),buf)
            raw=buf.raw[:max(0,length.value)]
            if lengthp:self.put(lengthp,"i",length.value)
            if out:self.u.mem_write(out,raw+b"\0")
            self.shader_compile.append({"shader":sh,"log":raw.decode(errors="replace")})

        def _create_program(self):
            value=self._cfunc("glCreateProgram",C.c_uint,[])(); self.x(0,value); self.programs.append(value)
            self.gl_events.append({"name":"glCreateProgram","id":value})

        def _cstring(self,pointer,cap=4096):
            raw=bytearray()
            for i in range(cap):
                b=self.u.mem_read(pointer+i,1)
                if b==b"\0":return bytes(raw)
                raw.extend(b)
            raise RuntimeError("native GL string exceeded bound")

        def _bind_attrib(self):
            program,index,name=self.x(0),self.x(1),self.x(2); raw=self._cstring(name)
            self._cfunc("glBindAttribLocation",None,[C.c_uint,C.c_uint,C.c_char_p])(program,index,raw)
            self.gl_events.append({"name":"glBindAttribLocation","program":program,"index":index,"attribute":raw.decode(errors="replace")})

        def _program_iv(self):
            program,pname,out=self.x(0),self.x(1),self.x(2); val=C.c_int()
            self._cfunc("glGetProgramiv",None,[C.c_uint,C.c_uint,C.POINTER(C.c_int)])(program,pname,C.byref(val)); self.put(out,"i",val.value)
            self.gl_events.append({"name":"glGetProgramiv","program":program,"pname":pname,"value":val.value})

        def _program_log(self):
            program,cap,lengthp,out=[self.x(i) for i in range(4)]
            buf=C.create_string_buffer(min(max(cap,1),65536)); length=C.c_int()
            self._cfunc("glGetProgramInfoLog",None,[C.c_uint,C.c_int,C.POINTER(C.c_int),C.c_char_p])(program,len(buf),C.byref(length),buf)
            raw=buf.raw[:max(0,length.value)]
            if lengthp:self.put(lengthp,"i",length.value)
            if out:self.u.mem_write(out,raw+b"\0")
            self.shader_compile.append({"program":program,"log":raw.decode(errors="replace")})

        def _get_uniform_location(self):
            program,name=self.x(0),self.x(1); raw=self._cstring(name)
            loc=self._cfunc("glGetUniformLocation",C.c_int,[C.c_uint,C.c_char_p])(program,raw)
            self.x(0,loc); self.uniform_locations[raw.decode(errors="replace")]=loc
            self.gl_events.append({"name":"glGetUniformLocation","program":program,"uniform":raw.decode(errors="replace"),"location":loc})

        def _virtual_path(self, pointer):
            raw=self._read_guest_cstr(pointer,4096)
            if not raw or b"\0" in raw:
                raise RuntimeError("empty or malformed path passed to virtual cache filesystem")
            path=raw.decode("utf-8",errors="strict")
            if path!=VIRTUAL_FS_PREFIX and not path.startswith(VIRTUAL_FS_PREFIX+"/"):
                raise RuntimeError(f"native cache filesystem path escaped the explicit virtual prefix: {path!r}")
            if "\\" in path or any(part in (".","..") for part in path.split("/")):
                raise RuntimeError(f"non-normalized native cache path rejected: {path!r}")
            return path

        def _set_virtual_errno(self, value):
            self.virtual_errno=value
            self.put(self.errno_ptr,"i",value)

        def virtual_errno_address(self):
            self.x(0,self.errno_ptr)

        def virtual_access(self):
            path=self._virtual_path(self.x(0)); mode=self.x(1)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            allowed={self.extra_bases["Renderer"]+EXPECTED_CACHE_ACCESS_LR_RENDERER_RVA,
                     self.base_dso_base+EXPECTED_CACHE_PARENT_ACCESS_LR_BASE_RVA}
            if lr not in allowed:raise RuntimeError(f"virtual access called from unexpected native source: {lr:#x}")
            if mode!=0:raise RuntimeError(f"unexpected access mode for shader-cache directory: {mode}")
            exists=path in self.virtual_dirs or path in self.virtual_files
            self.virtual_fs_events.append({"op":"access","path":path,"mode":mode,"exists":exists,
                "caller_lr":hex(lr),"errno_before":self.virtual_errno})
            if exists:
                self.x(0,0)
            else:
                self._set_virtual_errno(2) # POSIX ENOENT: native MakeDirectory checks errno.
                self.x(0,0xffffffff)

        def virtual_mkdir(self):
            path=self._virtual_path(self.x(0)); mode=self.x(1)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            if lr not in {self.base_dso_base+EXPECTED_CACHE_MKDIR_LR_BASE_RVA}:
                raise RuntimeError(f"virtual mkdir called from unexpected native source: {lr:#x}")
            if mode!=0x1ff:raise RuntimeError(f"unexpected native cache mkdir mode: {mode:#x}")
            parent=path.rsplit("/",1)[0]
            exists=path in self.virtual_dirs or path in self.virtual_files
            parent_exists=parent in self.virtual_dirs
            if exists:
                result=-1;err=17 # EEXIST
            elif not parent_exists:
                result=-1;err=2 # ENOENT
            else:
                self.virtual_dirs.add(path);result=0;err=None
            if err is not None:self._set_virtual_errno(err)
            self.virtual_fs_events.append({"op":"mkdir","path":path,"parent":parent,"mode":mode,
                "parent_exists":parent_exists,"already_exists":exists,"result":result,
                "errno":err,"caller_lr":hex(lr)})
            self.x(0,result)

        def native_operator_new(self):
            size=self.x(0)
            if not 0<size<=1<<20:
                raise RuntimeError(f"native operator new request outside bounded Pencil2 queue evidence cap: {size}")
            address=self.alloc(size)
            self.native_allocations.append({"pointer":hex(address),"size":size,
                "caller_lr":hex(self.u.reg_read(R.UC_ARM64_REG_LR))})
            self.x(0,address)

        def posix_memalign_guest(self):
            output=self.x(0);alignment=self.x(1);size=self.x(2)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            caller_rva=lr-LIBCPP_BASE
            call_rva=caller_rva-4
            profile=LIBCPP_POSIX_MEMALIGN_CALLS.get(call_rva)
            if profile is None:
                raise RuntimeError(f"posix_memalign call outside the two source-pinned libc++ callers: LR={lr:#x}")
            if size<1:
                raise RuntimeError(f"pinned libc++ source max(size,1) precondition failed: {size}")
            if call_rva==0xa023c:
                if alignment!=profile["alignment"]:
                    raise RuntimeError(f"pinned libc++ aligned allocation helper must pass 16-byte alignment, got {alignment}")
            elif alignment<8 or alignment&(alignment-1):
                raise RuntimeError(f"pinned aligned operator new produced invalid posix_memalign alignment: {alignment}")
            sp=self.u.reg_read(R.UC_ARM64_REG_SP)
            if not (0x20000000<=output and output+8<=0x20100000 and abs(output-sp)<=0x1000):
                raise RuntimeError(f"pinned posix_memalign caller output pointer is outside its guest stack frame: out={output:#x}, sp={sp:#x}")
            row={"symbol":"posix_memalign","abi":"int posix_memalign(void **, size_t, size_t)",
                 "caller_dso":"libc++_shared.so","caller_rva":hex(caller_rva),"caller_lr":hex(lr),
                 "callsite_rva":hex(call_rva),"caller_profile":profile,"out_pointer":hex(output),"alignment":alignment,"size":size,
                 "guest_heap_before":hex(self.heap),"max_request":LIBCPP_POSIX_MEMALIGN_MAX_REQUEST}
            if alignment>1<<20 or size>LIBCPP_POSIX_MEMALIGN_MAX_REQUEST:
                row.update({"return_code":12,"result":"ENOMEM","allocation":None})
                self.posix_memalign_calls.append(row)
                self.x(0,12)
                return
            raw,aligned,next_heap=aligned_guest_layout(self.heap,size,alignment)
            if next_heap>0x12000000:
                row.update({"return_code":12,"result":"ENOMEM","allocation":None})
                self.posix_memalign_calls.append(row)
                self.x(0,12)
                return
            extent=max(size,1)
            self.u.mem_write(aligned,bytes(extent))
            self.heap=next_heap
            self.u.mem_write(output,struct.pack("<Q",aligned))
            allocation={"raw_base":hex(raw),"pointer":hex(aligned),"size":size,
                        "alignment":alignment,"allocated_extent":extent,
                        "guest_heap_after":hex(next_heap),"pointer_alignment_remainder":aligned%alignment}
            row.update({"return_code":0,"result":"success","allocation":allocation})
            self.native_aligned_allocations.append(allocation)
            self.posix_memalign_calls.append(row)
            self.x(0,0)

        def free_guest(self):
            pointer=self.x(0)
            lr=self.u.reg_read(R.UC_ARM64_REG_LR)
            if pointer==0:
                self.native_free_calls.append({"pointer":"0x0","caller_lr":hex(lr),"result":"free(NULL) no-op"})
                return
            allocation=next((item for item in reversed(self.native_aligned_allocations)
                             if int(item["pointer"],16)==pointer),None)
            if allocation is None or allocation.get("freed",False):
                raise RuntimeError(f"libc++ free was not passed one live pointer returned by the pinned posix_memalign bridge: ptr={pointer:#x}, LR={lr:#x}")
            allocation["freed"]=True
            self.native_free_calls.append({"pointer":hex(pointer),"caller_lr":hex(lr),
                "result":"tracked guest aligned allocation marked freed; bump heap remains mapped",
                "posix_memalign_allocation":allocation})

        def install_typed_queue_adapter(self):
            env={**os.environ,"LD_LIBRARY_PATH":str(ROOT/"scratch/apk-analysis-runtime/binutils-aarch64/usr/lib/x86_64-linux-gnu")}
            nm=ROOT/"scratch/apk-analysis-runtime/binutils-aarch64/usr/bin/aarch64-linux-gnu-nm"
            if not nm.is_file():raise RuntimeError("pinned project AArch64 nm is unavailable")
            def rows(path, demangle=True):
                cmd=[str(nm),"-D"]
                if demangle:cmd.append("-C")
                cmd.append(str(path))
                output=subprocess.run(cmd,check=True,capture_output=True,text=True,env=env).stdout
                return parse_nm_defined_rows(output)
            # The pinned loader maps PenCommon in NativeFountain's initial
            # tuple, while Graphics and Renderer are extra mappings. Resolve
            # all three from actual exported text symbols and mapped regions;
            # do not treat the optional extra_bases catalog as authoritative.
            def dso_base(label, symbol, rva, expected):
                rows_for_dso=rows(LIB/("libSPen"+label+".so"),True)
                match=[value for value,_kind,name in rows_for_dso if name==symbol]
                if len(match)!=1 or match[0]!=rva:
                    raise RuntimeError(f"pinned {label} export mismatch for {symbol}: {match!r}")
                if symbol not in self.syms:
                    raise RuntimeError(f"loaded guest symbol table lacks required {label} export {symbol}")
                return resolve_mapped_dso_base(self.syms[symbol],rva,expected,
                    self.u.mem_regions(),label)
            common=dso_base("PenCommon","SPen::PenGLDataManager::GetMsgQueue()",0x48650,0x01000000)
            graphics=dso_base("Graphics",ACTIVATE_SUBBITMAP_RT,0x8dfc4,0x04000000)
            renderer=dso_base("Renderer","SPen::ShaderManager::GetInstance()",0x45bd0,0x05000000)
            # Resolve vtable/typeinfo data from the already hash-pinned native
            # DSOs. The queue class itself is host code, but uses native RTTI,
            # a source-pinned IGLMsgQueue ABI, and native WorkerTask objects.
            raw_renderer=rows(LIB/"libSPenRenderer.so",False)
            ti=[renderer+rva for rva,kind,name in raw_renderer if kind.upper() in ("V","D","R") and name=="_ZTIN4SPen11IGLMsgQueueE"]
            if len(ti)!=1 or ti[0]!=renderer+0x6b3f0:
                raise RuntimeError(f"pinned Renderer must export IGLMsgQueue typeinfo at its source-pinned RVA: {ti!r}")
            self.queue_typeinfo=ti[0]
            self.queue_dso_mappings={"PenCommon":{"base":hex(common),"symbol":"SPen::PenGLDataManager::GetMsgQueue()","rva":"0x48650"},
                "Graphics":{"base":hex(graphics),"symbol":ACTIVATE_SUBBITMAP_RT,"rva":"0x8dfc4"},
                "Renderer":{"base":hex(renderer),"symbol":"SPen::ShaderManager::GetInstance()","rva":"0x45bd0","queue_typeinfo":hex(self.queue_typeinfo)}}
            allowed_prefix="vtable for SPen::WorkerTask::"
            for library,base in (("libSPenPenCommon.so",common),("libSPenGraphics.so",graphics)):
                for rva,kind,name in rows(LIB/library,True):
                    if kind.upper() in ("V","D") and (name.startswith(allowed_prefix) or name=="vtable for SPen::PenGLRenderMsg"):
                        vptr=base+rva+16
                        if vptr in self.queue_task_vtables:
                            raise RuntimeError(f"duplicate source vtable address for native queue task: {vptr:#x}")
                        self.queue_task_vtables[vptr]=name
                        self.queue_task_sources[vptr]=library
            if not self.queue_task_vtables:
                raise RuntimeError("pinned PenCommon/Graphics DSOs expose no supported WorkerTask vtables")
            # One typed host queue object changes its PostTask policy by phase.
            # PenGLDataManager rejects replacing a different nonnull queue, so
            # setup execution and deferred ownership share the same pointer.
            self.queue=self.alloc(32); qmem=self.alloc(80); qvt=qmem+16
            self.managed_queue=self.alloc(32); mmem=self.alloc(48); mvt=mmem+16
            self.setup_queue=self.queue
            for obj,vptr in ((self.queue,qvt),(self.managed_queue,mvt)):
                self.put(obj,"Q",vptr)
            self.put(qvt-16,"qQ",0,self.queue_typeinfo)
            self.put(qvt+16,"Q",0x20001100)
            self.put(qvt+56,"Q",0x20001060)
            self.put(mvt+16,"Q",0x20001080)
            self.put(mvt+24,"Q",0x200010a0)
            for address in (0x20001020,0x20001040,0x20001060,
                            0x20001080,0x200010a0,0x20001100,0x20001200):
                self.u.mem_write(address,bytes.fromhex("1f2003d5c0035fd6"))
            self.queue_trampolines={0x20001020,0x20001040,0x20001060,
                                    0x20001080,0x200010a0,0x20001100,0x20001200}

        def queue_code_hook(self,u,address,_size,_data):
            if address==0x20001060:
                receiver=self.x(0)
                if receiver!=self.queue:
                    raise RuntimeError(f"IGLMsgQueue GetQueue callback received unexpected receiver {receiver:#x}")
                self.queue_get_calls.append({"receiver":hex(receiver),"return_queue":hex(self.managed_queue),
                    "caller_lr":hex(u.reg_read(R.UC_ARM64_REG_LR))})
                self.x(0,self.managed_queue);u.reg_write(R.UC_ARM64_REG_PC,u.reg_read(R.UC_ARM64_REG_LR));return
            if address in (0x20001080,0x200010a0):
                receiver=self.x(0)
                if receiver!=self.managed_queue:
                    raise RuntimeError(f"managed queue registration callback received unexpected receiver {receiver:#x}")
                self.queue_registration_calls.append({"callback_slot":"register" if address==0x20001080 else "unregister",
                    "receiver":hex(receiver),"argument":hex(self.x(1)),
                    "caller_lr":hex(u.reg_read(R.UC_ARM64_REG_LR))})
                self.x(0,1);u.reg_write(R.UC_ARM64_REG_PC,u.reg_read(R.UC_ARM64_REG_LR));return
            if address in (0x20001020,0x20001040):
                self.x(0,1);u.reg_write(R.UC_ARM64_REG_PC,u.reg_read(R.UC_ARM64_REG_LR));return
            if address==0x20001200:
                if not self.queue_return_stack:
                    raise RuntimeError("native WorkerTask Run reached the setup return trampoline without a saved caller")
                caller,index=self.queue_return_stack.pop()
                row=self.queue_setup_tasks[index]
                row["native_Run_return_x0"]=hex(self.x(0))
                row["native_Run_completed"]=True
                row["ownership_transferred_to_setup_queue"]=True
                u.reg_write(R.UC_ARM64_REG_LR,caller);u.reg_write(R.UC_ARM64_REG_PC,caller);return
            if address!=0x20001100:return
            receiver,task=self.x(0),self.x(1)
            is_setup=self.queue_active_phase in ("pencil2_rt_init","subbitmap_native_constructor","subbitmap_framebuffer_create")
            if receiver!=self.queue:raise RuntimeError(f"IGLMsgQueue PostTask receiver mismatch at {address:#x}: {receiver:#x}")
            if not task:raise RuntimeError("IGLMsgQueue PostTask received null WorkerTask")
            vptr=self.get(task,"Q")[0]
            source=self.queue_task_sources.get(vptr)
            run_method=self.get(vptr+16,"Q")[0] if vptr in self.queue_task_vtables else 0
            allocation=next((row for row in reversed(self.native_allocations) if int(row["pointer"],16)==task),None)
            if source is None or not run_method or allocation is None:
                raise RuntimeError(f"queue task is not a source-pinned native WorkerTask allocation: task={task:#x}, vptr={vptr:#x}, source={source!r}, run={run_method:#x}")
            task_size=int(allocation["size"])
            if not 0<task_size<=4096:raise RuntimeError(f"native WorkerTask size outside evidence cap: {task_size}")
            lr=u.reg_read(R.UC_ARM64_REG_LR)
            row={"index":len(self.queue_setup_tasks)+len(self.queue_retained_tasks),
                "queue":hex(receiver),"queue_kind":"setup_native_run" if is_setup else "deferred_retained",
                "phase":self.queue_active_phase,"task":hex(task),"allocation_size":task_size,
                "allocation_caller_lr":allocation["caller_lr"],"task_vptr":hex(vptr),
                "task_vtable_symbol":self.queue_task_vtables[vptr],"task_source_dso":source,
                "run_method":hex(run_method),"run_entry_role":"native WorkerTask virtual entry +16",
                "caller_lr":hex(lr),"task_bytes_before_run":bytes(u.mem_read(task,task_size)).hex(),
                "ownership_transferred_to_queue":True}
            if is_setup:
                if self.queue_active_phase not in ("pencil2_rt_init","subbitmap_native_constructor","subbitmap_framebuffer_create"):
                    raise RuntimeError(f"native setup WorkerTask posted outside the two bounded construction phases: {self.queue_active_phase}")
                if len(self.queue_setup_tasks)>=32:raise RuntimeError("native setup WorkerTask cap exceeded")
                row["run_state"]="native_Run_executed_by_phase_scoped_host_queue"
                row["ownership_transferred_to_setup_queue"]=True
                row["retained_after_native_Run"]=True
                self.queue_setup_tasks.append(row)
                self.queue_return_stack.append((lr,len(self.queue_setup_tasks)-1))
                self.x(0,task);u.reg_write(R.UC_ARM64_REG_LR,0x20001200);u.reg_write(R.UC_ARM64_REG_PC,run_method);return
            if self.queue_active_phase not in ("rt_initialized","rt_geometry_add_update","geometry_updated",
                                                "subbitmap_initialized","rtv4_draw","draw_returned",
                                                "post_draw","native_teardown"):
                raise RuntimeError(f"native deferred queue task posted in unsupported phase {self.queue_active_phase}")
            row["run_state"]="retained_not_run"
            self.queue_retained_tasks.append(row)
            self.x(0,1);u.reg_write(R.UC_ARM64_REG_PC,u.reg_read(R.UC_ARM64_REG_LR));return

        def guard_acquire(self):
            guard=self.x(0); seen=getattr(self,"_guards",set())
            if guard in seen:self.x(0,0)
            else:seen.add(guard);self._guards=seen;self.x(0,1)
        def guard_release(self):
            self._guards.add(self.x(0)); self.x(0,0)
        def guard_abort(self):
            self._guards.discard(self.x(0)); self.x(0,0)

        def hook(self,u,address,size,data):
            if self.pending_native_managed_registrations and address==self.pending_native_managed_registrations[-1]["return_pc"]:
                row=self.pending_native_managed_registrations.pop()["row"]
                receiver=int(row["receiver"],16)
                row.update({"return_pc":hex(address),"return_x0":hex(self.x(0)),
                    "field_8_after":hex(self.get(receiver+8,"Q")[0]),
                    "field_16_after":hex(self.get(receiver+16,"Q")[0])})
                row["managed_registration_complete"]=bool(int(row["field_8_after"],16) and int(row["field_16_after"],16))
                self.native_managed_registrations.append(row)
            if address==self.syms.get(MANAGED_OBJECT_REGISTER):
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                receiver=self.x(0)
                row={"symbol":MANAGED_OBJECT_REGISTER,"entry_pc":hex(address),"receiver":hex(receiver),
                    "caller_lr":hex(lr),"field_8_before":hex(self.get(receiver+8,"Q")[0]),
                    "field_16_before":hex(self.get(receiver+16,"Q")[0]),
                    "thread_tls_round_trip":self.native_thread_setup.get("tls_round_trip",False),
                    "expected_current_queue":self.native_thread_setup.get("secondary_queue")}
                self.pending_native_managed_registrations.append({"return_pc":lr,"row":row})
            if address in self.queue_trampolines:
                self.queue_code_hook(u,address,size,data);return
            renderer_base=self.extra_bases.get("Renderer")
            if renderer_base is not None and address==renderer_base+GET_BINDING_INTF_RVA:
                request_pointer=self.x(1)
                request_bytes=self._read_guest_cstr(request_pointer,STRCMP_OPERAND_BUFFER_SIZE)
                self.binding_name_inputs.append({"index":len(self.binding_name_inputs),
                    "symbol":GET_BINDING_INTF_SYMBOL,"entry_pc":hex(address),
                    "receiver":hex(self.x(0)),"request_pointer":hex(request_pointer),
                    "request_name_bytes_hex":request_bytes.hex(),"request_name_text":request_bytes.decode(errors="replace"),
                    "caller_lr":hex(u.reg_read(R.UC_ARM64_REG_LR))})
            if self.pending_format_helper is not None and address==self.pending_format_helper["return_pc"]:
                self.pending_format_helper["returned_at"]=hex(address)
                self.format_helper_calls.append(self.pending_format_helper)
                self.pending_format_helper=None
            if renderer_base is not None and address==renderer_base+EXPECTED_FORMAT_HELPER_ENTRY_RENDERER_RVA:
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                if lr!=renderer_base+EXPECTED_GETFILENAME_RETURN_RENDERER_RVA:
                    raise RuntimeError(f"internal cache filename formatter entered from unexpected GetFileName return site: {lr:#x}")
                if self.pending_format_helper is not None:raise RuntimeError("overlapping native shader cache format helper")
                self.pending_format_helper={"entry_pc":address,"return_pc":lr,"caller_lr":lr,
                    "destination":self.x(0),"key_u64":self.x(4)}
            if self.pending_cache_path_getter is not None and address==self.pending_cache_path_getter["return_pc"]:
                pointer=self.x(0)
                raw=self._read_guest_cstr(pointer,4096) if pointer else b""
                self.cache_path_calls.append({"symbol":SYSTEM_GET_CACHE_PATH,
                    "caller_lr":hex(self.pending_cache_path_getter["lr"]),
                    "return_pc":hex(address),"result_pointer":hex(pointer) if pointer else None,
                    "result_bytes_hex":raw.hex(),"result_text":raw.decode(errors="replace")})
                self.pending_cache_path_getter=None
            if self.pending_libcpp_assign is not None and address==self.pending_libcpp_assign["return_pc"]:
                row=self.pending_libcpp_assign["row"]
                row["returned_x0"]=hex(self.x(0))
                row["returned_receiver_match"]=self.x(0)==int(row["receiver"],16)
                row["receiver_after_hex"]=bytes(u.mem_read(int(row["receiver"],16),24)).hex()
                self.libcpp_assign_calls.append(row)
                self.pending_libcpp_assign=None
            if self.current_target_activation is not None and address==self.current_target_activation.get("return_pc"):
                self.current_target_activation["returned_at"]=hex(address)
                self.current_target_activation["receiver_field_80_after"]=hex(self.get(int(self.current_target_activation["receiver"],16)+80,"Q")[0])
                self.current_target_activation["receiver_field_88_after"]=hex(self.get(int(self.current_target_activation["receiver"],16)+88,"Q")[0])
                self.current_target_activation=None
            if self.pending_framebuffer_create is not None and address==self.pending_framebuffer_create["return_pc"]:
                row=self.pending_framebuffer_create
                receiver=int(row["receiver"],16); fbo=self.get(receiver+88,"Q")[0]
                row["returned_at"]=hex(address); row["receiver_field_80_after"]=hex(self.get(receiver+80,"Q")[0])
                row["receiver_field_88_after"]=hex(fbo)
                row["native_framebuffer_offscreen_target"]=hex(self.get(fbo+16,"Q")[0]) if fbo else None
                row["framebuffer_object_vptr"]=hex(self.get(fbo,"Q")[0]) if fbo else None
                row["offscreen_target_vptr"]=hex(self.get(self.get(fbo+16,"Q")[0],"Q")[0]) if fbo else None
                self.framebuffer_create_calls.append(row); self.pending_framebuffer_create=None
            name=self.plt.get(address)
            # TextureOracle replaces native CreateTextureObject and
            # SPGraphicsFactory::CreateBitmap PLT return addresses with the
            # same helper trampoline. Record the source-observed type before
            # delegating its actual native implementation to the helper.
            if name==texture.CREATE_BITMAP:
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                sp=u.reg_read(R.UC_ARM64_REG_SP)
                row={"kind":"CreateBitmap","symbol":name,"entry_pc":hex(address),
                    "caller_lr":hex(lr),"helper_native_return_lr":hex(lr),
                    "native_impl":"SPen::SPGraphicsFactory::CreateBitmap(SPen::IGLMsgQueue*, int, int, char const*, void const*, bool, int, bool, SPen::TextureMemoryLayout, SPen::TextureTargetLayout)",
                    "helper_pending_returns_depth_before":len(self.pending_returns),
                    "args_x0_x7":[hex(self.x(i)) for i in range(8)],
                    "stack_args_u64":[hex(self.get(sp+i*8,"Q")[0]) for i in range(2)]}
                self.pending_texture_oracle_returns.append(row)
            # TextureOracle replaces the native PLT return address with this
            # helper trampoline while the native RendererFactoryImpl method runs.
            # Observe its real x0 result before delegating the trampoline's
            # source-pinned PC restoration to the helper.
            if address==self.return_tramp:
                helper_pending_return=self.pending_returns[-1] if self.pending_returns else None
                row=pop_texture_oracle_observer_return(self.pending_texture_oracle_returns,helper_pending_return)
                if row is None:
                    if self.pending_texture_factory_callbacks:
                        raise RuntimeError(f"untyped TextureOracle trampoline return while source-observed CreateTextureObject rows remain: {self.pending_texture_factory_callbacks!r}")
                    unrelated={"kind":"unclassified_helper_return","return_trampoline_pc":hex(address),
                        "helper_pending_return_lr":hex(helper_pending_return),"native_return_x0":hex(self.x(0)),
                        "native_return_x1":hex(self.x(1)),"source_factory_type":"not observed by this candidate"}
                    self.unclassified_texture_oracle_returns.append(unrelated)
                    super().hook(u,address,size,data)
                    return
                row["return_trampoline_pc"]=hex(address)
                row["native_return_x0"]=hex(self.x(0))
                row["native_return_x1"]=hex(self.x(1))
                row["native_impl_completed_before_helper_pc_restore"]=True
                if row["kind"]=="CreateBitmap":
                    row["returned_bitmap_object"]=hex(self.x(0))
                    row["returned_bitmap_object_vptr"]=hex(self.get(self.x(0),"Q")[0]) if self.x(0) else None
                    self.bitmap_factory_calls.append(row)
                elif row["kind"]=="CreateTextureObject":
                    if not self.pending_texture_factory_callbacks:
                        raise RuntimeError(f"source-observed CreateTextureObject return has no matching descriptor observer row: {row!r}")
                    texture_row=self.pending_texture_factory_callbacks.pop()
                    if texture_row["caller_lr"]!=row["caller_lr"] or texture_row["entry_pc"]!=row["entry_pc"]:
                        raise RuntimeError(f"typed TextureObject return does not match its descriptor observer row: return={row!r}, descriptor={texture_row!r}")
                    texture_row["return_trampoline_pc"]=hex(address)
                    texture_row["native_return_x0"]=hex(self.x(0))
                    texture_row["returned_texture_object"]=hex(self.x(0))
                    texture_row["returned_texture_object_vptr"]=hex(self.get(self.x(0),"Q")[0]) if self.x(0) else None
                    texture_row["native_factory_impl_completed_before_pc_restore"]=True
                    texture_row["texture_oracle_return_dispatch"]={"type":row["kind"],"caller_lr":row["caller_lr"],
                        "helper_pending_return_depth_before_restore":len(self.pending_returns),"helper_lr_matched":True}
                    self.texture_factory_calls.append(texture_row)
                else:
                    raise RuntimeError(f"unknown source-observed TextureOracle return type: {row!r}")
                super().hook(u,address,size,data)
                return
            if name=="SPen::File::IsAccessible(char const*, int)":
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                expected=self.extra_bases["Renderer"]+EXPECTED_CACHE_ACCESS_LR_RENDERER_RVA
                if lr!=expected:raise RuntimeError(f"native File::IsAccessible entered from unexpected Renderer source: {lr:#x}")
                row={"symbol":name,"lr":hex(lr),"path_pointer":hex(self.x(0)),"mode":self.x(1)}
                self.filesystem_native_calls.append(row)
            if name=="SPen::Directory::MakeDirectory(char const*)":
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                expected=self.extra_bases["Renderer"]+EXPECTED_CACHE_MKDIR_LR_RENDERER_RVA
                if lr!=expected:raise RuntimeError(f"native Directory::MakeDirectory entered from unexpected Renderer source: {lr:#x}")
                row={"symbol":name,"lr":hex(lr),"path_pointer":hex(self.x(0))}
                self.filesystem_native_calls.append(row)
            if name==SYSTEM_GET_CACHE_PATH:
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                renderer_base=self.extra_bases["Renderer"]
                expected=renderer_base+EXPECTED_CACHE_PATH_GETTER_LR_RENDERER_RVA
                if lr!=expected:raise RuntimeError(f"SDK cache path getter called from unexpected source: {lr:#x} != {expected:#x}")
                self.pending_cache_path_getter={"lr":lr,"return_pc":lr}
            if name==LIBCPP_ASSIGN_CSTR:
                lr=u.reg_read(R.UC_ARM64_REG_LR)
                renderer_base=self.extra_bases["Renderer"]
                expected=renderer_base+EXPECTED_CACHE_PATH_ASSIGN_LR_RENDERER_RVA
                if lr!=expected:raise RuntimeError(f"libc++ assign(const char*) called from unexpected Renderer source: {lr:#x} != {expected:#x}")
                receiver,source=self.x(0),self.x(1)
                raw=self._read_guest_cstr(source,4096)
                if not self.cache_path_calls or int(self.cache_path_calls[-1]["result_pointer"],16)!=source:
                    raise RuntimeError("libc++ path assignment source was not the immediately returned native System cache path")
                if self.pending_libcpp_assign is not None:raise RuntimeError("overlapping native libc++ path assignments")
                self.pending_libcpp_assign={"return_pc":lr,"row":{
                    "symbol":LIBCPP_ASSIGN_CSTR,"implementation":"pinned libc++_shared.so native export",
                    "export_address":hex(self.syms[LIBCPP_ASSIGN_CSTR]),"source_dso":"libc++_shared.so",
                    "caller":"SPen::ShaderProgramCache::Init()","caller_lr":hex(lr),
                    "receiver":hex(receiver),"source_pointer":hex(source),
                    "source_bytes_hex":raw.hex(),"source_text":raw.decode(errors="replace"),
                    "receiver_before_hex":bytes(u.mem_read(receiver,24)).hex()}}
            if address==self.syms.get(CREATE_SUBBITMAP_FRAMEBUFFER):
                receiver=self.x(0); lr=u.reg_read(R.UC_ARM64_REG_LR)
                if receiver!=self.subbitmap:raise RuntimeError(f"CreateFrameBuffer receiver differs from the native target: {receiver:#x}")
                if self.pending_framebuffer_create is not None:raise RuntimeError("overlapping native SPSubBitmapRT framebuffer creation")
                self.pending_framebuffer_create={"symbol":CREATE_SUBBITMAP_FRAMEBUFFER,"entry_pc":hex(address),
                    "receiver":hex(receiver),"caller_lr":hex(lr),"return_pc":hex(lr),
                    "receiver_field_80_before":hex(self.get(receiver+80,"Q")[0]),
                    "receiver_field_88_before":hex(self.get(receiver+88,"Q")[0]),
                    "gl_event_start":len(self.gl_events),"creation_path":"native exported SPSubBitmapRT::CreateFrameBuffer -> virtual slot +144 -> CreateFrameBufferRT(false)"}
            if address==self.syms.get(ACTIVATE_SUBBITMAP_RT):
                receiver=self.x(0)
                row={"index":len(self.target_activation_calls),"symbol":ACTIVATE_SUBBITMAP_RT,
                     "receiver":hex(receiver),"arg_bool":self.x(1),
                     "lr":hex(u.reg_read(R.UC_ARM64_REG_LR)),
                     "return_pc":u.reg_read(R.UC_ARM64_REG_LR),
                     "receiver_field_80":hex(self.get(receiver+80,"Q")[0]),
                     "receiver_field_88":hex(self.get(receiver+88,"Q")[0]),
                     "entry_pc":hex(address),"framebuffer_bind_ids":[]}
                self.target_activation_calls.append(row)
                self.current_target_activation=row
            if name==CREATE_TEXTURE_RT:
                lr=u.reg_read(R.UC_ARM64_REG_LR); receiver=self.x(0)
                rect=struct.unpack("<4i",bytes(u.mem_read(receiver+60,16)))
                row={"index":len(self.texture_rt_calls),"entry_pc":hex(address),"receiver":hex(receiver),
                    "caller_lr":hex(lr),"factory_call_site_lr":"0x"+format(lr,"x"),
                    "xy_args":[self.x(1),self.x(2)],"bitmap_index_arg":self.x(3),
                    "receiver_rect_xyxy":list(rect),"receiver_rect_dimensions":[rect[2]-rect[0],rect[3]-rect[1]],
                    "tag_pointer":hex(self.x(4)),"texture_data_pointer":hex(self.x(5)),
                    "render_target_bool_arg":self.x(6),"memory_layout_arg":self.x(7),
                    "target_layout_stack_arg":self.get(u.reg_read(R.UC_ARM64_REG_SP),"I")[0],
                    "factory_boundary_count":0}
                self.texture_rt_calls.append(row)
                self.last_texture_rt_call_index=row["index"]
            if name=="SPen::RendererFactory::CreateTextureObject(SPen::TextureDescriptor const&, char const*, void const*, unsigned int const*, unsigned int, SPen::TextureBufferInfo const*)":
                lr=u.reg_read(R.UC_ARM64_REG_LR); desc=self.x(0)
                graphics_base=self.syms[CREATE_TEXTURE_RT]-0x8d9ac
                if lr!=graphics_base+0x8da68:raise RuntimeError(f"native CreateTextureObject callsite changed: {lr:#x}")
                if self.last_texture_rt_call_index is None:
                    raise RuntimeError("native target texture factory entry lacks its source-pinned createTextureRT callsite observation")
                caller=self.texture_rt_calls[self.last_texture_rt_call_index]
                if caller["factory_boundary_count"]!=0:
                    raise RuntimeError(f"more than one CreateTextureObject call from one createTextureRT invocation: {caller!r}")
                raw=bytes(u.mem_read(desc,40))
                if address not in self.plt or self.plt[address]!=name:
                    raise RuntimeError("CreateTextureObject observer did not enter through the pinned helper-handled PLT boundary")
                row={"index":len(self.texture_factory_calls)+len(self.pending_texture_factory_callbacks),"symbol":name,"entry_pc":hex(address),"caller_lr":hex(lr),"helper_native_return_lr":hex(lr),
                    "kind":"CreateTextureObject",
                    "texture_oracle_helper":"airbrush_texture_native.TextureOracle.hook",
                    "texture_oracle_native_impl":texture.CREATE_TEXTURE_IMPL,
                    "texture_oracle_factory_record_index_before":len(self.factory_records),
                    "texture_oracle_pending_returns_depth_before":len(self.pending_returns),
                    "texture_rt_call_index":caller["index"],"texture_rt_receiver":caller["receiver"],
                    "is_requested_target_receiver":int(caller["receiver"],16)==self.subbitmap if self.subbitmap else False,
                    "descriptor_pointer":hex(desc),"descriptor_bytes":raw.hex(),
                    "descriptor_u32_0_5":list(struct.unpack("<6I",raw[:24])),
                    "descriptor_render_target_byte_24":raw[24],"descriptor_tail_hex":raw[24:].hex(),
                    "tag_pointer":hex(self.x(1)),"texture_data_pointer":hex(self.x(2)),
                    "pixel_format_map_pointer":hex(self.x(3)),"pixel_format_map_count":self.x(4),
                    "texture_buffer_info_pointer":hex(self.x(5))}
                row["receiver_rect_xyxy"]=caller["receiver_rect_xyxy"]
                row["receiver_rect_dimensions"]=caller["receiver_rect_dimensions"]
                row["descriptor_dimensions_match_native_rect"]=(row["descriptor_u32_0_5"][:2]==caller["receiver_rect_dimensions"])
                if not row["descriptor_dimensions_match_native_rect"]:
                    raise RuntimeError(f"native TextureDescriptor dimensions differ from caller receiver Rect: {row!r}")
                caller["factory_boundary_count"]+=1
                caller["factory_call_index"]=row["index"]
                self.pending_texture_factory_callbacks.append(row)
                self.pending_texture_oracle_returns.append({"kind":"CreateTextureObject","symbol":name,
                    "entry_pc":hex(address),"caller_lr":hex(lr),"helper_native_return_lr":hex(lr),
                    "native_impl":texture.CREATE_TEXTURE_IMPL,
                    "helper_pending_returns_depth_before":len(self.pending_returns),
                    "texture_factory_row_index":row["index"]})
            if name==CREATE_GRAPHICS:
                self.native_graphics_returns.append({"descriptor_u32":list(self.get(self.x(2),"8I")),"primitive":self.x(1),"x0_x4":[hex(self.x(i)) for i in range(5)]})
                u.reg_write(R.UC_ARM64_REG_PC,self.syms[CREATE_GRAPHICS_IMPL]); return
            if name==CREATE_BLEND:
                self.native_blend_returns.append({"descriptor_hex":bytes(u.mem_read(self.x(0),32)).hex()})
                u.reg_write(R.UC_ARM64_REG_PC,self.syms[CREATE_BLEND]); return
            for sym in (RT_CTOR,RT_INIT,RT_ADD,RT_UPDATE,RT_DRAW):
                if address==self.syms.get(sym):self.rtv_entries.append({"symbol":sym,"receiver":hex(self.x(0)),"pc":hex(address)})
            if name is not None:self.native_calls.append({"symbol":name,"pc":hex(address)})
            super().hook(u,address,size,data)

    p=MesaPencil2()
    LAST_PROBE=p
    # Singleton setup follows the native constructor/GOT contract used by the
    # existing Crayon2 paint adapter. No object vtable or renderer slot is forged.
    manager=p.alloc(512); p.call("SPen::ShaderManager::ShaderManager()",[manager])
    renderer_base=p.extra_bases["Renderer"]
    p.put(renderer_base+0x6d480,"Q",manager)
    p.call("SPen::ShaderManager::GetInstance()",[])
    if p.x(0)!=manager:
        raise RuntimeError("native ShaderManager constructor/GOT singleton did not round-trip")
    cache_guard=renderer_base+0x73290
    p.call("SPen::CriticalSection::CriticalSection(bool)",[cache_guard,0])
    cache_path=p.alloc(80);p.u.mem_write(cache_path,SDK_CACHE_CONFIG_PATH.encode()+b"\0")
    p.call("SPen::System::SetSDKCacheDirectoryPath(char const*)",[cache_path])
    p.call("SPen::OpenGLRenderer::InitParameters()",[],instruction_limit=2_000_000)

    width=192; height=192
    # The native SPSubBitmapRT target owns the actual framebuffer. Do not
    # manufacture a separate render target and mistake it for Draw output.
    f=p.mesa.f

    manager_gl=p.alloc(512)
    p.call("SPen::PenGLDataManager::PenGLDataManager()",[manager_gl])
    p.install_typed_queue_adapter()
    p.manager=manager_gl
    p.call("SPen::PenGLDataManager::SetMsgQueue(SPen::IGLMsgQueue*)",[manager_gl,p.setup_queue])
    if p.get(manager_gl+56,"Q")[0]!=p.setup_queue:
        raise RuntimeError("native PenGLDataManager::SetMsgQueue did not retain the single phase-scoped typed queue")
    p.call(GET_CURRENT_MSG_QUEUE,[])
    current_queue_before_rt_init=p.x(0)
    p.native_thread_setup.update({"native_current_queue_getter":GET_CURRENT_MSG_QUEUE,
        "native_current_queue_before_RT_init":hex(current_queue_before_rt_init),
        "tls_modified_by_candidate":False,"worker_start_called":False})
    rt=p.alloc(0x300); p.rt=rt
    p.call(RT_CTOR,[rt,manager_gl])
    inverse_scale=p.alloc(8);p.u.mem_write(inverse_scale,struct.pack("<2f",1.0,1.0))
    p.call(RT_SET_INVERSE_SCALE,[rt,inverse_scale])
    inverse_scale_state={"method":RT_SET_INVERSE_SCALE,"input_pointer":hex(inverse_scale),
                         "input_f32":[1.0,1.0],"rt_plus252_bytes":bytes(p.u.mem_read(rt+252,8)).hex(),
                         "native_store_contract":"Pencil2 RTV4 SetInverseScale loads [x1] and stur x8,[x0,#252]"}
    p.queue_active_phase="pencil2_rt_init"
    p.call(RT_INIT,[rt],instruction_limit=5_000_000)
    p.queue_active_phase="rt_initialized"
    if p.queue_return_stack:
        raise RuntimeError(f"native setup queue returned with pending WorkerTask Run frames: {p.queue_return_stack!r}")
    if p.get(manager_gl+56,"Q")[0]!=p.setup_queue or p.setup_queue!=p.queue:
        raise RuntimeError("single phase-scoped IGLMsgQueue pointer changed during native Pencil2 Init")
    if len(p.cache_path_calls)!=1 or len(p.libcpp_assign_calls)!=1:
        raise RuntimeError(f"first native Pencil2 RT Init shader-cache lifecycle did not complete one SDK path get/assign pair: getter={len(p.cache_path_calls)} assign={len(p.libcpp_assign_calls)}")
    assignment=p.libcpp_assign_calls[0]
    if not assignment.get("returned_receiver_match") or assignment["source_text"]!=SDK_CACHE_CONFIG_PATH:
        raise RuntimeError(f"native libc++ cache path assignment did not preserve the explicitly configured cache path: {assignment!r}")
    if EXPECTED_SHADER_CACHE_DIR not in p.virtual_dirs:
        raise RuntimeError(f"native RendererCache directory was not created by actual native Init: {p.virtual_fs_events!r}")
    if not any(row["op"]=="access" and row["path"]==EXPECTED_SHADER_CACHE_DIR and not row["exists"] for row in p.virtual_fs_events):
        raise RuntimeError(f"native Init did not perform the expected missing-directory access: {p.virtual_fs_events!r}")
    seen_fs_symbols=[row["symbol"] for row in p.filesystem_native_calls]
    if seen_fs_symbols.count("SPen::File::IsAccessible(char const*, int)")!=1 or seen_fs_symbols.count("SPen::Directory::MakeDirectory(char const*)")!=1:
        raise RuntimeError(f"shader-cache directory lifecycle did not execute each pinned Base method once: {p.filesystem_native_calls!r}")
    init_error=f["glGetError"]()
    if init_error:raise RuntimeError(f"Mesa reported GL error after native Pencil2 Init: {init_error:#x}")

    # Seed the same native vector lifecycle used by Pencil2 GLV14::RedrawPen:
    # PenReturnCallback ctor/GetBuffer, then PenDrawableRT::SetBuffer. Keep the
    # callback and its vector alive through readback; do not call its destructor
    # because the candidate has no native ISPPenCanvas callback receiver.
    callback=p.alloc(0x80)
    p.call(PEN_RETURN_CALLBACK_CTOR,[callback,rt,0])
    p.call(PEN_RETURN_CALLBACK_GET_BUFFER,[callback])
    vector=p.x(0)
    if not vector:raise RuntimeError("native PenReturnCallback::GetBuffer returned null")
    if p.get(vector,"3Q")!=(0,0,0):
        raise RuntimeError(f"native GetBuffer did not return an empty C++ vector: {p.get(vector,'3Q')!r}")
    p.call(PEN_DRAWABLE_SET_BUFFER,[rt,vector,0])
    input_slots_before_add={"rt_plus80":hex(p.get(rt+80,"Q")[0]),"rt_plus104":hex(p.get(rt+104,"Q")[0]),"callback":hex(callback),"native_vector":hex(vector)}
    if p.get(rt+80,"Q")[0]!=vector or p.get(rt+104,"Q")[0]!=0:
        raise RuntimeError(f"native PenDrawableRT::SetBuffer did not bind the callback-owned vector: {input_slots_before_add!r}")
    p.geometry_buffer_contract={"callback":hex(callback),"vector":hex(vector),"input_slots":input_slots_before_add,"published_slots":None,"update_boolean":None,"inverse_scale":inverse_scale_state}

    # Replay all 84 actual draw_object_stroke AddPoint register rows from the
    # pinned native Drawing capture into the native callback-owned C++ vector.
    # This is an explicit RT replay, not a fresh Drawing lifecycle capture.
    geometry=json.loads(DRAWPOINT_RECEIPT.read_text())
    rows=[row for row in geometry["addpoint_events"] if row.get("phase")=="draw_object_stroke"]
    source_stream=geometry["streams"]["draw_object_stroke"]
    source_stream_bytes=bytes.fromhex(source_stream["data_hex"])
    if (len(rows)!=DRAWPOINT_FULL_STREAM_ROWS or source_stream["addpoint_calls"]!=DRAWPOINT_FULL_STREAM_ROWS or
        source_stream["bytes"]!=DRAWPOINT_FULL_STREAM_BYTES or source_stream["record_stride_bytes"]!=56 or
        source_stream["sha256"]!=DRAWPOINT_FULL_STREAM_SHA256 or
        hashlib.sha256(source_stream_bytes).hexdigest()!=DRAWPOINT_FULL_STREAM_SHA256 or
        b"".join(bytes.fromhex(row["delta_bytes"]) for row in rows)!=source_stream_bytes):
        raise RuntimeError("pinned Pencil2 Drawing receipt is missing its exact complete 84-row/4704-byte draw_object_stroke stream")
    if any(int(row.get("return_pc","0"),16)!=0x5074754 for row in rows):
        raise RuntimeError("complete native Drawing stream contains an AddPoint row outside the pinned caller")
    style_rows=[row for row in geometry["style_calls"] if row.get("phase")=="draw_object_stroke" and row.get("method")==PEN_DRAWABLE_SET_PEN_DATA]
    if len(style_rows)!=1:raise RuntimeError(f"pinned Drawing capture must contain one actual SetPenData call: {style_rows!r}")
    source_style=style_rows[0]
    if int(source_style["x0"],16)!=int(geometry["route"]["selected_rt"],16):
        raise RuntimeError("pinned SetPenData receiver does not match Drawing-selected Pencil2 RTV4")
    source_size_register_bits_u32=int(source_style["s0"],16)
    source_size_register_bytes_le=struct.pack("<I",source_size_register_bits_u32)
    source_size=struct.unpack("<f",source_size_register_bytes_le)[0]
    source_argb=int(source_style["x1"],16)&0xffffffff
    if not math.isfinite(source_size) or source_size<=0 or source_argb!=int(geometry["input"]["object_stroke_color_argb"],16):
        raise RuntimeError(f"saved native style inputs are not finite/consistent: {source_style!r}")
    expected_effective_size_bytes_le_hex=geometry["pen_size_contract"]["expected_effective_pen_size_f32_bits_from_pencommon_clamp"]
    expected_effective_size_register_bits_u32=little_endian_u32_from_hex_bytes(expected_effective_size_bytes_le_hex)
    if source_size_register_bits_u32!=expected_effective_size_register_bits_u32:
        raise RuntimeError(f"native RT SetPenData size differs from PenCommon effective clamp: register_bits={source_size_register_bits_u32:#x} != decoded_expected_bits={expected_effective_size_register_bits_u32:#x}, expected_serialized_le={expected_effective_size_bytes_le_hex}")
    p.call(PEN_DRAWABLE_SET_PEN_DATA,[rt,source_argb],[source_size])
    expected_rgba=tuple(((source_argb>>shift)&255)/255.0 for shift in (16,8,0,24))
    expected_rgba_bytes=struct.pack("<4f",*expected_rgba)
    set_pen_data_state={"method":PEN_DRAWABLE_SET_PEN_DATA,"sourceDrawingCall":source_style,"rt_receiver":hex(rt),"s0_size_f32_register_bits_u32":hex(source_size_register_bits_u32),"s0_size_f32_bytes_le":source_size_register_bytes_le.hex(),"expected_size_f32_bytes_le_hex":expected_effective_size_bytes_le_hex,"expected_size_f32_register_bits_u32":hex(expected_effective_size_register_bits_u32),"w1_argb":hex(source_argb),"rt_size_u32":p.get(rt+60,"I")[0],"rt_rgba_f32_bytes":bytes(p.u.mem_read(rt+44,16)).hex(),"expected_rgba_f32_bytes":expected_rgba_bytes.hex()}
    if set_pen_data_state["rt_size_u32"]!=int(source_size) or set_pen_data_state["rt_rgba_f32_bytes"]!=expected_rgba_bytes.hex():
        raise RuntimeError(f"native Pencil2 RT style fields do not match saved Drawing SetPenData call: {set_pen_data_state!r}")
    p.geometry_buffer_contract["style"] = set_pen_data_state
    p.queue_active_phase="rt_geometry_add_update"
    for i,row in enumerate(rows):
        point16=bytes.fromhex(row["vector2_plus_tangent_bytes_16"])
        point8=bytes.fromhex(row["vector2_bytes"])
        if (len(point16)!=16 or point16[:8]!=point8 or int(row.get("return_pc","0"),16)!=0x5074754):
            raise RuntimeError(f"Drawing row {i} does not contain the complete 16-byte native SmPoint consumed by RTV4: {row!r}")
        vec=p.alloc(16); p.u.mem_write(vec,point16)
        regs=row["float_register_bits"]
        fs=[struct.unpack("<f",struct.pack("<I",int(regs[f"s{j}"],16)))[0] for j in range(7)]
        p.call(RT_ADD,[rt,vec,row["int_arg_w2"]],fs,instruction_limit=5_000_000)
    vector_begin,vector_end,vector_capacity=p.get(vector,"3Q")
    actual_geometry=bytes(p.u.mem_read(vector_begin,vector_end-vector_begin))
    expected_geometry=b"".join(bytes.fromhex(row["delta_bytes"]) for row in rows)
    mismatch_offsets=[i for i,(actual,expected) in enumerate(zip(actual_geometry,expected_geometry)) if actual!=expected]
    first_mismatch=mismatch_offsets[0] if mismatch_offsets else None
    first_mismatch_lane=(first_mismatch//4) if first_mismatch is not None else None
    geometry_diff={"actual_bytes":len(actual_geometry),"expected_bytes":len(expected_geometry),"actual_hex":actual_geometry.hex(),"expected_hex":expected_geometry.hex(),"mismatch_byte_count":len(mismatch_offsets),"mismatch_offsets":mismatch_offsets,"first_mismatch_byte":first_mismatch,"first_mismatch_record":first_mismatch//56 if first_mismatch is not None else None,"first_mismatch_byte_in_record":first_mismatch%56 if first_mismatch is not None else None,"first_mismatch_f32_lane":first_mismatch_lane,"first_mismatch_f32_lane_in_record":(first_mismatch%56)//4 if first_mismatch is not None else None,"actual_first_mismatch_u32":hex(struct.unpack_from("<I",actual_geometry,(first_mismatch_lane or 0)*4)[0]) if first_mismatch_lane is not None else None,"expected_first_mismatch_u32":hex(struct.unpack_from("<I",expected_geometry,(first_mismatch_lane or 0)*4)[0]) if first_mismatch_lane is not None else None}
    p.geometry_buffer_contract["addpoint_comparison"] = geometry_diff
    if (len(expected_geometry)!=DRAWPOINT_FULL_STREAM_BYTES or expected_geometry!=source_stream_bytes or
        actual_geometry!=expected_geometry or len(actual_geometry)!=DRAWPOINT_FULL_STREAM_BYTES):
        raise RuntimeError(f"native RTV4 AddPoint output differs from the exact pinned 84-row Drawing stream: {geometry_diff!r}")
    # Source-pinned native base API publishes this vector to the ordinary
    # Update(false)/Draw path at RT+88; no raw RT vector field writes occur.
    p.call(PEN_DRAWABLE_SEND_DATA_TO_GPU,[rt,vector,0])
    output_slots={"rt_plus88":hex(p.get(rt+88,"Q")[0]),"rt_plus112":hex(p.get(rt+112,"Q")[0]),"vector":hex(vector),"vector_bytes":len(actual_geometry),"vector_sha256":hashlib.sha256(actual_geometry).hexdigest(),"rows":len(rows),"record_stride_bytes":56}
    if p.get(rt+88,"Q")[0]!=vector or p.get(rt+112,"Q")[0]!=0:
        raise RuntimeError(f"native PenDrawableRT::SendDataToGPU did not publish the populated vector: {output_slots!r}")
    p.geometry_buffer_contract.update({"published_slots":output_slots,"update_boolean":0})
    p.call(RT_UPDATE,[rt,0],instruction_limit=5_000_000)
    if p.get(rt+72,"I")[0]!=DRAWPOINT_FULL_STREAM_ROWS or p.get(rt+193,"B")[0]!=0:
        raise RuntimeError(f"RTV4 Update(false) count/cache state differs from the complete published Drawing stream: count={p.get(rt+72,'I')[0]}, state={p.get(rt+193,'B')[0]}")
    p.queue_active_phase="geometry_updated"
    update_error=f["glGetError"]()
    if update_error:raise RuntimeError(f"Mesa reported GL error after native Pencil2 Update: {update_error:#x}")

    # Create a native SPSubBitmapRT backing bitmap through the shipped Graphics
    # constructor. The input is an explicit fixed test target; no fake vtable.
    # If the constructor requires a queue task, the hook fails closed above.
    rect=p.alloc(16); p.u.mem_write(rect,struct.pack("<4i",0,0,width,height))
    subbitmap=p.alloc(0x200); p.subbitmap=subbitmap
    queue=p.setup_queue
    bitmap_name=p.alloc(32); p.u.mem_write(bitmap_name,b"pencil2-mesa-target\0")
    p.queue_active_phase="subbitmap_native_constructor"
    constructor_args=[subbitmap,queue,0,rect,width,height,bitmap_name,0,1,6,2]
    p.constructor_input={"symbol":"SPen::SPSubBitmapRT::SPSubBitmapRT(SPen::IGLMsgQueue*, int, SPen::Rect const&, int, int, char const*, void const*, bool, SPen::TextureMemoryLayout, SPen::TextureTargetLayout)",
        "register_and_stack_arguments":[hex(value) for value in constructor_args],"bool_render_target":constructor_args[8],
        "texture_layout_pair":constructor_args[9:11],"explicit_rect_i32":[0,0,width,height]}
    p._invoke("SPen::SPSubBitmapRT::SPSubBitmapRT(SPen::IGLMsgQueue*, int, SPen::Rect const&, int, int, char const*, void const*, bool, SPen::TextureMemoryLayout, SPen::TextureTargetLayout)",[subbitmap,queue,0,rect,width,height,bitmap_name,0,1,6,2])
    p.constructor_input["texture_object_after_constructor"]=hex(p.get(subbitmap+80,"Q")[0])
    p.constructor_input["subbitmap_framebuffer_after_constructor"]=hex(p.get(subbitmap+88,"Q")[0])
    target_texture_factories=[row for row in p.texture_factory_calls if row.get("is_requested_target_receiver") and row.get("texture_rt_receiver")==hex(subbitmap)]
    p.constructor_input["texture_factory_calls_for_target_receiver"]=target_texture_factories
    p.constructor_input["texture_rt_calls_for_target_receiver"]=[row for row in p.texture_rt_calls if row["receiver"]==hex(subbitmap)]
    if p.pending_texture_factory_callbacks:
        raise RuntimeError(f"TextureOracle returned from target constructor with pending CreateTextureObject callbacks: {p.pending_texture_factory_callbacks!r}")
    if p.pending_texture_oracle_returns or p.pending_returns:
        raise RuntimeError(f"TextureOracle constructor left shared helper/native return rows pending: observer={p.pending_texture_oracle_returns!r}, helper={p.pending_returns!r}")
    if len(target_texture_factories)!=1 or target_texture_factories[0]["descriptor_render_target_byte_24"]!=1:
        raise RuntimeError(f"requested SPSubBitmapRT constructor bool did not reach its own TextureDescriptor/factory boundary: target={target_texture_factories!r}, all={p.texture_factory_calls!r}")
    if p.constructor_input["texture_object_after_constructor"]!=target_texture_factories[0]["returned_texture_object"]:
        raise RuntimeError(f"target SPSubBitmapRT+80 is not the actual object returned through TextureOracle’s native CreateTextureObject bridge: {p.constructor_input!r}")
    p.queue_active_phase="subbitmap_initialized"
    if p.queue_return_stack:
        raise RuntimeError(f"native setup queue returned with pending bitmap WorkerTask Run frames: {p.queue_return_stack!r}")
    # SPSubBitmapRT construction only creates its texture (field+80). The
    # shipped CreateFrameBuffer lifecycle separately constructs SPFrameBuffer,
    # creates an OffscreenRenderTarget/FBO, and stores it in field+88.
    p.queue_active_phase="subbitmap_framebuffer_create"
    framebuffer_gl_start=len(p.gl_events)
    p.call(CREATE_SUBBITMAP_FRAMEBUFFER,[subbitmap],instruction_limit=5_000_000)
    p.queue_active_phase="subbitmap_framebuffer_created"
    framebuffer_create=finish_native_framebuffer_call_observation(p,subbitmap,FRAMEBUFFER_CALL_STOP)
    if p.pending_framebuffer_create is not None or not p.framebuffer_create_calls or p.framebuffer_create_calls[-1] is not framebuffer_create:
        raise RuntimeError("post-stop native SPSubBitmapRT::CreateFrameBuffer observation did not finalize the pending target call")
    framebuffer_create["gl_events"]=[event for event in p.gl_events[framebuffer_gl_start:]]
    if p.queue_return_stack:raise RuntimeError(f"native framebuffer lifecycle returned with pending WorkerTask Run frames: {p.queue_return_stack!r}")
    if p.get(manager_gl+56,"Q")[0]!=p.setup_queue:raise RuntimeError("native framebuffer lifecycle changed the installed IGLMsgQueue")
    if int(framebuffer_create["receiver_field_88_after"],16)==0 or not framebuffer_create["native_framebuffer_offscreen_target"]:
        raise RuntimeError(f"native CreateFrameBuffer failed to publish its real SPFrameBuffer/OffscreenRenderTarget to +88: {framebuffer_create!r}")
    # Establish an explicit transparent baseline through the same native bitmap
    # activation before Draw; record PRE bytes separately from native paint.
    p.queue_active_phase="target_preclear_setup"
    p.call(ACTIVATE_SUBBITMAP_RT,[subbitmap,0],instruction_limit=5_000_000)
    f["glViewport"](0,0,width,height);f["glClearColor"](0.0,0.0,0.0,0.0);f["glClear"](0x00004000)
    pre_pixels=C.create_string_buffer(width*height*4);f["glPixelStorei"](0x0d05,1);f["glReadPixels"](0,0,width,height,0x1908,0x1401,pre_pixels);pre_raw=pre_pixels.raw
    if f["glGetError"]():raise RuntimeError("Mesa preclear baseline readback returned a GL error")
    f["glBindFramebuffer"](0x8d40,0)
    matrix=p.alloc(64); p.u.mem_write(matrix,struct.pack("<16f",1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1))
    draw_event_start=len(p.gl_events)
    activation_start=len(p.target_activation_calls)
    p.queue_active_phase="rtv4_draw"
    p.call(RT_DRAW,[rt,subbitmap,matrix],instruction_limit=8_000_000)
    p.queue_active_phase="draw_returned"
    err=f["glGetError"]()
    if err:raise RuntimeError(f"Mesa reported GL error after native Pencil2 RTV4 Draw: {err:#x}")
    draw_events=p.gl_events[draw_event_start:]
    pending_draw_tasks=[row for row in p.queue_retained_tasks if row["phase"] in ("rt_geometry_add_update","geometry_updated","rtv4_draw")]
    if pending_draw_tasks:
        raise RuntimeError(f"native Pencil2 render posted WorkerTasks to the deferred host queue; no queued work was run, so readback would be incomplete: {pending_draw_tasks!r}")
    draw_activations=[row for row in p.target_activation_calls[activation_start:] if row["receiver"]==hex(subbitmap)]
    if len(draw_activations)!=1 or not draw_activations[0].get("returned_at"):
        raise RuntimeError(f"RTV4 Draw did not complete exactly one SPSubBitmapRT ActivateFrameBufferRT on its target: {draw_activations!r}")
    target_activation=draw_activations[0]
    if target_activation["arg_bool"]!=0:
        raise RuntimeError(f"RTV4 Draw activated target with unexpected discard flag: {target_activation['arg_bool']}")
    expected_activate_lr=p.extra_bases["Pencil2"]+EXPECTED_ACTIVATE_CALLSITE_RTV4
    if int(target_activation["lr"],16)!=expected_activate_lr:
        raise RuntimeError(f"SPSubBitmapRT activation caller differs from RTV4 Draw site: {target_activation['lr']} != {expected_activate_lr:#x}")
    activation_binds=[event for event in draw_events if event.get("activation_call_index")==target_activation["index"] and event["name"]=="glBindFramebuffer"]
    draw_target_fbos=[]
    for event in activation_binds:
        if event["args"][0]==0x8d40 and event["args"][1] in p.framebuffer_ids and event["args"][1] not in draw_target_fbos:
            draw_target_fbos.append(event["args"][1])
    if len(draw_target_fbos)!=1:
        raise RuntimeError(f"target receiver's native ActivateFrameBufferRT did not bind one generated Mesa FBO: {activation_binds!r}")
    draw_target_fbo=draw_target_fbos[0]
    target_activation["framebuffer_bind_ids"]=[event["args"][1] for event in activation_binds]
    target_attachments=[]
    bound_fbo=None
    for event in p.gl_events[:draw_event_start]+draw_events:
        if event["name"]=="glBindFramebuffer" and len(event.get("args",[]))==2:
            bound_fbo=event["args"][1]
        elif event["name"]=="glFramebufferTexture2D" and len(event.get("args",[]))==5 and bound_fbo==draw_target_fbo:
            target_attachments.append(event["args"])
    valid_attachments=[row for row in target_attachments if row[0]==0x8d40 and row[1]==0x8ce0 and row[2]==0x0de1 and row[3] in p.texture_ids and row[4]==0]
    if not valid_attachments:
        raise RuntimeError(f"native Draw target FBO lacks a Mesa-generated GL_FRAMEBUFFER/COLOR_ATTACHMENT0/GL_TEXTURE_2D attachment: {target_attachments!r}")
    target_texture=valid_attachments[0][3]
    target_format_rows=[event for event in p.gl_events if event.get("name")=="glTexImage2D" and event.get("texture")==target_texture and event["args"][3:5]==[width,height]]
    rgba8_target_rows=[event for event in target_format_rows if event["args"][2]==0x8058 and event["args"][6]==0x1908 and event["args"][7]==0x1401]
    if len(rgba8_target_rows)!=1:
        raise RuntimeError(f"native FBO attachment is not joined to exactly one Mesa RGBA8/GL_RGBA/UNSIGNED_BYTE storage allocation: texture={target_texture}, rows={target_format_rows!r}")
    draw_calls=[event for event in draw_events if event["name"] in ("glDrawArrays","glDrawArraysInstanced","glDrawElements")]
    if not draw_calls:
        raise RuntimeError("RTV4 Draw returned without an observed Mesa draw call")
    if len(draw_calls)!=1 or draw_calls[0]["name"]!="glDrawArraysInstanced" or draw_calls[0].get("args")!=[5,0,4,DRAWPOINT_FULL_STREAM_ROWS]:
        raise RuntimeError(f"complete Pencil2 replay did not reach exactly one native 84-instance triangle-strip draw: {draw_calls!r}")
    f["glBindFramebuffer"](0x8d40,draw_target_fbo)
    status=f["glCheckFramebufferStatus"](0x8d40)
    if status!=0x8cd5: raise RuntimeError(f"native Pencil2 target framebuffer incomplete after Draw: {status:#x}")
    f["glViewport"](0,0,width,height)
    pixels=C.create_string_buffer(width*height*4)
    f["glPixelStorei"](0x0d05,1); f["glReadPixels"](0,0,width,height,0x1908,0x1401,pixels)
    raw=pixels.raw
    if f["glGetError"]():raise RuntimeError("Mesa readback returned a GL error")
    if len(pre_raw)!=len(raw) or not any(a!=b for a,b in zip(pre_raw,raw)):
        raise RuntimeError("native Pencil2 Draw produced no per-channel difference from the explicitly cleared RGBA8 target")
    channel_changes={"changed_pixels":sum(1 for i in range(0,len(raw),4) if raw[i:i+4]!=pre_raw[i:i+4]),"changed_channel_bytes":[sum(1 for ch_i in range(ch,len(raw),4) if raw[ch_i]!=pre_raw[ch_i]) for ch in range(4)],"pre_minmax":[[min(pre_raw[ch::4]),max(pre_raw[ch::4])] for ch in range(4)],"post_minmax":[[min(raw[ch::4]),max(raw[ch::4])] for ch in range(4)],"post_nonzero":[sum(1 for value in raw[ch::4] if value!=0) for ch in range(4)]}
    p.pixel_diagnostic={"channel_changes":channel_changes,"pre_alpha_sha256":hashlib.sha256(pre_raw[3::4]).hexdigest(),"post_alpha_sha256":hashlib.sha256(raw[3::4]).hexdigest(),"readback_bytes":len(raw)}
    if channel_changes["changed_channel_bytes"][3]<=0 or channel_changes["post_nonzero"][3]<=0:
        raise RuntimeError(f"native Mesa Pencil2 paint produced no changed/nonzero alpha samples (row0 is source-shader-discarded; rows1-3 are eligible): {channel_changes!r}")
    vector=p.get(rt+80,"Q")[0]; begin,end,capacity=p.get(vector,"QQQ")
    if not begin<=end<=capacity or (end-begin)%56:raise RuntimeError("RTV4 buffer is not a bounded 56-byte record stream")
    stream=bytes(p.u.mem_read(begin,end-begin))
    if len(stream)!=DRAWPOINT_FULL_STREAM_BYTES or hashlib.sha256(stream).hexdigest()!=DRAWPOINT_FULL_STREAM_SHA256:
        raise RuntimeError(f"post-Draw RTV4 vector no longer contains the exact pinned 84-row/4704-byte stream: bytes={len(stream)}, sha256={hashlib.sha256(stream).hexdigest()}")
    graphics=p.get(rt+200,"Q")[0]
    graphics_vptr=p.get(graphics,"Q")[0]
    graphics_vtable_symbol="vtable for SPen::GLES::GraphicsObject"
    expected_graphics_vptr=p.syms.get(graphics_vtable_symbol)
    if expected_graphics_vptr is not None:expected_graphics_vptr+=16
    if expected_graphics_vptr is not None and graphics_vptr!=expected_graphics_vptr:
        raise RuntimeError(f"RTV4 graphics object did not use native GraphicsObject vtable: {graphics_vptr:#x} != {expected_graphics_vptr:#x}")
    if not p.native_graphics_returns:raise RuntimeError("Pencil2 Init did not route through native RendererFactoryImpl::GreateGraphicsObject")
    if not p.texture_ids or not p.buffer_ids:raise RuntimeError("native Pencil2 pipeline did not allocate actual Mesa texture and buffer IDs")
    if not p.shader_sources or not p.programs:raise RuntimeError("native Pencil2 shader source was not compiled through Mesa")
    expected_pattern_uploads={
        (150,150,"6eb2dcce1a14653fb945de5eb446b8e706f9d02d86f74277a3146c08d0e6ea7e"),
        (100,300,"743dc88582b5fe222d0375807c56be7ef4b03ee878d77f1bbe1e6f3b929558db"),
    }
    actual_uploads={(row["args"][4],row["args"][5],row["sha256"]) for row in p.uploads if row["name"]=="glTexSubImage2D"}
    if not expected_pattern_uploads.issubset(actual_uploads):
        raise RuntimeError(f"native Mesa uploads do not contain the two pinned Pencil2 pattern payloads: {actual_uploads!r}")
    return {
        "schema":"sdocx.pencil2-rtv4-native-mesa-draw.v11",
        "scope":"Pencil2 RTV4 constructor/Init/AddPoint/Update/Draw plus native SPSubBitmapRT texture and CreateFrameBuffer lifecycle, Renderer offscreen target, Mesa GL IDs and framebuffer readback. All 84 direct AddPoint inputs replay the pinned draw_object_stroke phase from V29 (4704 bytes, 56-byte records); V29 used a synthetic Model ObjectStroke setter input, not a serialized Samsung document. This is controlled RT replay, not fresh Drawing admission or device capture. No RenderThreadGLImpl is constructed because that constructor requires Android system-property dynamic loading; the native current queue is observed without mutation.",
        "pinned_inputs":{"dsos":DSO_PINS,"source_receipts":{"v37_successful_four_point_mesa_receipt_sha256":V37_SUCCESS_SHA256,"v37_retrospective_evidence_sha256":V37_RETROSPECTIVE_SHA256,"v29_full_stream_rows":DRAWPOINT_FULL_STREAM_ROWS,"v29_full_stream_bytes":DRAWPOINT_FULL_STREAM_BYTES,"v29_full_stream_sha256":DRAWPOINT_FULL_STREAM_SHA256,"v37_retrospective_sha256":V37_RETROSPECTIVE_SHA256,"v37_candidate_sha256":V37_CANDIDATE_SHA256,"v37_manifest_sha256":V37_MANIFEST_SHA256,"drawpoint_full_stream_bytes":DRAWPOINT_FULL_STREAM_BYTES,"drawpoint_full_stream_rows":DRAWPOINT_FULL_STREAM_ROWS,"drawpoint_full_stream_sha256":DRAWPOINT_FULL_STREAM_SHA256,"v36_native_framebuffer_stop_observer_failure_sha256":V36_FAILURE_SHA256,"v36_candidate_sha256":V36_CANDIDATE_SHA256,"v36_manifest_sha256":V36_MANIFEST_SHA256,"v35_shared_return_observer_failure_sha256":V35_FAILURE_SHA256,"v35_candidate_sha256":V35_CANDIDATE_SHA256,"v35_manifest_sha256":V35_MANIFEST_SHA256,"v32_null_framebuffer_failure_sha256":V32_FAILURE_SHA256,"v32_candidate_sha256":V32_CANDIDATE_SHA256,"v32_manifest_sha256":V32_MANIFEST_SHA256,"v31_null_framebuffer_failure_sha256":V31_FAILURE_SHA256,"v31_candidate_sha256":V31_CANDIDATE_SHA256,"v31_manifest_sha256":V31_MANIFEST_SHA256,"v30_posix_memalign_failure_sha256":V30_FAILURE_SHA256,"v30_candidate_sha256":V30_CANDIDATE_SHA256,"v30_manifest_sha256":V30_MANIFEST_SHA256,"drawpoint_v29_sha256":DRAWPOINT_RECEIPT_SHA256,"drawpoint_v29_candidate_sha256":DRAWPOINT_CAPTURE_CANDIDATE_SHA256,"drawpoint_v29_manifest_sha256":DRAWPOINT_CAPTURE_MANIFEST_SHA256,"texture_v3_sha256":TEXTURE_V3_SHA256,"color_layout_doc_sha256":COLOR_LAYOUT_DOC_SHA256},"native_source_pins":{"SPSubBitmapRT_CreateFrameBuffer_rva":"0x8ddd0","SPSubBitmapRT_CreateFrameBuffer_bytes":struct.pack("<IIII",0xf9400008,0x2a1f03e1,0xf9404902,0xd61f0040).hex(),"SPSubBitmapRT_CreateFrameBufferRT_rva":"0x8ddf0","SPSubBitmapRT_CreateFrameBufferRT_stores_plus88_rva":"0x8de68","SPFrameBuffer_ctor_rva":"0x81d20","OffscreenRenderTarget_ctor_rva":"0x5475c","PenDrawableRT_SetPenData_rva":hex(PEN_COMMON_SET_PEN_DATA_RVA),"PenDrawableRT_SetPenData_bytes":PEN_COMMON_SET_PEN_DATA_BYTES.hex(),"Pencil2_SetInverseScale_rva":hex(PENCIL2_SET_INVERSE_SCALE_RVA),"Pencil2_SetInverseScale_bytes":PENCIL2_SET_INVERSE_SCALE_BYTES.hex(),"libcxx_posix_memalign_callsite_rvas":[hex(x) for x in sorted(LIBCPP_POSIX_MEMALIGN_CALLS)],"libcxx_posix_memalign_return_rvas":[hex(LIBCPP_POSIX_MEMALIGN_CALLS[x]["return_rva"]) for x in sorted(LIBCPP_POSIX_MEMALIGN_CALLS)],"libcxx_posix_memalign_plt_rva":hex(LIBCPP_POSIX_MEMALIGN_PLT_RVA),"SPSubBitmapRT_constructor_render_target_bool_source_rvas":["0x8d8c4","0x8d968","0x8da34","0x8da54"],"ActivateFrameBufferRT_null_texture_throw_source_rvas":["0x8dfd0","0x8e010","0x8e050","0x8e064","0x8e07c"]}},
        "host_mesa":p.mesa.identity,
        "singleton":{"constructor":"SPen::ShaderManager::ShaderManager()","got_slot_rva":"0x6d480","native_getinstance_roundtrip":True},
        "renderer_singleton_source_audit":{"getinstance_rva":"0x45bd0","getinstance_body":"direct load from GOT slot 0x6d480","got_relocation":"R_AARCH64_GLOB_DAT slot 0x6d480 resolves SPen::ShaderManager::m_instance at RVA 0x731e8","native_init_array":"pinned Renderer .init_array relocations resolve to RVAs 0x3e778, 0x56310, 0x44c90, 0x453a8; none directly targets the ShaderManager constructor at RVA 0x45bdc","setup":"call shipped ShaderManager constructor at RVA 0x45bdc on host allocation, then set its actual m_instance GOT slot as in existing Crayon2 paint adapter; bounded class-paint host setup, not natural app initialization","cache_guard":"ShaderProgramCache::m_instanceGuard is a separate 16-byte static at RVA 0x73290 via GOT slot 0x6d4b0; call shipped CriticalSection(bool=false) constructor on that exact static address. pthread functions remain serialized no-op host boundaries, so concurrency semantics are outside scope"},
        "renderer":{"graphics_factory_impl":CREATE_GRAPHICS_IMPL,"graphics_factory_calls":p.native_graphics_returns,"blend_factory_impl":CREATE_BLEND_IMPL,"blend_factory_calls":p.native_blend_returns,"actual_texture_ids":p.texture_ids,"actual_buffer_ids":p.buffer_ids},
        "queue_adapter_boundary":{"class":"host implementation of source-pinned SPen::IGLMsgQueue ABI; native typeinfo pointer from pinned Renderer DSO","native_manager":"constructed by shipped PenGLDataManager constructor and assigned through shipped SetMsgQueue at offset +56","setup_policy":"during RT Init and explicit native SPSubBitmapRT construction, PostTask accepts only exact operator-new allocations with vptrs from pinned PenCommon/Graphics WorkerTask exports and executes the actual vtable +16 Run method; retains snapshots and ownership evidence","deferred_policy":"one assigned typed adapter retains native WorkerTasks without running them outside RT Init and explicit SPSubBitmapRT construction; no second SetMsgQueue call is made","setup_queue_pointer":hex(p.setup_queue),"deferred_queue_pointer":hex(p.queue),"managed_queue_pointer":hex(p.managed_queue),"typeinfo_pointer":hex(p.queue_typeinfo),"verified_dso_mappings":p.queue_dso_mappings,"supported_task_vtables":sorted(({"source":p.queue_task_sources[a],"symbol":n} for a,n in p.queue_task_vtables.items()),key=lambda x:(x["source"],x["symbol"])),"get_queue_calls":p.queue_get_calls,"registration_calls":p.queue_registration_calls,"setup_tasks":p.queue_setup_tasks,"retained_tasks":p.queue_retained_tasks,"native_operator_new_calls":p.native_allocations},
        "native_thread_setup":p.native_thread_setup,
        "native_managed_registrations":p.native_managed_registrations,
        "runtime":{"rt":hex(rt),"entries":p.rtv_entries,"addpoint_input_rows":rows,"inverse_scale_host_control_f32":[1.0,1.0],"rtv4_stream_bytes":len(stream),"rtv4_stream_sha256":hashlib.sha256(stream).hexdigest(),"rtv4_stream_hex":stream.hex(),"subbitmap":{"pointer":hex(subbitmap),"constructor":"SPen::SPSubBitmapRT(SPen::IGLMsgQueue*, int, SPen::Rect const&, int, int, char const*, void const*, bool, SPen::TextureMemoryLayout, SPen::TextureTargetLayout)","host_arguments":{"queue":p.setup_queue,"index":0,"rect_i32":[0,0,width,height],"width":width,"height":height,"name":"pencil2-mesa-target","data":0,"is_render_target":True,"memory_layout":6,"target_layout":2}},"graphics_object":hex(graphics),"graphics_object_vptr":hex(graphics_vptr),"expected_native_graphics_vptr":hex(expected_graphics_vptr) if expected_graphics_vptr is not None else None,"graphics_vtable_symbol":graphics_vtable_symbol,"native_calls":p.native_calls[-64:]},
        "native_geometry_buffer_contract":{"callback_object":hex(callback),"vector_object":hex(vector),"native_input_slots_before_add":input_slots_before_add,"native_published_slots":output_slots,"style":set_pen_data_state,"inverse_scale":inverse_scale_state,"addpoint_comparison":geometry_diff,"update_boolean":0,"native_methods":[PEN_RETURN_CALLBACK_CTOR,PEN_RETURN_CALLBACK_GET_BUFFER,PEN_DRAWABLE_SET_BUFFER,PEN_DRAWABLE_SET_PEN_DATA,PEN_DRAWABLE_SEND_DATA_TO_GPU],"callback_destructor_called":False,"host_boundary":"single-threaded explicit native RTV4 replay; vector ownership is retained through readback because no native ISPPenCanvas callback receiver exists"},
        "native_shader_cache":{"sdk_cache_path":SDK_CACHE_CONFIG_PATH,"directory":EXPECTED_SHADER_CACHE_DIR,"filesystem":"bounded in-memory virtual directories plus memory-backed fopen/fread/fwrite callbacks; no host files are opened","directory_events":p.virtual_fs_events,"native_directory_methods":p.filesystem_native_calls,"base_dso_mapping":{"base":hex(p.base_dso_base),"end":hex(p.base_dso_end),"size":hex(BASE_DSO_MAPPING_SIZE),"base_file_access":hex(p.syms["SPen::File::IsAccessible(char const*, int)"]),"base_make_directory":hex(p.syms["SPen::Directory::MakeDirectory(char const*)"])},"directories":sorted(p.virtual_dirs),"errno":p.virtual_errno,"events":p.virtual_file_events,"files":{path:{"bytes":len(row["data"]),"sha256":hashlib.sha256(row["data"]).hexdigest()} for path,row in p.virtual_files.items() if isinstance(path,str)}},
        "runtime_helpers":p.helper_receipt,
        "native_posix_memalign_contract":{"abi":"int posix_memalign(void **, size_t alignment, size_t size)","guest_heap_only":True,"host_pointer_returned":False,"source_dso_sha256":LIBCPP_SHA256,"plt_rva":hex(LIBCPP_POSIX_MEMALIGN_PLT_RVA),"jump_slot_relocation":{"r_offset":"0x142178","type":"R_AARCH64_JUMP_SLOT","symbol":"posix_memalign"},"pinned_callers":{hex(k):LIBCPP_POSIX_MEMALIGN_CALLS[k] for k in sorted(LIBCPP_POSIX_MEMALIGN_CALLS)},"max_size_bytes":LIBCPP_POSIX_MEMALIGN_MAX_REQUEST,"max_alignment_bytes":1<<20,"heap_bounds":["0x10000000","0x12000000"],"calls":p.posix_memalign_calls,"allocations":p.native_aligned_allocations,"tracked_free_calls":p.native_free_calls},
        "native_libcpp":{**p.libcpp_receipt,"cache_path_getter_calls":p.cache_path_calls,
                         "string_assign_calls":p.libcpp_assign_calls,
                         "strlen_calls":p.libcpp_strlen_calls,
                         "posix_memalign_calls":p.posix_memalign_calls,
                         "aligned_guest_allocations":p.native_aligned_allocations,
                         "free_calls":p.native_free_calls,
                         "invalid_memory_events":p.invalid_memory_events},
        "strncmp_calls":p.strncmp_calls,
        "strtof_calls":p.strtof_calls,
        "strstr_calls":p.strstr_calls,
        "crc32_calls":p.crc32_calls,
        "format_helper_calls":p.format_helper_calls,
        "vsnprintf_calls":p.vsnprintf_calls,
        "strchr_calls":p.strchr_calls,
        "active_uniform_outputs":p.active_uniform_outputs,
        "fortified_string_calls":{"strlen_chk":p.strlen_chk_calls,"strncpy_chk2":p.strncpy_chk2_calls},
        "binding_name_inputs":p.binding_name_inputs,
        "strcmp_calls":p.strcmp_calls,
        "native_subbitmap_lifecycle":{"constructor_input":p.constructor_input,"texture_factory_calls":p.texture_factory_calls,"bitmap_factory_calls":p.bitmap_factory_calls,"unclassified_texture_oracle_returns":p.unclassified_texture_oracle_returns,"texture_rt_calls":p.texture_rt_calls,"texture_oracle_factory_records":p.factory_records,"texture_oracle_boundary":{"helper":"airbrush_texture_native.TextureOracle.hook","public_factory_callbacks_removed":[texture.CREATE_TEXTURE,texture.CREATE_BITMAP],"native_impls":{"CreateTextureObject":texture.CREATE_TEXTURE_IMPL,"CreateBitmap":"SPen::SPGraphicsFactory::CreateBitmap(SPen::IGLMsgQueue*, int, int, char const*, void const*, bool, int, bool, SPen::TextureMemoryLayout, SPen::TextureTargetLayout)"},"shared_native_return_trampoline":hex(p.return_tramp),"dispatch":"source-observed helper pending-return LIFO row; CreateTextureObject and CreateBitmap have distinct typed receipts; unobserved helper rows are recorded as unrelated","return_rows_observed_before_helper_restores_PC":True},"framebuffer_create_call":framebuffer_create,"source_semantics":{"constructor_bool_sets_texture_descriptor_byte24":True,"CreateFrameBuffer_dispatches_virtual_slot_plus144":True,"CreateFrameBufferRT_constructs_SPFrameBuffer_and_stores_at_plus88":True,"SPFrameBuffer_constructs_Renderer_offscreen_target_from_texture_plus80":True}},"mesa":{"readback_source":"Mesa FBO bind joined to this exact native SPSubBitmapRT::ActivateFrameBufferRT receiver and call during RTV4 Draw","preclear":{"native_activation_call":p.target_activation_calls[0] if p.target_activation_calls else None,"bytes_sha256":hashlib.sha256(pre_raw).hexdigest(),"bytes_rgba_hex":pre_raw.hex()},"post_minus_pre_channel_receipt":channel_changes,"alpha_delta_required":True,"target_texture_format":{"native_texture_id_from_fbo_attachment":target_texture,"mesa_allocation_event":rgba8_target_rows[0]},"readback_framebuffer":draw_target_fbo,"target_activation_call":target_activation,"all_subbitmap_activation_calls":p.target_activation_calls,"native_draw_target_texture_attachments":target_attachments,"validated_color_texture_attachments":valid_attachments,"draw_calls":draw_calls,"draw_gl_events":draw_events,"dimensions":[width,height],"actual_texture_ids":p.texture_ids,"actual_buffer_ids":p.buffer_ids,"actual_sampler_ids":p.sampler_ids,"actual_framebuffer_ids":p.framebuffer_ids,"actual_renderbuffer_ids":p.renderbuffer_ids,"actual_vertex_array_ids":p.vertex_array_ids,"gl_events":p.gl_events,"shader_sources":p.shader_sources,"shader_compile_logs":p.shader_compile,"programs":p.programs,"uniform_locations":p.uniform_locations,"texture_uploads":p.uploads,"readback_bytes":len(raw),"readback_sha256":hashlib.sha256(raw).hexdigest(),"readback_rgba_hex":raw.hex()},
        "limitations":["Native shader cache has a memory-backed file boundary; cache miss triggers native source compilation, and no host files are written.","SPSubBitmapRT constructor bool selects the render-target descriptor byte; the separate native CreateFrameBuffer API constructs SPFrameBuffer/Renderer OffscreenRenderTarget and stores it at +88. V32 proved constructor flag alone leaves +88 null. V33 records both real transitions and never writes native target fields.","The IGLMsgQueue is an explicit typed host scheduler boundary. Only native WorkerTask allocations from pinned PenCommon/Graphics vtables are accepted; setup Run is real native code. The native RenderThreadGLImpl/Android worker is not constructed; its Base property loader requires libc.so and __system_property_get, so no Android loader or property value is stubbed. ManagedObject::Register uses native emutls and its source has an explicit null-current-queue return path; this capture records Register entry/return if reached.","The ShaderProgramCache guard uses the shipped CriticalSection constructor, but pthread functions are serialized no-op host callbacks; concurrency behavior is outside scope.","Four AddPoint register rows and the native PenDrawableRT::SetPenData effective size/ARGB call replay from the pinned explicit14 Drawing capture into a native PenReturnCallback-owned C++ vector; native SetBuffer and SendDataToGPU establish the input/output slots, and Update(false) selects the published vector. The callback object is retained through readback because no native ISPPenCanvas receiver is constructed. Inverse scale is an explicit host control of (1,1), not recovered Drawing state.","posix_memalign uses a bounded guest-memory allocator only for the two source-pinned libc++ callsites; it does not expose host pointers or claim host allocator behavior outside the observed ABI boundary.","SPSubBitmapRT uses the native-source-confirmed RGBA8 layout pair (6,2) for this controlled color target; the capture must join the actual Mesa RGBA8 texture ID to the native Draw FBO attachment and compare post-DRAW bytes with an explicit transparent preclear. This does not establish an Android/device-natural canvas format.","The subbitmap is a native SPSubBitmapRT constructed with explicit 192x192 host target arguments; readback uses the native target FBO activated by Draw.","Mesa pixels are host GLES output, not Samsung device or PDF parity."],
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--preflight",action="store_true")
    group.add_argument("--capture",action="store_true")
    parser.add_argument("--output")
    args=parser.parse_args()
    if args.preflight:
        print(json.dumps(preflight(),indent=2,sort_keys=True)); return 0
    if not args.output:raise SystemExit("--capture requires --output")
    parent=CAPTURES
    if parent.is_symlink() or (parent.exists() and not parent.is_dir()):raise RuntimeError("captures must be a real directory")
    if not parent.exists():parent.mkdir(exist_ok=False)
    output=Path(args.output)
    if output.is_symlink() or output.exists() or output.parent.resolve()!=parent.resolve():raise RuntimeError("output must be a fresh direct child of captures")
    output.mkdir(exist_ok=False)
    try:
        result=capture(output)
        with (output/"capture.json").open("x",encoding="utf-8") as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write("\n")
    except BaseException as exc:
        p=LAST_PROBE
        diagnostics={}
        if p is not None:
            try:
                diagnostics={"pc":hex(p.u.reg_read(LAST_REGS.UC_ARM64_REG_PC)),
                             "lr":hex(p.u.reg_read(LAST_REGS.UC_ARM64_REG_LR)),
                             "sp":hex(p.u.reg_read(LAST_REGS.UC_ARM64_REG_SP)),
                             "registers_x0_x7":[hex(p.x(i)) for i in range(8)],
                             "last_native_calls":p.native_calls[-32:],"last_rtv_entries":p.rtv_entries[-16:],"target_activation_calls":p.target_activation_calls[-16:],"strncmp_calls":p.strncmp_calls[-16:],"strtof_calls":p.strtof_calls[-16:],"strstr_calls":p.strstr_calls[-16:],"crc32_calls":p.crc32_calls[-16:],"format_helper_calls":p.format_helper_calls[-16:],"vsnprintf_calls":p.vsnprintf_calls[-16:],"strchr_calls":p.strchr_calls[-16:],"active_uniform_outputs":getattr(p,"active_uniform_outputs",[]),"strlen_chk_calls":getattr(p,"strlen_chk_calls",[]),"strncpy_chk2_calls":getattr(p,"strncpy_chk2_calls",[]),"binding_name_inputs":getattr(p,"binding_name_inputs",[]),"strcmp_calls":getattr(p,"strcmp_calls",[]),"native_libcpp":{"receipt":getattr(p,"libcpp_receipt",{}),"cache_path_getter_calls":getattr(p,"cache_path_calls",[]),"string_assign_calls":getattr(p,"libcpp_assign_calls",[]),"pending_string_assign":getattr(p,"pending_libcpp_assign",None),"strlen_calls":getattr(p,"libcpp_strlen_calls",[]),"posix_memalign_calls":getattr(p,"posix_memalign_calls",[]),"aligned_guest_allocations":getattr(p,"native_aligned_allocations",[]),"free_calls":getattr(p,"native_free_calls",[])},"invalid_memory_events":getattr(p,"invalid_memory_events",[]),"runtime_helpers":getattr(p,"helper_receipt",{}),
                             "last_gl_events":p.gl_events[-32:],"constructor_input":getattr(p,"constructor_input",None),"texture_factory_calls":getattr(p,"texture_factory_calls",[]),"bitmap_factory_calls":getattr(p,"bitmap_factory_calls",[]),"unclassified_texture_oracle_returns":getattr(p,"unclassified_texture_oracle_returns",[]),"pending_texture_oracle_returns":getattr(p,"pending_texture_oracle_returns",[]),"framebuffer_create_calls":getattr(p,"framebuffer_create_calls",[]),"pending_framebuffer_create":getattr(p,"pending_framebuffer_create",None),"texture_rt_calls":getattr(p,"texture_rt_calls",[]),"last_texture_rt_call_index":getattr(p,"last_texture_rt_call_index",None),"pending_texture_factory_callbacks":getattr(p,"pending_texture_factory_callbacks",[]),"texture_oracle_pending_returns":getattr(p,"pending_returns",[]),"texture_oracle_return_trampoline":hex(p.return_tramp) if getattr(p,"return_tramp",0) else None,"pixel_diagnostic":getattr(p,"pixel_diagnostic",None),"virtual_fs_events":getattr(p,"virtual_fs_events",[]),
                             "filesystem_native_calls":getattr(p,"filesystem_native_calls",[]),
                             "base_dso_mapping":{"base":hex(p.base_dso_base),"end":hex(p.base_dso_end)} if getattr(p,"base_dso_base",None) else None,
                             "virtual_dirs":sorted(getattr(p,"virtual_dirs",set())),"virtual_errno":getattr(p,"virtual_errno",None),
                             "errno_pointer":hex(p.errno_ptr) if getattr(p,"errno_ptr",None) else None,
                             "geometry_buffer_contract":getattr(p,"geometry_buffer_contract",None),
                             "native_rt_pen_style_bytes_44_68":bytes(p.u.mem_read(p.rt+44,24)).hex() if getattr(p,"rt",0) else None,
                             "native_rt_inverse_scale_bytes_252_260":bytes(p.u.mem_read(p.rt+252,8)).hex() if getattr(p,"rt",0) else None,
                             "rt_inverse_scale_contract":"Pencil2 RTV4 SetInverseScale copies the 8-byte Vector2 argument to RT+252",
                             "queue_adapter":{"manager":hex(p.manager) if getattr(p,"manager",0) else None,
                                 "manager_queue":hex(p.get(p.manager+56,"Q")[0]) if getattr(p,"manager",0) else None,
                                 "setup_queue":hex(p.setup_queue) if getattr(p,"setup_queue",0) else None,
                                 "deferred_queue":hex(p.queue) if getattr(p,"queue",0) else None,
                                 "native_thread_setup":getattr(p,"native_thread_setup",{}),
                                 "native_managed_registrations":getattr(p,"native_managed_registrations",[]),
                                 "pending_native_managed_registrations":getattr(p,"pending_native_managed_registrations",[]),
                                 "active_phase":getattr(p,"queue_active_phase",None),
                                 "verified_dso_mappings":getattr(p,"queue_dso_mappings",{}),
                                 "get_queue_calls":getattr(p,"queue_get_calls",[]),
                                 "registration_calls":getattr(p,"queue_registration_calls",[]),
                                 "setup_tasks":getattr(p,"queue_setup_tasks",[]),
                                 "retained_tasks":getattr(p,"queue_retained_tasks",[]),
                                 "pending_native_Run_returns":getattr(p,"queue_return_stack",[]),
                                 "native_allocations":getattr(p,"native_allocations",[])[-64:]},
                             "rt_fields":{str(o):hex(p.get(p.rt+o,"Q")[0]) for o in (80,192,200,208,216,224,232) if p.rt}}
            except Exception as diagnostic_error:diagnostics={"diagnostic_collection_error":repr(diagnostic_error)}
        failure={"stage":"Pencil2 RTV4 Mesa Draw candidate","exception":repr(exc),"traceback":traceback.format_exc(limit=12),"diagnostics":diagnostics,"native_run_attempted":True,"pixel_claim":False}
        with (output/"failure.json").open("x",encoding="utf-8") as stream:json.dump(failure,stream,indent=2,sort_keys=True);stream.write("\n")
        raise
    return 0


if __name__=="__main__":raise SystemExit(main())
